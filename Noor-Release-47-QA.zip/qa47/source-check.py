import urllib.request,xml.etree.ElementTree as ET,json,re,html,pathlib
base=pathlib.Path('Noor/src')
xml=urllib.request.urlopen('https://tanzil.net/res/text/metadata/quran-data.xml').read()
pathlib.Path('qa47/quran-data.xml').write_bytes(xml)
root=ET.fromstring(xml);data=json.load(open(base/'mushafMarksData.json'));rev=json.load(open(base/'revelationData.json'))
quarters=[f"{v.attrib['sura']}:{v.attrib['aya']}" for v in root.find('hizbs')]
assert quarters==[v['verseKey'] for v in data['quarters']]
for s in root.find('suras'):
 m=next(v for v in rev['surahs'] if v['number']==int(s.attrib['index']))
 assert m['order']==int(s.attrib['order']) and m['type']==s.attrib['type']
page=urllib.request.urlopen('https://tanzil.net/docs/Revelation_Order').read().decode();pathlib.Path('qa47/revelation-source.html').write_text(page)
for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>',page,re.S):
 cells=[html.unescape(re.sub('<[^>]+>','',c)).strip() for c in re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.S)]
 if len(cells)>=5 and cells[0].isdigit():
  note=cells[4]
  if note:
   numbers=', '.join(re.findall(r'\d+(?:-\d+)?',note))
   n=int(cells[2]);m=next(v for v in rev['surahs'] if v['number']==n)
   if numbers:m['note']=f'يذكر جدول Tanzil استثناءات تتعلق بالآيات {numbers} في مكان النزول. هذه النسبة منقولة عن الجدول وليست إجماعًا؛ راجع نص الملاحظة في المصدر.'
   elif n==16:m['note']='ينقل المصدر أن الآيات الثلاث الأخيرة مدنية، مع تصنيف السورة مكية.'
   elif n==9:m['note']='ينقل المصدر أن الآيتين الأخيرتين مكيتان، مع تصنيف السورة مدنية.'
   else:m['note']='توجد ملاحظة عن سياق أو مكان النزول في جدول المصدر؛ راجعها مع الخلاف في ترتيب السور.'
rev['verified']='2026-10-10';(base/'revelationData.json').write_text(json.dumps(rev,ensure_ascii=False,indent=2)+'\n')
print('Verified 240 quarters, 60 hizbs, 30 juz and 114 revelation entries against current Tanzil XML.')
