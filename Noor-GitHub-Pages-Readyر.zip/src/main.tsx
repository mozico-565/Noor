import React, {useEffect, useMemo, useRef, useState} from "react";
import { createRoot } from "react-dom/client";
import {
  Search, Send, BookOpen, Bookmark, BookmarkCheck, Settings, Sparkles, Moon, Sun,
  ChevronLeft, ChevronRight, Quote, Info, X, List, RotateCcw, LibraryBig, Play, Pause, Minus, Plus
} from "lucide-react";
import "./styles.css";
const NOOR_LOGO="./noor-logo.png";
const NOOR_CIRCLE="./noor-logo-circle.png";

type QWord = { index:number; text:string; buckwalter?:string };
type QAyah = {
  number:number; verse_key:string; global_number:number; text:string; words:QWord[];
  page:number; juz:number; hizb:number; ruku?:number; sajda?:unknown;
};
type QSurah = {
  number:number; name_arabic:string; name_transliteration?:string; counts:{ayahs:number};
  revelation?:{type:string;order:number}; ayahs:QAyah[];
};
type QuranData = { dataset?:unknown; surahs:QSurah[] };
type RootWord = {t:string; r?:string};
type RootAyah = {k:string; a:number; words:RootWord[]};
type MufradatEntry = {r?:string; t?:string; v?:string[]; vc?:number};
type RootEntry = {b?:string; m?:string; f?:number; v?:string[]};
type AsbabEntry = {surah:number; ayahs:number[]; occasions:string[]};
type TafsirItem = {type:string; text:string};
type TafsirAyah = {ayah_number:number; tafsir:TafsirItem[]};
type TafsirSurah = {surah?:string; number:number; ayahs:TafsirAyah[]};
type HadithIndexItem = {book:string; id:string|number; arabic:string; reference?:string; grade?:string};
type TafsirSearchItem = {verseKey:string; surah:number; ayah:number; text:string};
type CommonFact = {id:string; patterns:string[]; title:string; answer:string; verseKey?:string; source:string};

type ReaderVerse = QAyah & {surahNumber:number; surahName:string};
type Answer = {
  title:string; ayah:string; ref:string; meaning:string; context:string; sabab:string; source:string;
  verseKey?:string;
  details?:string;
};
type WordInfo = {text:string; root?:string; contextMeaning?:string; lexicalMeaning?:string; english?:string; verseKey:string; source?:string};
type QwenIntent = {
  intent?: "word_meaning"|"person"|"surah_fact"|"tafsir"|"hadith"|"topic"|"verse_search"|"general";
  keywords?: string[];
  fact_id?: string;
  surah?: string;
  verse?: number;
};

const qwenResolvers=new Map<string,{resolve:(value:QwenIntent|null)=>void,timer:number}>();

declare global {
  interface Window {
    Android?: {
      setReaderActive:(active:boolean)=>void;
      saveReaderPage:(page:number)=>void;
      getReaderPage:()=>number;
      setSystemBarsDark?:(dark:boolean)=>void;
      isQwenReady?:()=>boolean;
      qwenModelSize?:()=>number;
      startQwenDownload?:()=>void;
      deleteQwenModel?:()=>void;
      qwenInfer?:(requestId:string,prompt:string)=>void;
    };
    noorVolumePage?:(delta:number)=>void;
    noorQwenProgress?:(percent:number,status:string)=>void;
    noorQwenResult?:(requestId:string,result:string,error:string)=>void;
  }
}

const suggestions=["ما معنى الصمد؟","اشرح سورة العصر","أين ذُكر الصبر؟","ما معنى التقوى؟"];
const contextualWordGlosses:Record<string,string>={
  "2:7|غشاوه":"غِشاوة: غطاءٌ وحجابٌ على الأبصار. في سياق الآية: جُعل على أبصارهم غطاء فلا ينتفعون برؤية الحق.",
  "2:7|ختم":"خَتَمَ: طبع وأغلق. في سياق الآية: طبع الله على قلوبهم وسمعهم بسبب كفرهم فلا يصل إليهما الهدى.",
  "2:2|المتقين":"المتقون: الذين يجعلون بينهم وبين عذاب الله وقاية بطاعته واجتناب معصيته."
};
const stopWords=new Set(["ما","ماذا","من","عن","في","هو","هي","معنى","اشرح","شرح","أين","ذكر","القرآن","القران","سورة","آية","اية","سبب","نزول","سبب النزول"]);
const functionWordMeanings:Record<string,string>={
  "من":"حرف جر، ويأتي لابتداء الغاية أو التبعيض أو غيرهما بحسب السياق.",
  "في":"حرف جر يفيد الظرفية غالبًا بحسب السياق.",
  "على":"حرف جر يفيد الاستعلاء حقيقةً أو مجازًا بحسب السياق.",
  "الى":"حرف جر يدل غالبًا على انتهاء الغاية.",
  "عن":"حرف جر يفيد المجاوزة أو البعد بحسب السياق.",
  "ب":"حرف جر، ومن معانيه الإلصاق والاستعانة والسببية بحسب السياق.",
  "ك":"حرف تشبيه وجر.",
  "ل":"حرف جر، ومن معانيه الملك والاختصاص والتعليل بحسب السياق.",
  "و":"حرف عطف أو استئناف بحسب السياق.",
  "ف":"حرف عطف أو تفريع يدل غالبًا على التعقيب بحسب السياق.",
  "ثم":"حرف عطف للترتيب مع التراخي.",
  "او":"حرف عطف، ويأتي للتخيير أو التقسيم أو الإباحة بحسب السياق.",
  "لا":"أداة نفي أو نهي أو غير ذلك بحسب السياق.",
  "ما":"قد تأتي اسمًا موصولًا أو أداة استفهام أو نفي أو غير ذلك بحسب السياق.",
  "ان":"قد تأتي أداة توكيد أو شرط أو نفي بحسب الضبط والسياق.",
  "انما":"أداة حصر وتوكيد.",
  "هل":"أداة استفهام.",
  "هذا":"اسم إشارة للمفرد المذكر.",
  "هذه":"اسم إشارة للمفرد المؤنث.",
  "ذلك":"اسم إشارة للبعيد المفرد المذكر.",
  "تلك":"اسم إشارة للبعيد المفرد المؤنث.",
  "الذي":"اسم موصول للمفرد المذكر.",
  "التي":"اسم موصول للمفرد المؤنث.",
  "الذين":"اسم موصول لجمع المذكر.",
  "هو":"ضمير منفصل للمفرد المذكر الغائب.",
  "هي":"ضمير منفصل للمفرد المؤنث الغائب.",
  "هم":"ضمير لجمع الغائبين.",
  "هن":"ضمير لجمع الغائبات.",
  "انا":"ضمير المتكلم المفرد.",
  "نحن":"ضمير المتكلمين.",
  "انت":"ضمير للمخاطب بحسب الضبط والسياق.",
  "كان":"فعل ماض ناقص، ويدل مع خبره على اتصاف الاسم بالخبر في الزمن أو السياق المذكور.",
  "ليس":"فعل ماض ناقص جامد يفيد النفي.",
  "كل":"لفظ يفيد الشمول بحسب ما يضاف إليه.",
  "بعض":"لفظ يدل على جزء من كل.",
  "قبل":"ظرف يدل على التقدم زمانًا أو مكانًا بحسب السياق.",
  "بعد":"ظرف يدل على التأخر زمانًا أو مكانًا بحسب السياق."
};

function Glass({children,className="",onClick}:{children:React.ReactNode,className?:string,onClick?:React.MouseEventHandler<HTMLDivElement>}) {
  return <div className={`glass ${className}`} onClick={onClick}>{children}</div>;
}

function normalizeArabic(s:string){
  return s
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,"")
    .replace(/[إأآٱ]/g,"ا")
    .replace(/ى/g,"ي")
    .replace(/ؤ/g,"و")
    .replace(/ئ/g,"ي")
    .replace(/ة/g,"ه")
    .replace(/[^\u0621-\u063A\u0641-\u064A0-9\s]/g,"")
    .replace(/\s+/g," ")
    .trim();
}
function cleanQuranDisplay(s:string){
  // Android system fonts do not render every ornamental Quran annotation.
  // Keep letters + ordinary harakat, remove only decorative annotation codepoints
  // that were appearing as empty square glyphs on some phones.
  return s.normalize("NFC")
    .replace(/[\u06D6-\u06ED\u08D4-\u08FF]/g,"")
    .replace(/[\u200B-\u200F\u2066-\u2069\uFEFF]/g,"");
}
function arNum(n:number){ return String(n).replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[Number(d)]); }
function clamp(n:number,min:number,max:number){ return Math.max(min,Math.min(max,n)); }

function useLiquidRuntime(){
  useEffect(()=>{
    const root=document.documentElement;
    let pressed:HTMLElement|null=null;
    let raf=0;
    let timer=0;
    let maxViewport=Math.max(window.innerHeight,window.visualViewport?.height||0);
    const setVH=()=>{
      const h=Math.round(window.visualViewport?.height ?? window.innerHeight);
      if(h>maxViewport-40)maxViewport=Math.max(maxViewport,h);
      const keyboardOpen=(maxViewport-h)>120;
      root.style.setProperty("--vvh",`${h}px`);
      root.style.setProperty("--keyboard-gap",`${Math.max(0,maxViewport-h)}px`);
      root.classList.toggle("keyboard-open",keyboardOpen);
    };
    const update=(el:HTMLElement,ev:PointerEvent)=>{
      cancelAnimationFrame(raf);
      raf=requestAnimationFrame(()=>{
        const r=el.getBoundingClientRect();
        if(!r.width||!r.height)return;
        const px=clamp(ev.clientX-r.left,0,r.width), py=clamp(ev.clientY-r.top,0,r.height);
        el.style.setProperty("--touch-x",`${px}px`);
        el.style.setProperty("--touch-y",`${py}px`);
        el.style.setProperty("--gx",`${px/r.width*100}%`);
        el.style.setProperty("--gy",`${py/r.height*100}%`);
      });
    };
    const down=(ev:PointerEvent)=>{
      const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
      if(!el)return;
      pressed=el; clearTimeout(timer); update(el,ev);
      el.classList.remove("liquid-release"); el.classList.add("liquid-press");
    };
    const move=(ev:PointerEvent)=>{ if(pressed) update(pressed,ev); };
    const release=()=>{
      if(!pressed)return;
      const el=pressed; pressed=null; el.classList.remove("liquid-press"); el.classList.add("liquid-release");
      timer=window.setTimeout(()=>el.classList.remove("liquid-release"),360);
    };
    setVH();
    window.visualViewport?.addEventListener("resize",setVH);
    window.addEventListener("orientationchange",setVH,{passive:true});
    document.addEventListener("pointerdown",down,{passive:true});
    document.addEventListener("pointermove",move,{passive:true});
    document.addEventListener("pointerup",release,{passive:true});
    document.addEventListener("pointercancel",release,{passive:true});
    return()=>{
      cancelAnimationFrame(raf); clearTimeout(timer);
      window.visualViewport?.removeEventListener("resize",setVH);
      window.removeEventListener("orientationchange",setVH);
      document.removeEventListener("pointerdown",down);
      document.removeEventListener("pointermove",move);
      document.removeEventListener("pointerup",release);
      document.removeEventListener("pointercancel",release);
    };
  },[]);
}

function App(){
  useLiquidRuntime();

  const [q,setQ]=useState("");
  const [answer,setAnswer]=useState<Answer|null>(null);
  const [tab,setTab]=useState<"home"|"quran"|"saved"|"settings">(()=>{
    const saved=localStorage.getItem("noor_last_tab");
    return saved==="quran"||saved==="saved"||saved==="settings"||saved==="home"?saved:"home";
  });
  const [dark,setDark]=useState(()=>localStorage.getItem("noor_theme")==="dark" || (!localStorage.getItem("noor_theme") && matchMedia("(prefers-color-scheme: dark)").matches));
  const [sources,setSources]=useState(false);
  const [thinking,setThinking]=useState(false);
  const [askMode,setAskMode]=useState<"quran"|"sirah">("quran");
  const [sirahPage,setSirahPage]=useState(false);
  const [thinkingStage,setThinkingStage]=useState("أفهم سؤالك…");
  const [qwenReady,setQwenReady]=useState(()=>Boolean(window.Android?.isQwenReady?.()));
  const [qwenProgress,setQwenProgress]=useState(0);
  const [qwenStatus,setQwenStatus]=useState(qwenReady?"جاهز للعمل دون إنترنت":"غير مثبت");
  const DEFAULT_QWEN_INSTRUCTION=`أنت مساعد إسلامي موثوق داخل تطبيق نور. قبل الإجابة نفّذ داخليًا هذه المراحل دون عرضها للمستخدم: (1) افهم السؤال كاملًا وحدد ما الذي يطلبه المستخدم بالضبط، مع مراعاة اللهجة والسياق، ولا تجب عن سؤال آخر يشبهه لفظيًا. (2) صنّف المجال: قرآن، تفسير، معنى كلمة، حديث، سيرة نبوية، صحابة، أسباب نزول، فقه أو معلومة إسلامية عامة. (3) استخرج كلمات بحث دلالية ومرادفات وأسماء محتملة، ثم افحص المراجع المسترجعة واختر فقط ما يجيب السؤال مباشرة. (4) إن كانت النتائج ضعيفة أو متعارضة أو لا تجيب المقصود، لا تحاول ملء الفراغ من الذاكرة؛ اطلب من نظام نور بحثًا إضافيًا أو استخدم نتائج البحث الشبكي الموثقة التي يرسلها لك. (5) كوّن جوابًا مباشرًا وطبيعيًا ثم راجعه مقابل الأدلة قبل إرساله. القرآن والنصوص والمراجع التي يرسلها نور هي مصدر الحقيقة، ولا تخترع آية أو حديثًا أو اسمًا أو رقمًا. في الحديث لا تعرض سلسلة الإسناد الطويلة ولا أسماء جميع الرواة؛ استخرج متن الحديث أو المعلومة المطلوبة، واذكر صحابيًا واحدًا راويًا للحديث إن كان معروفًا من المرجع مثل «عن أبي هريرة رضي الله عنه»، ثم اسم المصدر مثل البخاري أو مسلم. لا تعرض بادئات الفهرسة مثل bukhari: أو muslim: أو quran: أو tafsir:. إذا كان السؤال عن شخص أو حدث في السيرة فاستخرج الجواب نفسه لا أول نص يحتوي الكلمات. عند تعدد الأقوال المعتبرة اذكر الخلاف باختصار. إذا لم تكف الأدلة فقل بوضوح إن المراجع المتاحة لا تكفي بدل التخمين. اجعل الجواب مختصرًا ومباشرًا: الجواب أولًا، ثم توضيح ضروري فقط، ثم المصدر.`;
  const [qwenInstruction,setQwenInstruction]=useState(()=>localStorage.getItem("noor_qwen_instruction")||DEFAULT_QWEN_INSTRUCTION);
  const [openRouterKey,setOpenRouterKey]=useState(()=>localStorage.getItem("noor_openrouter_key")||"");
  const OPENROUTER_MODEL="deepseek/deepseek-v4-flash-0731:free";
  const [customSources,setCustomSources]=useState<Array<{id:string;title:string;content:string}>>(()=>{try{return JSON.parse(localStorage.getItem("noor_custom_sources")||"[]")}catch{return []}});
  const [sourceTitle,setSourceTitle]=useState("");
  const [sourceContent,setSourceContent]=useState("");

  const [quran,setQuran]=useState<QuranData|null>(null);
  const [mufradat,setMufradat]=useState<Record<string,MufradatEntry>>({});
  const [roots,setRoots]=useState<Record<string,RootEntry>>({});
  const [asbab,setAsbab]=useState<AsbabEntry[]>([]);
  const [wordRootIndex,setWordRootIndex]=useState<Record<string,string>>({});
  const [commonFacts,setCommonFacts]=useState<CommonFact[]>([]);
  const [dataError,setDataError]=useState("");
  const rootCache=useRef<Record<number,RootAyah[]>>({});
  const tafsirCache=useRef<Record<number,TafsirSurah>>({});
  const tafsirSearchCache=useRef<TafsirSearchItem[]|null>(null);
  const hadithCache=useRef<HadithIndexItem[]|null>(null);

  const [readerPage,setReaderPage]=useState(()=>{
    const native=window.Android?.getReaderPage?.();
    if(native && native>0)return native;
    return Number(localStorage.getItem("noor_reader_page")||"1");
  });
  const [wordInfo,setWordInfo]=useState<WordInfo|null>(null);
  const [surahPicker,setSurahPicker]=useState(false);
  const [autoScroll,setAutoScroll]=useState(false);
  const [autoScrollSpeed,setAutoScrollSpeed]=useState(()=>Number(localStorage.getItem("noor_auto_scroll_speed")||"2"));
  const [bookmarks,setBookmarks]=useState<string[]>(()=>JSON.parse(localStorage.getItem("noor_bookmarks")||"[]"));
  const [readerMounted,setReaderMounted]=useState(false);
  const [rootDownload,setRootDownload]=useState({active:false,done:0,total:0});
  const rootDownloadStarted=useRef(false);
  const readerRef=useRef<HTMLDivElement>(null);
  const restoredScroll=useRef(false);
  const scrollSaveTimer=useRef<number>(0);

  useEffect(()=>{
    Promise.all([
      fetch("./data/quran.json").then(r=>{if(!r.ok)throw new Error("quran"); return r.json()}),
      fetch("./data/mufradat.json").then(r=>r.ok?r.json():{}),
      fetch("./data/roots_index.json").then(r=>r.ok?r.json():{}),
      fetch("./data/asbab.json").then(r=>r.ok?r.json():[]),
      fetch("./data/word_root_index.json").then(r=>r.ok?r.json():{}).catch(()=>({})),
      fetch("./data/common_facts.json").then(r=>r.ok?r.json():[]).catch(()=>([]))
    ]).then(([q,m,r,a,w,f])=>{
      setQuran(q as QuranData);
      setMufradat(m);
      setRoots(r);
      setAsbab(Array.isArray(a)?a:[]);
      setWordRootIndex(w||{});
      setCommonFacts(Array.isArray(f)?f:[]);
    }).catch(()=>setDataError("تعذر تحميل بيانات القرآن. أعد بناء النسخة من GitHub Actions."));
  },[]);

  useEffect(()=>{
    localStorage.setItem("noor_theme",dark?"dark":"light");
    document.documentElement.style.colorScheme=dark?"dark":"light";
    document.documentElement.classList.toggle("dark-root",dark);
    window.Android?.setSystemBarsDark?.(dark);
  },[dark]);

  useEffect(()=>{
    window.noorQwenProgress=(percent,status)=>{
      setQwenProgress(Math.max(0,Math.min(100,Number(percent)||0)));
      setQwenStatus(status||"جاري تجهيز Qwen…");
      if(percent>=100){
        setQwenReady(true);
        setQwenStatus("جاهز للعمل دون إنترنت");
      }
    };
    window.noorQwenResult=(requestId,result,error)=>{
      const pending=qwenResolvers.get(requestId);
      if(!pending)return;
      window.clearTimeout(pending.timer);
      qwenResolvers.delete(requestId);
      if(error){
        pending.resolve(null);
        return;
      }
      try{
        const cleaned=String(result||"")
          .replace(/<think>[\s\S]*?<\/think>/g,"")
          .trim();
        if(requestId.startsWith("a")){
          (pending.resolve as any)(cleaned);
          return;
        }
        const match=cleaned.match(/\{[\s\S]*\}/);
        pending.resolve(match?JSON.parse(match[0]):null);
      }catch{
        pending.resolve(null);
      }
    };
    return()=>{
      window.noorQwenProgress=undefined;
      window.noorQwenResult=undefined;
    };
  },[]);

  useEffect(()=>{
    localStorage.setItem("noor_tab",tab);
  },[tab]);

  useEffect(()=>{
    localStorage.setItem("noor_bookmarks",JSON.stringify(bookmarks));
  },[bookmarks]);

  useEffect(()=>{
    localStorage.setItem("noor_last_tab",tab);
  },[tab]);

  const pages=useMemo(()=>{
    const map:Record<number,ReaderVerse[]>={};
    if(!quran)return map;
    for(const s of quran.surahs){
      for(const a of s.ayahs){
        (map[a.page] ||= []).push({...a,surahNumber:s.number,surahName:s.name_arabic});
      }
    }
    return map;
  },[quran]);

  const verseByKey=useMemo(()=>{
    const map=new Map<string,ReaderVerse>();
    if(quran) for(const s of quran.surahs) for(const a of s.ayahs) map.set(a.verse_key,{...a,surahNumber:s.number,surahName:s.name_arabic});
    return map;
  },[quran]);

  const firstPageBySurah=useMemo(()=>{
    const map=new Map<number,number>();
    if(quran) for(const s of quran.surahs) if(s.ayahs.length) map.set(s.number,s.ayahs[0].page);
    return map;
  },[quran]);

  async function loadRootSurah(n:number){
    if(rootCache.current[n])return rootCache.current[n];
    const url=`./data/surahs/${n}.json`;
    try{
      if("caches" in window){
        const cache=await caches.open("noor-roots-v1");
        const cached=await cache.match(url);
        if(cached){
          const data=await cached.json();
          rootCache.current[n]=data;
          return data as RootAyah[];
        }
      }
      const r=await fetch(url);
      const d=r.ok?await r.json():[];
      rootCache.current[n]=d;
      if(r.ok && "caches" in window){
        const cache=await caches.open("noor-roots-v1");
        await cache.put(url,new Response(JSON.stringify(d),{headers:{"Content-Type":"application/json"}}));
      }
      return d as RootAyah[];
    }catch{return [] as RootAyah[];}
  }

  useEffect(()=>{
    if(tab!=="quran" || !quran || rootDownloadStarted.current)return;
    rootDownloadStarted.current=true;
    let cancelled=false;
    setRootDownload({active:true,done:0,total:quran.surahs.length});
    const prepareRoots=async()=>{
      let done=0;
      for(const surah of quran.surahs){
        await loadRootSurah(surah.number);
        done+=1;
        if(!cancelled)setRootDownload({active:true,done,total:quran.surahs.length});
      }
      if(!cancelled)setRootDownload({active:false,done:quran.surahs.length,total:quran.surahs.length});
    };
    void prepareRoots();
    return()=>{cancelled=true;};
  },[tab,quran]);

  useEffect(()=>{
    if(tab!=="quran"){
      setReaderMounted(false);
      return;
    }
    setReaderMounted(false);
    const frame=requestAnimationFrame(()=>setReaderMounted(true));
    return()=>cancelAnimationFrame(frame);
  },[tab]);

  useEffect(()=>{
    const active=tab==="quran";
    window.Android?.setReaderActive?.(active);
    return()=>{ window.noorVolumePage=undefined; };
  },[tab]);

  useEffect(()=>{
    if(tab!=="quran" || !readerRef.current || restoredScroll.current)return;
    restoredScroll.current=true;
    const top=Number(localStorage.getItem("noor_reader_continuous_scroll")||"0");
    requestAnimationFrame(()=>requestAnimationFrame(()=>readerRef.current?.scrollTo({top})));
  },[tab,quran]);

  useEffect(()=>{
    localStorage.setItem("noor_auto_scroll_speed",String(autoScrollSpeed));
  },[autoScrollSpeed]);

  useEffect(()=>{
    if(!autoScroll || tab!=="quran")return;
    let raf=0,last=performance.now(),carry=0;
    const tick=(now:number)=>{
      const el=readerRef.current;if(!el)return;
      const pxPerSecond=12+autoScrollSpeed*10;
      carry += pxPerSecond*((now-last)/1000); last=now;
      if(carry>=1){ const step=Math.floor(carry); carry-=step; el.scrollTop+=step; }
      if(el.scrollTop+el.clientHeight>=el.scrollHeight-2){setAutoScroll(false);return;}
      raf=requestAnimationFrame(tick);
    };
    raf=requestAnimationFrame(tick);
    return()=>cancelAnimationFrame(raf);
  },[autoScroll,autoScrollSpeed,tab]);

  function onReaderScroll(){
    if(!readerRef.current)return;
    clearTimeout(scrollSaveTimer.current);
    const top=readerRef.current.scrollTop;
    scrollSaveTimer.current=window.setTimeout(()=>localStorage.setItem("noor_reader_continuous_scroll",String(top)),90);
  }

  function scrollToSurah(n:number,behavior:ScrollBehavior="smooth"){
    const viewport=readerRef.current;
    const target=document.getElementById(`surah-${n}`);
    if(!viewport||!target)return;
    viewport.scrollTo({top:target.offsetTop-8,behavior});
  }

  function goPage(n:number,reset=true){
    const next=clamp(n,1,604);
    setReaderPage(next);
    const first=pages[next]?.[0];
    if(first){setTab("quran");requestAnimationFrame(()=>requestAnimationFrame(()=>scrollToSurah(first.surahNumber,reset?"smooth":"auto")));}
  }

  function toggleBookmark(k:string){
    setBookmarks(b=>b.includes(k)?b.filter(x=>x!==k):[...b,k]);
  }

  function findAsbab(surah:number,ayah:number){
    return asbab.find(x=>Number(x.surah)===surah && Array.isArray(x.ayahs) && x.ayahs.map(Number).includes(ayah));
  }

  async function openWord(verse:ReaderVerse,index:number,text:string){
    const target=normalizeArabic(text);

    // Resolve the root from the exact surface form first. The old implementation
    // trusted the word array index before validating the token, which could return
    // the root of a neighbouring word when two datasets segment an ayah differently.
    let root: string | undefined = wordRootIndex[target];

    const rootData=await loadRootSurah(verse.surahNumber);
    const row=rootData.find(x=>x.k===verse.verse_key);

    if(!root && row?.words){
      const exact=row.words.find(w=>normalizeArabic(w.t)===target);
      root=exact?.r;
    }

    if(!root && row?.words?.[index]){
      const indexed=row.words[index];
      // Index fallback is accepted only when the actual surface word matches.
      if(normalizeArabic(indexed.t)===target) root=indexed.r;
    }

    const mf=root?mufradat[root]:undefined;
    const ri=root?roots[root]:undefined;

    // Prefer a context-specific gloss, then a short excerpt from the tafsir of
    // this exact ayah. The root dictionary remains visible separately as a
    // lexical reference and is never presented as the contextual meaning itself.
    let contextMeaning=contextualWordGlosses[`${verse.verse_key}|${target}`];

    const tafsir=await loadTafsirSurah(verse.surahNumber);
    const ayahTafsir=tafsir?.ayahs?.find(a=>Number(a.ayah_number)===verse.number);
    const preferred=(ayahTafsir?.tafsir||[]).find(x=>
      /الميسر|السعدي|المختصر/.test(x.type||"")
    ) || ayahTafsir?.tafsir?.[0];

    if(!contextMeaning && preferred?.text){
      const clean=preferred.text.replace(/\s+/g," ").trim();
      contextMeaning=`في سياق الآية (${preferred.type}): ${clean.slice(0,520)}${clean.length>520?"…":""}`;
    }

    if(!contextMeaning){
      contextMeaning=functionWordMeanings[target] || "لم أجد شرحًا سياقيًا مستقلًا لهذه الكلمة في المراجع المحلية الحالية.";
    }

    setWordInfo({
      text:cleanQuranDisplay(text),
      root,
      contextMeaning,
      lexicalMeaning:mf?.t
        ? `المعنى المعجمي للجذر «${root}»: ${mf.t.slice(0,650)}`
        : undefined,
      english:ri?.m,
      verseKey:verse.verse_key,
      source:preferred?.type
        ? `${preferred.type} · مفردات الراغب · فهرس الجذور المحلي`
        : "مفردات ألفاظ القرآن للراغب الأصفهاني · فهرس الجذور المحلي"
    });
  }

  function extractTerms(text:string){
    const norm=normalizeArabic(text);
    return norm.split(" ").filter(w=>w.length>1&&!stopWords.has(w)).sort((a,b)=>b.length-a.length);
  }

  function matchCommonFact(text:string){
    const n=normalizeArabic(text);
    return commonFacts.find(f=>f.patterns.some(p=>n.includes(normalizeArabic(p))));
  }

  async function loadTafsirSurah(surah:number){
    if(tafsirCache.current[surah])return tafsirCache.current[surah];
    try{
      const key=String(surah).padStart(3,"0");
      const r=await fetch(`./data/tafsir/${key}.json`);
      if(!r.ok)return null;
      const data=await r.json() as TafsirSurah;
      tafsirCache.current[surah]=data;
      return data;
    }catch{return null}
  }

  async function loadHadithIndex(){
    if(hadithCache.current)return hadithCache.current;
    try{
      const r=await fetch("./data/hadith_index.json");
      if(!r.ok)return [];
      const data=await r.json();
      hadithCache.current=Array.isArray(data)?data:[];
      return hadithCache.current;
    }catch{return []}
  }

  async function loadTafsirSearch(){
    if(tafsirSearchCache.current)return tafsirSearchCache.current;
    try{
      const r=await fetch("./data/tafsir_search.json");
      if(!r.ok)return [];
      const data=await r.json();
      tafsirSearchCache.current=Array.isArray(data)?data:[];
      return tafsirSearchCache.current;
    }catch{return []}
  }

  function compactText(text:string,max=250){
    const clean=String(text||"")
      .replace(/<[^>]+>/g," ")
      .replace(/\s+/g," ")
      .trim();
    if(clean.length<=max)return clean;
    const sentence=clean.slice(0,max);
    const cut=Math.max(sentence.lastIndexOf("。"),sentence.lastIndexOf("."),sentence.lastIndexOf("؛"),sentence.lastIndexOf("،"));
    return (cut>90?sentence.slice(0,cut):sentence).trim()+"…";
  }

  function tafsirPriority(name:string){
    const n=normalizeArabic(name);
    if(n.includes("الميسر"))return 0;
    if(n.includes("السعدي"))return 1;
    if(n.includes("ابن كثير"))return 2;
    if(n.includes("الطبري"))return 3;
    if(n.includes("القرطبي"))return 4;
    return 9;
  }

  async function callOpenRouter(messages:Array<{role:"system"|"user"|"assistant";content:string}>,maxTokens=320){
    const key=openRouterKey.trim();
    if(!navigator.onLine || !key)return null;
    const ctrl=new AbortController();
    const timer=window.setTimeout(()=>ctrl.abort(),18000);
    try{
      const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{
        method:"POST",
        signal:ctrl.signal,
        headers:{
          "Authorization":`Bearer ${key}`,
          "Content-Type":"application/json",
          "HTTP-Referer":"https://mozico-565.github.io/Noor/",
          "X-Title":"Noor Quran"
        },
        body:JSON.stringify({
          model:OPENROUTER_MODEL,
          messages,
          temperature:0.15,
          max_tokens:maxTokens
        })
      });
      if(!r.ok)throw new Error(`OpenRouter ${r.status}`);
      const j=await r.json();
      const text=String(j?.choices?.[0]?.message?.content||"").trim();
      return text||null;
    }catch(err){
      console.warn("OpenRouter unavailable; falling back locally",err);
      return null;
    }finally{window.clearTimeout(timer)}
  }

  async function understandQuestion(question:string):Promise<QwenIntent|null>{
    const system=`أنت طبقة توجيه داخل تطبيق نور. لا تجب عن السؤال ولا تستخدم معرفتك كمصدر ديني. حلل نية السؤال فقط وأعد JSON صالحًا بلا Markdown. intent واحد من: word_meaning, person, surah_fact, tafsir, hadith, topic, verse_search, general. الكلمات المفتاحية عربية قصيرة ودقيقة. fact_id لا تستخدمه إلا إذا كان السؤال يطابق حقيقة قرآنية معروفة من القائمة: longest-surah, shortest-surah, longest-ayah, ayat-kursi, surah-count, juz-count, first-surah, last-surah, basmala-tawbah, two-basmala, named-companion. الصيغة: {"intent":"...","keywords":["..."],"fact_id":"","surah":"","verse":0}`;
    const cloud=await callOpenRouter([{role:"system",content:system},{role:"user",content:question}],180);
    if(cloud){
      try{
        const m=cloud.match(/\{[\s\S]*\}/);
        if(m)return JSON.parse(m[0]) as QwenIntent;
      }catch{}
    }
    return understandWithQwen(question);
  }

  async function composeGroundedAnswer(question:string,evidence:string){
    const extra=customEvidence(question);
    if(extra)evidence=(evidence?evidence+"\n\n":"")+extra;
    const fallback=compactText(evidence,230);
    if(!evidence.trim())return fallback;

    const cloud=await callOpenRouter([
      {role:"system",content:`${qwenInstruction}\n\nأنت الآن في مرحلة صياغة الجواب النهائي. المراجع المرسلة هي مصدر الحقيقة الوحيد. لا تستخدم ذاكرتك الدينية لإكمال نقص المراجع. لا تعرض نص الفهرس الخام أو الأسانيد الطويلة إلا إذا طلب المستخدم. أجب بالعربية الواضحة باختصار، ثم اذكر المصدر إن كان ظاهرًا في المراجع.`},
      {role:"user",content:`السؤال: ${question}\n\nالمراجع المسترجعة من نور:\n${evidence.slice(0,6500)}`}
    ],360);
    if(cloud)return compactText(cloud,520);

    if(!window.Android?.isQwenReady?.() || !window.Android?.qwenInfer)return fallback;

    const requestId=`a${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const prompt=`<|im_start|>system
أنت محرر إجابة داخل تطبيق قرآن.
تعليمات المستخدم القابلة للتعديل: ${qwenInstruction}
استخدم فقط النص الموجود في "المراجع". لا تضف معلومة من ذاكرتك.
أجب بالعربية الواضحة في جملة أو جملتين، وبحد أقصى 220 حرفًا.
إذا كانت المراجع لا تكفي قل بوضوح: "المراجع المتاحة لا تكفي للجزم."
لا تكتب مقدمات ولا JSON ولا اقتباسات طويلة.
/no_think<|im_end|>
<|im_start|>user
السؤال: ${question}
المراجع:
${evidence.slice(0,2200)}<|im_end|>
<|im_start|>assistant
`;

    return new Promise<string>(resolve=>{
      const timer=window.setTimeout(()=>{
        qwenResolvers.delete(requestId);
        resolve(fallback);
      },12000);
      qwenResolvers.set(requestId,{
        timer,
        resolve:(value:any)=>{
          const raw=typeof value==="string"?value:"";
          resolve(compactText(raw||fallback,240));
        }
      } as any);
      try{
        window.Android!.qwenInfer!(requestId,prompt);
      }catch{
        window.clearTimeout(timer);
        qwenResolvers.delete(requestId);
        resolve(fallback);
      }
    });
  }

  function textScore(text:string,terms:string[]){
    const n=normalizeArabic(text);
    let score=0;
    for(const term of terms){
      if(n.includes(term))score += term.length>=5?4:2;
      else if(term.length>=4 && n.includes(term.slice(0,-1)))score += 1;
    }
    return score;
  }

  async function findHadithSupport(terms:string[]){
    if(!terms.length)return [] as HadithIndexItem[];
    const data=await loadHadithIndex();
    return data
      .map(h=>({h,score:textScore(h.arabic,terms)}))
      .filter(x=>x.score>0)
      .sort((a,b)=>b.score-a.score)
      .slice(0,3)
      .map(x=>x.h);
  }

  async function onlineQuranVerify(term:string){
    if(!navigator.onLine || !term)return null;
    const ctrl=new AbortController();
    const timer=window.setTimeout(()=>ctrl.abort(),4500);
    try{
      const url=`https://api.alquran.cloud/v1/search/${encodeURIComponent(term)}/all/quran-simple-clean`;
      const r=await fetch(url,{signal:ctrl.signal});
      if(!r.ok)return null;
      const j=await r.json();
      const matches=j?.data?.matches;
      if(!Array.isArray(matches)||!matches.length)return null;
      const m=matches[0];
      return {
        text:String(m.text||""),
        surah:String(m.surah?.name||m.surah?.englishName||""),
        number:Number(m.numberInSurah||0)
      };
    }catch{return null}
    finally{clearTimeout(timer)}
  }

  async function understandWithQwen(question:string):Promise<QwenIntent|null>{
    if(!window.Android?.isQwenReady?.() || !window.Android?.qwenInfer)return null;

    const requestId=`q${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const prompt=`<|im_start|>system
أنت وحدة فهم سؤال فقط داخل تطبيق قرآن. لا تجب عن السؤال ولا تقتبس آية من ذاكرتك.
تعليمات المستخدم القابلة للتعديل: ${qwenInstruction}
مهمتك تحويل سؤال المستخدم إلى JSON فقط بلا شرح.
القيم المسموحة intent:
word_meaning, person, surah_fact, tafsir, hadith, topic, verse_search, general.
fact_id المسموح عند التطابق الواضح فقط:
longest-surah, shortest-surah, longest-ayah, ayat-kursi, surah-count, juz-count, first-surah, last-surah, basmala-tawbah, two-basmala, named-companion.
أخرج:
{"intent":"...","keywords":["..."],"fact_id":"","surah":"","verse":0}
ضع الكلمات العربية المهمة فقط في keywords. لا تخترع معلومة دينية.
/no_think<|im_end|>
<|im_start|>user
${question}<|im_end|>
<|im_start|>assistant
`;

    return new Promise(resolve=>{
      const timer=window.setTimeout(()=>{
        qwenResolvers.delete(requestId);
        resolve(null);
      },12000);
      qwenResolvers.set(requestId,{resolve,timer});
      try{
        window.Android!.qwenInfer!(requestId,prompt);
      }catch{
        window.clearTimeout(timer);
        qwenResolvers.delete(requestId);
        resolve(null);
      }
    });
  }

  async function submitSirah(text=q){
    const t=text.trim(); if(!t || thinking)return;
    setQ(t);
    setThinking(true);
    setThinkingStage("أبحث في صحيح البخاري ومسلم…");
    if(document.activeElement instanceof HTMLElement)document.activeElement.blur();

    try{
      const ai=await understandQuestion(t);
      const baseTerms=extractTerms(t);
      const aiTerms=(ai?.keywords||[]).map(normalizeArabic).filter(x=>x.length>1&&!stopWords.has(x));
      const terms=[...new Set([...aiTerms,...baseTerms])].sort((a,b)=>b.length-a.length);
      setThinkingStage("أراجع مراجع السيرة والحديث…");
      const hadiths=await loadHadithIndex();
      const preferred=hadiths
        .filter(h=>/البخاري|bukhari|مسلم|muslim/i.test(h.book||""))
        .map(h=>({h,score:textScore(h.arabic,terms)}))
        .filter(x=>x.score>0)
        .sort((a,b)=>b.score-a.score)
        .slice(0,5)
        .map(x=>x.h);

      if(preferred.length){
        setThinkingStage("أصيغ جوابًا مختصرًا…");
        const evidence=preferred.map(h=>`${h.book}${h.reference?` · ${h.reference}`:""}: ${h.arabic}`).join("\n\n");
        const concise=await composeGroundedAnswer(`سؤال عن السيرة النبوية: ${t}`,evidence);
        setAnswer({
          title:"جواب من السيرة",
          ayah:"",
          ref:"",
          meaning:concise || compactText(preferred[0].arabic,230),
          details:preferred.map(h=>`${h.book}${h.reference?` · ${h.reference}`:""}: ${compactText(h.arabic,650)}`).join("\n\n"),
          context:"",
          sabab:"",
          source:"صحيح البخاري · صحيح مسلم"
        });
        return;
      }

      setAnswer({
        title:"لم أجد نصًا كافيًا",
        ayah:"",
        ref:"",
        meaning:"لم أجد في صحيح البخاري ومسلم نصًا واضحًا يجيب عن السؤال بهذه الصياغة. جرّب صياغة أكثر تحديدًا باسم الشخص أو الحدث.",
        details:"",
        context:"",
        sabab:"",
        source:"صحيح البخاري · صحيح مسلم"
      });
    } finally {
      setThinking(false);
    }
  }

  function customEvidence(question:string){
    const terms=extractTerms(question);
    return customSources.map(x=>({x,score:textScore(x.title+" "+x.content,terms)}))
      .filter(v=>v.score>0).sort((a,b)=>b.score-a.score).slice(0,3)
      .map(v=>`مرجع مضاف: ${v.x.title}\n${compactText(v.x.content,900)}`).join("\n\n");
  }

  async function submit(text=q){
    const t=text.trim(); if(!t || thinking)return;

    setQ(t);
    setThinking(true);
    setThinkingStage(navigator.onLine&&openRouterKey.trim()?"أفهم سؤالك بالذكاء السحابي…":qwenReady?"أفهم سؤالك…":"أبحث في المراجع…");
    if(document.activeElement instanceof HTMLElement)document.activeElement.blur();

    try{
      if(!quran){
        setAnswer({title:"جاري تجهيز البيانات",ayah:"",ref:"",meaning:dataError||"انتظر لحظة حتى تُحمّل قاعدة القرآن المحلية.",context:"",sabab:"",source:"قاعدة نور المحلية"});
        return;
      }

      const fact=matchCommonFact(t);
      if(fact){
        const v=fact.verseKey?verseByKey.get(fact.verseKey):undefined;
        setAnswer({
          title:fact.title,
          ayah:v?cleanQuranDisplay(v.text):"",
          ref:v?`سورة ${v.surahName} · الآية ${arNum(v.number)}`:"",
          meaning:fact.answer,
          context:"",
          sabab:"",
          source:fact.source
        });
        return;
      }

      const ai=await understandQuestion(t);
      setThinkingStage("أراجع القرآن والتفاسير…");

      if(ai?.fact_id){
        const aiFact=commonFacts.find(f=>f.id===ai.fact_id);
        if(aiFact){
          const v=aiFact.verseKey?verseByKey.get(aiFact.verseKey):undefined;
          setAnswer({
            title:aiFact.title,
            ayah:v?cleanQuranDisplay(v.text):"",
            ref:v?`سورة ${v.surahName} · الآية ${arNum(v.number)}`:"",
            meaning:aiFact.answer,
            context:"",
            sabab:"",
            source:aiFact.source+" · استُخدم Qwen لفهم صياغة السؤال فقط"
          });
          return;
        }
      }

      const baseTerms=extractTerms(t);
      const aiTerms=(ai?.keywords||[]).map(normalizeArabic).filter(x=>x.length>1&&!stopWords.has(x));
      const terms=[...new Set([...aiTerms,...baseTerms])].sort((a,b)=>b.length-a.length);

      // Exact word meaning.
      if((ai?.intent==="word_meaning" || /معن[ىي]|ماذا تعني|ما المقصود/.test(normalizeArabic(t))) && terms[0]){
        const word=terms[0];
        const root=wordRootIndex[word] || wordRootIndex[normalizeArabic(word)];
        const mf=root?mufradat[root]:undefined;

        const localMatches:Array<ReaderVerse>=[];
        for(const s of quran.surahs){
          for(const a of s.ayahs){
            if(a.words.some(w=>normalizeArabic(w.text)===word || normalizeArabic(w.text).includes(word))){
              localMatches.push({...a,surahNumber:s.number,surahName:s.name_arabic});
              if(localMatches.length>=5)break;
            }
          }
          if(localMatches.length>=5)break;
        }

        const first=localMatches[0];
        if(first){
          const tafsir=await loadTafsirSurah(first.surahNumber);
          const ayahTafsir=tafsir?.ayahs?.find(a=>Number(a.ayah_number)===first.number);
          const preferred=(ayahTafsir?.tafsir||[])
            .filter(x=>x.text?.trim())
            .sort((a,b)=>tafsirPriority(a.type)-tafsirPriority(b.type));

          const exactGloss=contextualWordGlosses[`${first.verse_key}|${word}`];
          const evidence=[
            exactGloss||"",
            preferred[0]?.text||"",
            mf?.t||""
          ].filter(Boolean).join("\n");

          setThinkingStage("أصيغ جوابًا مختصرًا…");
          const concise=exactGloss
            ? compactText(exactGloss,220)
            : await composeGroundedAnswer(t,evidence);

          setAnswer({
            title:`معنى ${word}`,
            ayah:cleanQuranDisplay(first.text),
            ref:`سورة ${first.surahName} · الآية ${arNum(first.number)}`,
            meaning:concise || compactText(mf?.t||"لم أجد معنى موثقًا كافيًا.",220),
            details:[
              preferred[0]?.text?`${preferred[0].type}: ${compactText(preferred[0].text,650)}`:"",
              mf?.t?`المعنى المعجمي: ${compactText(mf.t,650)}`:""
            ].filter(Boolean).join("\n\n"),
            context:localMatches.length>1?`ورد اللفظ أو قريب منه في: ${localMatches.slice(0,4).map(v=>`${v.surahName} ${arNum(v.number)}`).join(" · ")}`:"",
            sabab:first?(findAsbab(first.surahNumber,first.number)?.occasions?.[0]||""):"",
            source:[
              preferred[0]?.type,
              mf?.t?"مفردات ألفاظ القرآن للراغب الأصفهاني":"",
              "نص القرآن المحلي"
            ].filter(Boolean).join(" · ")
          });
          return;
        }
      }

      // Search Quran text.
      const scored:Array<{v:ReaderVerse;score:number}>=[];
      for(const s of quran.surahs){
        const surahName=normalizeArabic(s.name_arabic);
        for(const a of s.ayahs){
          let score=textScore(a.text,terms);
          if(terms.some(term=>surahName.includes(term)))score+=3;
          if(score>0)scored.push({v:{...a,surahNumber:s.number,surahName:s.name_arabic},score});
        }
      }

      // Search a compact tafsir index as a second retrieval channel.
      const tafsirIndex=await loadTafsirSearch();
      const tafsirHits=tafsirIndex
        .map(x=>({x,score:textScore(x.text,terms)}))
        .filter(x=>x.score>1)
        .sort((a,b)=>b.score-a.score)
        .slice(0,8);

      for(const hit of tafsirHits){
        const v=verseByKey.get(hit.x.verseKey);
        if(v){
          const existing=scored.find(x=>x.v.verse_key===v.verse_key);
          if(existing)existing.score+=hit.score+2;
          else scored.push({v,score:hit.score+2});
        }
      }

      scored.sort((a,b)=>b.score-a.score || a.v.global_number-b.v.global_number);
      const all=scored.slice(0,8).map(x=>x.v);
      const first=all[0];

      if(first){
        const tafsir=await loadTafsirSurah(first.surahNumber);
        const ayahTafsir=tafsir?.ayahs?.find(a=>Number(a.ayah_number)===first.number);
        const selected=(ayahTafsir?.tafsir||[])
          .filter(x=>x.text?.trim())
          .sort((a,b)=>tafsirPriority(a.type)-tafsirPriority(b.type))
          .slice(0,2);

        let evidence=selected.map(x=>`${x.type}: ${compactText(x.text,850)}`).join("\n\n");
        let hadithDetail="";

        if(ai?.intent==="hadith" || /حديث|السنه|الرسول|النبي|فضل|حكم/.test(normalizeArabic(t))){
          setThinkingStage("أراجع الحديث المرتبط…");
          const hadiths=await findHadithSupport(terms);
          if(hadiths.length){
            const h=hadiths[0];
            hadithDetail=`${h.book}${h.reference?` · ${h.reference}`:""}: ${compactText(h.arabic,700)}`;
            evidence += `\n\nحديث مرتبط: ${hadithDetail}`;
          }
        }

        if(!evidence){
          const candidate=terms[0];
          const row=(await loadRootSurah(first.surahNumber)).find(x=>x.k===first.verse_key);
          const idx=first.words.findIndex(w=>normalizeArabic(w.text).includes(candidate||""));
          const root=row?.words?.[Math.max(0,idx)]?.r;
          if(root&&mufradat[root]?.t)evidence=mufradat[root]!.t!;
        }

        setThinkingStage("أصيغ جوابًا مختصرًا…");
        const concise=await composeGroundedAnswer(
          t,
          evidence || `الآية الأقرب: ${cleanQuranDisplay(first.text)}`
        );

        const sabab=findAsbab(first.surahNumber,first.number);
        setAnswer({
          title:"الجواب المختصر",
          ayah:cleanQuranDisplay(first.text),
          ref:`سورة ${first.surahName} · الآية ${arNum(first.number)}`,
          meaning:concise || "وجدت موضعًا مرتبطًا بالسؤال، لكن المراجع المتاحة لا تكفي للجزم بجواب أوسع.",
          details:selected.length
            ? selected.map(x=>`${x.type}: ${compactText(x.text,700)}`).join("\n\n")+(hadithDetail?`\n\nحديث مرتبط: ${hadithDetail}`:"")
            : hadithDetail,
          context:all.length>1?`مواضع مرتبطة: ${all.slice(0,4).map(v=>`${v.surahName} ${arNum(v.number)}`).join(" · ")}`:"",
          sabab:sabab?.occasions?.[0] || "",
          source:selected.length
            ? `نص القرآن · ${selected.map(x=>x.type).join(" · ")}${hadithDetail?" · فهرس الحديث المحلي":""}`
            : `نص القرآن · مفردات الراغب${hadithDetail?" · فهرس الحديث المحلي":""}`
        });
        return;
      }

      // Hadith-only fallback.
      const hadiths=await findHadithSupport(terms);
      if(hadiths.length){
        const h=hadiths[0];
        setThinkingStage("أصيغ جوابًا مختصرًا…");
        const concise=await composeGroundedAnswer(t,h.arabic);
        setAnswer({
          title:"جواب من السنة",
          ayah:"",
          ref:"",
          meaning:concise || compactText(h.arabic,230),
          details:compactText(h.arabic,850),
          context:`${h.book}${h.reference?` · ${h.reference}`:""}${h.grade?` · الدرجة في المصدر: ${h.grade}`:""}`,
          sabab:"",
          source:"فهرس كتب الحديث المحلي داخل Noor"
        });
        return;
      }

      // Network fallback: verify Quran text only. No fabricated religious answer.
      setThinkingStage("أتحقق من وجود نص مرتبط…");
      const online=await onlineQuranVerify(terms[0]||normalizeArabic(t));
      if(online){
        setAnswer({
          title:"نتيجة تحقق نصي",
          ayah:cleanQuranDisplay(online.text),
          ref:`${online.surah}${online.number?` · الآية ${arNum(online.number)}`:""}`,
          meaning:"وجدت نصًا قرآنيًا مرتبطًا بالكلمة، لكن المراجع المحلية لم تعطِ جوابًا كافيًا على صياغة السؤال نفسها.",
          details:"",
          context:"",
          sabab:"",
          source:"Al Quran Cloud للتحقق النصي فقط · قاعدة Noor المحلية"
        });
        return;
      }

      setAnswer({
        title:"لا أريد التخمين",
        ayah:"",
        ref:"",
        meaning:"لم أجد في المراجع المتاحة دليلًا كافيًا لإجابة موثوقة على هذا السؤال بصيغته الحالية. جرّب صياغته بشكل أوضح أو اذكر السورة أو الموضوع.",
        details:"",
        context:"",
        sabab:"",
        source:"قاعدة Noor المحلية"
      });
    } finally {
      setThinking(false);
    }
  }

  const currentVerses=pages[readerPage]||[];
  const currentSurahs=[...new Map(currentVerses.map(v=>[v.surahNumber,v.surahName])).entries()];

  if(sirahPage){
    return <main className={dark?"app dark":"app"}>
      <div className="aurora a1"/><div className="aurora a2"/>
      <header>
        <div className="brand"><img className="logo topRightNoorLogo" src={NOOR_LOGO} alt="نور"/><div><b>نور</b><small>اسأل عن السيرة</small></div></div>
        <button className="icon glass" onClick={()=>setDark(!dark)} aria-label="تغيير المظهر">{dark?<Sun/>:<Moon/>}</button>
      </header>
      <section className="content sirahStandalone">
        <button className="sirahBack glass" onClick={()=>{setSirahPage(false);setAnswer(null);setQ("")}}><ChevronRight/> العودة</button>
        {!answer ? <div className="sirahHero">
          <img src={NOOR_LOGO} className="sirahPageLogo" alt="نور"/>
          <h1>اسأل عن السيرة</h1>
          <p>من صحيح البخاري وصحيح مسلم</p>
        </div> : <div className="answer pageEnter"><Glass className="answerCard">
          <div className="answerHead"><Sparkles/><div><small>إجابة موثقة من السنة</small><h2>{answer.title}</h2></div></div>
          <section className="answerSummary"><h3>الجواب</h3><p>{answer.meaning}</p></section>
          {answer.details&&<details className="referenceDetails"><summary>تفاصيل من المراجع</summary><p>{answer.details}</p></details>}
          <button className="source" onClick={()=>setSources(true)}><Info/> المصادر <ChevronLeft/></button>
        </Glass></div>}
        <div className="composer glass"><Search/><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!thinking&&submitSirah()} placeholder="اسأل عن السيرة…"/><button disabled={thinking} onClick={()=>submitSirah()}>{thinking?<span className="miniSpinner"/>:<Send/>}</button></div>
      </section>
      {thinking&&<div className="thinkingOverlay" role="status"><Glass className="thinkingCard"><div className="thinkingMark"><span/><span/><span/></div><h3>{thinkingStage}</h3><p>نور يراجع صحيح البخاري ومسلم.</p></Glass></div>}
      {sources&&<div className="modalWrap" onClick={()=>setSources(false)}><Glass className="sourcesModal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSources(false)}><X/></button><h2>المصادر</h2><p>صحيح البخاري · صحيح مسلم</p></Glass></div>}
    </main>
  }

  return <main className={dark?"app dark":"app"}>
    <div className="aurora a1"/><div className="aurora a2"/>

    {tab!=="quran" && <header>
      <div className="brand"><img className="logo topRightNoorLogo" src={NOOR_LOGO} alt="نور"/><div><b>نور</b><small>اسأل عن القرآن</small></div></div>
      <button className="icon glass" onClick={()=>setDark(!dark)} aria-label="تغيير المظهر">{dark?<Sun/>:<Moon/>}</button>
    </header>}

    <section className="content">
      {tab==="home" && <>
        {!answer ? <div className="hero">
          <button className="orb noorLogoOrb sirahLauncher" onClick={()=>{setSirahPage(true);setAnswer(null);setQ("");}} aria-label="فتح اسأل عن السيرة">
            <img src={NOOR_LOGO} alt="اسأل عن السيرة"/>
          </button>
          <h1 className="simpleTitle"><span>اسأل عن القرآن</span></h1>
          <div className="chips">{suggestions.map((s,i)=>
            <button className="chip glass" onClick={()=>submit(s)} key={s}>
              <span className="chipIcon">{i===0?<BookOpen/>:i===1?<Sparkles/>:i===2?<Quote/>:<BookOpen/>}</span>
              <span>{s}</span><ChevronLeft/>
            </button>)}
          </div>
        </div> :
        <div className="answer pageEnter">
          <button className="back glass" onClick={()=>{setAnswer(null);setQ("")}}><X/> سؤال جديد</button>
          <Glass className="answerCard">
            <div className="answerHead"><Sparkles/><div><small>إجابة موثقة ومختصرة</small><h2>{answer.title}</h2></div></div>
            <section className="answerSummary"><h3>الجواب</h3><p>{answer.meaning}</p></section>
            {answer.ayah && (answer.ayah.length>280
              ? <details className="ayah ayahDetails"><summary><Quote/> عرض الآية المرتبطة <small>{answer.ref}</small></summary><p>{answer.ayah}</p></details>
              : <div className="ayah"><Quote/><p>{answer.ayah}</p><small>{answer.ref}</small></div>)}
            {answer.details && <details className="referenceDetails"><summary>تفاصيل من المراجع</summary><p>{answer.details}</p></details>}
            {answer.context && <section className="compactSection"><h3>مرتبط أيضًا</h3><p>{answer.context}</p></section>}
            {answer.sabab && <section className="compactSection"><h3>سبب النزول</h3><p>{compactText(answer.sabab,360)}</p></section>}
            <button className="source" onClick={()=>setSources(true)}><Info/> المصادر <ChevronLeft/></button>
          </Glass>
        </div>}
        <div className="composer glass"><Search/><input value={q} onFocus={()=>document.documentElement.classList.add("keyboard-open")} onBlur={()=>window.setTimeout(()=>{const h=window.visualViewport?.height??window.innerHeight;if(window.innerHeight-h<100)document.documentElement.classList.remove("keyboard-open")},120)} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!thinking&&submit()} placeholder="اسأل عن القرآن…"/><button disabled={thinking} onClick={()=>submit()}>{thinking?<span className="miniSpinner"/>:<Send/>}</button></div>
      </>}

      {tab==="quran" && <div className="readerShell continuousReader pageEnter">
        <div className="readerToolbar glass continuousToolbar">
          <button className="surahPickerButton" onClick={()=>setSurahPicker(true)}><List/><span>اختر السورة</span></button>
          <div className="autoScrollControls" aria-label="التمرير التلقائي">
            <button onClick={()=>setAutoScrollSpeed(v=>Math.max(1,v-1))} aria-label="تقليل سرعة التمرير"><Minus/></button>
            <button className={autoScroll?"autoActive":""} onClick={()=>setAutoScroll(v=>!v)} aria-label={autoScroll?"إيقاف التمرير التلقائي":"تشغيل التمرير التلقائي"}>{autoScroll?<Pause/>:<Play/>}<span>{autoScroll?"إيقاف":"تلقائي"}</span></button>
            <button onClick={()=>setAutoScrollSpeed(v=>Math.min(6,v+1))} aria-label="زيادة سرعة التمرير"><Plus/></button>
            <small>{arNum(autoScrollSpeed)}</small>
          </div>
        </div>
        <div className="readerViewport continuousViewport" ref={readerRef} onScroll={onReaderScroll}>
          {(!quran || !readerMounted) && <div className="readerLoading">{dataError||"جاري تجهيز المصحف…"}</div>}
          {rootDownload.active && readerMounted && <div className="readerLoading rootLoadingNotice" role="status">جاري تجهيز البحث في الجذور… {arNum(rootDownload.done)} / {arNum(rootDownload.total)}</div>}
          {readerMounted && quran?.surahs.map(surah=>{
            const verses=surah.ayahs.map(v=>({...v,surahNumber:surah.number,surahName:surah.name_arabic} as ReaderVerse));
            // The dataset prefixes the basmala to the first ayah of every
            // surah except At-Tawbah. Keep Al-Fatihah intact, and show the
            // basmala as a separate heading for the remaining surahs.
            const separateBasmala=surah.number>1 && surah.number!==9;
            const basmalaWords=separateBasmala?verses[0]?.words.slice(0,4):[];
            return <section className="mushafSurah continuousSurah" id={`surah-${surah.number}`} key={surah.number}>
              <div className="surahBanner ornate">
                <span className="surahMeta">{surah.revelation?.type==="Meccan"?"مكية":"مدنية"}</span>
                <b>سورة {surah.name_arabic}</b>
                <span className="surahMeta">{arNum(surah.counts.ayahs)} آية</span>
              </div>
              {separateBasmala && basmalaWords?.length===4 && <div className="basmala" aria-label="بسم الله الرحمن الرحيم">
                {basmalaWords.map((w,wi)=><React.Fragment key={`basmala-${surah.number}-${wi}`}>
                  <WordSpan text={cleanQuranDisplay(w.text)} onLong={()=>openWord(verses[0],wi,w.text)}/>{wi<basmalaWords.length-1?' ':''}
                </React.Fragment>)}
              </div>}
              <div className="mushafText">
                {verses.map(v=><React.Fragment key={v.verse_key}>
                  {(separateBasmala && v===verses[0]?v.words.slice(4):v.words).map((w,wi)=><React.Fragment key={`${v.verse_key}-${wi}`}>
                    <WordSpan text={cleanQuranDisplay(w.text)} onLong={()=>openWord(v,wi,w.text)}/>{' '}
                  </React.Fragment>)}
                  <button className={`ayahNumber ${bookmarks.includes(v.verse_key)?"bookmarked":""}`} onClick={()=>toggleBookmark(v.verse_key)} aria-label={bookmarks.includes(v.verse_key)?"إزالة حفظ الآية":"حفظ الآية"}><span>{arNum(v.number)}</span></button>{' '}
                </React.Fragment>)}
              </div>
            </section>;
          })}
          <div className="readerBottomPad"/>
        </div>
      </div>}

      {tab==="saved" && <Glass className="page savedPage pageEnter">
        <Bookmark/><h2>المحفوظات</h2>
        {bookmarks.length===0?<p>اضغط رقم أي آية داخل المصحف لحفظها هنا.</p>:
          <div className="savedList">{bookmarks.map(k=>{
            const v=verseByKey.get(k); if(!v)return null;
            return <button key={k} onClick={()=>{goPage(v.page,false);setTab("quran")}}>
              <b>سورة {v.surahName} · {arNum(v.number)}</b><span>{cleanQuranDisplay(v.text)}</span>
            </button>;
          })}</div>}
      </Glass>}

      {tab==="settings" && <Glass className="page settingsPage pageEnter">
        <Settings/><h2>الإعدادات</h2>
        <div className="setting"><span>الوضع</span><button onClick={()=>setDark(!dark)}>{dark?"داكن":"فاتح"}</button></div>
        <div className="setting"><span>آخر صفحة</span><b>{arNum(readerPage)}</b></div>
        <div className="setting"><span>أزرار الصوت</span><b>تغيير صفحات المصحف في تطبيق Android</b></div>
        <div className="settingsEditor">
          <b>الذكاء السحابي · OpenRouter</b>
          <small>عند وجود الإنترنت يستخدم نور نموذج DeepSeek V4 Flash المجاني لفهم السؤال وصياغة الإجابة من مراجع نور. المفتاح يبقى محفوظًا على هذا الجهاز ولا يوضع داخل كود المشروع.</small>
          <input type="password" value={openRouterKey} onChange={e=>setOpenRouterKey(e.target.value)} placeholder="OpenRouter API Key · sk-or-v1-…" autoComplete="off"/>
          <div className="editorActions"><button onClick={()=>localStorage.setItem("noor_openrouter_key",openRouterKey.trim())}>حفظ المفتاح</button><button className="dangerSoft" onClick={()=>{setOpenRouterKey("");localStorage.removeItem("noor_openrouter_key")}}>حذف المفتاح</button></div>
          <small>النموذج الحالي: DeepSeek V4 Flash 0731 (Free). إذا لم يوجد مفتاح أو انقطع الإنترنت ينتقل نور تلقائيًا إلى Qwen المحلي إن كان مثبتًا، ثم إلى البحث المحلي.</small>
        </div>
        <div className="setting qwenSetting">
          <div className="qwenLabel">
            <span>Qwen المحلي · اختياري للأوفلاين</span>
            <small>{window.Android?`${qwenStatus}${qwenProgress>0&&qwenProgress<100?` · ${Math.round(qwenProgress)}%`:""}`:"متاح داخل تطبيق Android"}</small>
          </div>
          {window.Android && <div className="qwenActions">
            {!qwenReady
              ? <button onClick={()=>{setQwenStatus("بدء التنزيل…");window.Android?.startQwenDownload?.()}}>تنزيل Qwen</button>
              : <button className="dangerSoft" onClick={()=>{window.Android?.deleteQwenModel?.();setQwenReady(false);setQwenProgress(0);setQwenStatus("غير مثبت")}}>حذف النموذج</button>}
          </div>}
        </div>
        {window.Android && !qwenReady && <div className="qwenHint">Qwen3 1.7B Q4_K_M حجمه نحو 1.28 GB. أذكى في فهم العربية والأسئلة المركبة، ويستمر تنزيله في الخلفية عبر Android.</div>}
        <div className="settingsEditor">
          <b>برومبت الذكاء الاصطناعي</b>
          <small>هذه التعليمات تُستخدم مع OpenRouter وQwen عند فهم السؤال وصياغة الإجابة.</small>
          <textarea value={qwenInstruction} onChange={e=>setQwenInstruction(e.target.value)} rows={6}/>
          <div className="editorActions"><button onClick={()=>localStorage.setItem("noor_qwen_instruction",qwenInstruction)}>حفظ البرومبت</button><button onClick={()=>{setQwenInstruction(DEFAULT_QWEN_INSTRUCTION);localStorage.setItem("noor_qwen_instruction",DEFAULT_QWEN_INSTRUCTION)}}>استعادة الافتراضي</button></div>
        </div>
        <div className="settingsEditor">
          <b>مصادر ومراجع إضافية</b>
          <small>أضف نص مرجع موثوق. يبحث نور فيه محليًا ويضيف المقاطع المرتبطة بالسؤال إلى مراجع الذكاء الاصطناعي.</small>
          <input value={sourceTitle} onChange={e=>setSourceTitle(e.target.value)} placeholder="اسم المرجع"/>
          <textarea value={sourceContent} onChange={e=>setSourceContent(e.target.value)} rows={6} placeholder="الصق نص المرجع هنا…"/>
          <button onClick={()=>{if(!sourceTitle.trim()||!sourceContent.trim())return;const next=[...customSources,{id:String(Date.now()),title:sourceTitle.trim(),content:sourceContent.trim()}];setCustomSources(next);localStorage.setItem("noor_custom_sources",JSON.stringify(next));setSourceTitle("");setSourceContent("")}}>+ إضافة المرجع</button>
          {customSources.length>0&&<div className="customSourceList">{customSources.map(x=><div key={x.id}><span>{x.title}</span><button onClick={()=>{const next=customSources.filter(v=>v.id!==x.id);setCustomSources(next);localStorage.setItem("noor_custom_sources",JSON.stringify(next))}}>حذف</button></div>)}</div>}
        </div>
        <div className="setting"><span>العمل بدون إنترنت</span><b>القرآن والمعاني وأسباب النزول وحقائق شائعة محلية</b></div>
        <div className="credits">
          <b>المصادر</b>
          <p>نص القرآن: Tanzil عبر Quran Core Dataset. المعاني: مفردات الراغب. أسباب النزول: صحيح أسباب النزول. وعند نجاح Build تُضاف ثمانية تفاسير رئيسية وفهرس حديثي واسع للاستخدام دون إنترنت.</p>
        </div>
      </Glass>}
    </section>

    {thinking&&<div className="thinkingOverlay" role="status" aria-live="polite">
      <Glass className="thinkingCard">
        <div className="thinkingMark"><span/><span/><span/></div>
        <h3>{thinkingStage}</h3>
        <p>نور يراجع المراجع قبل عرض الإجابة.</p>
      </Glass>
    </div>}

    <nav className={`nav glass nav-${tab}`}>
      <span className="liquidSelection" aria-hidden="true"/>
      <button className={tab==="home"?"active":""} onClick={()=>setTab("home")}><Sparkles/><span>اسأل</span></button>
      <button className={tab==="quran"?"active":""} onClick={()=>setTab("quran")}><BookOpen/><span>القرآن</span></button>
      <button className={tab==="saved"?"active":""} onClick={()=>setTab("saved")}><Bookmark/><span>محفوظات</span></button>
      <button className={tab==="settings"?"active":""} onClick={()=>setTab("settings")}><Settings/><span>الإعدادات</span></button>
    </nav>

    {sources&&<div className="modal" onClick={()=>setSources(false)}>
      <Glass className="sheet" onClick={e=>e.stopPropagation()}><button onClick={()=>setSources(false)}><X/></button><h2>المصادر</h2><p>{answer?.source}</p></Glass>
    </div>}

    {wordInfo&&<div className="modal wordModal" onClick={()=>setWordInfo(null)}>
      <Glass className="sheet wordSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setWordInfo(null)}><X/></button>
        <small>ضغط مطول · {wordInfo.verseKey}</small>
        <h2>{wordInfo.text}</h2>
        {wordInfo.root&&<div className="rootBadge">الجذر: {wordInfo.root}</div>}
        <h3 className="wordSectionTitle">المعنى في هذه الآية</h3>
        <p className="wordDefinition">{wordInfo.contextMeaning}</p>
        {wordInfo.lexicalMeaning&&<details className="lexicalDetails"><summary>المعنى المعجمي للجذر</summary><p>{wordInfo.lexicalMeaning}</p></details>}
        {wordInfo.english&&<details><summary>مرجع لغوي إضافي</summary><p>{wordInfo.english}</p></details>}
        <small>المصدر: {wordInfo.source}</small>
      </Glass>
    </div>}

    {surahPicker&&<div className="modal" onClick={()=>setSurahPicker(false)}>
      <Glass className="sheet surahSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setSurahPicker(false)}><X/></button>
        <h2>السور</h2>
        <div className="surahList">{quran?.surahs.map(s=>
          <button key={s.number} onClick={()=>{setSurahPicker(false);requestAnimationFrame(()=>scrollToSurah(s.number))}}>
            <span>{arNum(s.number)}</span><b>{s.name_arabic}</b><small>{arNum(s.counts.ayahs)} آية</small>
          </button>)}
        </div>
      </Glass>
    </div>}
  </main>;
}

function WordSpan({text,onLong}:{text:string;onLong:()=>void}){
  const timer=useRef<number>(0);
  const origin=useRef<{x:number;y:number}|null>(null);
  const start=(e:React.PointerEvent<HTMLSpanElement>)=>{
    origin.current={x:e.clientX,y:e.clientY};
    clearTimeout(timer.current);
    timer.current=window.setTimeout(()=>{onLong(); if(navigator.vibrate)navigator.vibrate(18);},520);
  };
  const move=(e:React.PointerEvent<HTMLSpanElement>)=>{
    if(!origin.current)return;
    if(Math.hypot(e.clientX-origin.current.x,e.clientY-origin.current.y)>9){
      clearTimeout(timer.current); origin.current=null;
    }
  };
  const stop=()=>{clearTimeout(timer.current);origin.current=null};
  return <span className="qWord" onPointerDown={start} onPointerMove={move} onPointerUp={stop} onPointerCancel={stop} onPointerLeave={stop} onContextMenu={e=>e.preventDefault()}>{text}</span>;
}

createRoot(document.getElementById("root")!).render(<App/>);
