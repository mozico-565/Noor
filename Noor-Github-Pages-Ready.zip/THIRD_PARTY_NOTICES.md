# Third-party data notices

Noor bundles Quran and reference data for offline use.

- Quran Core Dataset by Mirza Iqbal: CC BY 4.0.
- Underlying Tanzil Uthmani Quran text and metadata: CC BY 3.0. Quran text is kept verbatim.
- Quran bil-Quran code/data packaging: MIT. Its morphology/root mapping cites the Quranic Arabic Corpus (GNU GPL); the root data is kept as a separate data asset and attribution is preserved.
- Al-Mufradat fi Gharib al-Quran: classical work by al-Raghib al-Isfahani, packaged in Quran bil-Quran.
- Asbab al-Nuzul Dataset by mostafaahmed97: MIT, based on "Sahih Asbab al-Nuzul" by Ibrahim Muhammad al-Ali.

Do not remove these notices when redistributing the app.


## Additional optional offline reference layers

- `meibassam/mosahaf-tafseer`: aggregated JSON reference layer containing eight Arabic tafsir sources. The upstream README describes it as an automated compilation from public sources and recommends cross-checking in sensitive contexts. Noor stores compact excerpts for retrieval, not a substitute for printed critical editions.
- `AhmedBaset/hadith-json`: ISC-licensed project code/database packaging with 17 hadith collections. The upstream project documents known data limitations. Noor uses it as a retrieval index and displays the named book/reference when present.
- Al Quran Cloud: network fallback for Quran text search verification only when a connection is available.

Noor should not present an inferred answer as a quotation from a source unless the text is actually present in the bundled reference data.


## Qwen and llama.cpp
- Qwen3-1.7B Q4_K_M is downloaded by the user on-device from the
  MaziyarPanahi/Qwen3-1.7B-GGUF Hugging Face repository.
- The local runtime is built from ggml-org/llama.cpp during GitHub Actions.
- Noor uses Qwen only as a natural-language intent parser. It is not cited as
  a source for Quran, hadith, tafsir, or religious rulings.
