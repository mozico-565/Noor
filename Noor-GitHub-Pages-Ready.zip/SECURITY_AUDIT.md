# Noor security audit

- No embedded OpenRouter/API secrets found. On Android, a user-supplied OpenRouter key is persisted in private app SharedPreferences rather than Web localStorage; a production shared key must live behind a server-side proxy, never in APK/JS.
- Android release build: debug disabled, code/resource shrinking enabled, cleartext HTTP disabled, backups disabled.
- WebView assets are served from the private appassets origin; path traversal is rejected; external navigation leaves the WebView.
- CSP and referrer policy added to the web entry point. React rendering is used; no dangerouslySetInnerHTML/innerHTML/eval usage found.
- Custom source forms have length limits and control-character sanitization. React escapes rendered text.
- Client AI throttling added (30/hour, >=1.5s between calls). This is abuse protection only; authoritative rate limiting belongs on the future server-side AI proxy.
- Location is requested only when automatic iqama is enabled. Coordinates stay in private SharedPreferences and prayer times are calculated locally.
- No authentication, password database, admin routes, application database, or first-party server API exists in this project, so password hashing/admin-route/DB-row-policy checks are not applicable.
- No .env, private key, keystore, or obvious credential files found in the project archive.
- Dependencies kept minimal. Adhan Java 1.2.1 added for local prayer-time calculation. Existing React/Vite/WorkManager dependencies retained because they are used.
- CORS: Noor has no first-party server API. Browser calls to OpenRouter are governed by OpenRouter CORS. A shared production key must use a backend with an explicit origin allowlist.
