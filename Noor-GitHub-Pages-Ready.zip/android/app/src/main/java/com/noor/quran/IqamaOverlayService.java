package com.noor.quran;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class IqamaOverlayService extends Service {
  private WindowManager wm; private LinearLayout card; private CountDownTimer timer;
  private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
  @Override public int onStartCommand(Intent in,int flags,int id){
    if(android.os.Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel("iqama_countdown","تنبيه الإقامة",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch); }
    Notification.Builder nb=android.os.Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"iqama_countdown"):new Notification.Builder(this);
    nb.setContentTitle("نور · تنبيه الإقامة").setContentText("العد التنازلي للإقامة ظاهر الآن").setSmallIcon(com.noor.quran.R.drawable.ic_noor).setOngoing(true);
    startForeground(4201,nb.build());
    if(!Settings.canDrawOverlays(this)){ stopSelf(); return START_NOT_STICKY; }
    String prayer=in.getStringExtra("prayer"); long iqama=in.getLongExtra("iqamaAt",0); boolean dark=in.getBooleanExtra("dark",false);
    long left=iqama-System.currentTimeMillis(); if(left<=0||left>5*60_000L+30_000L){stopSelf();return START_NOT_STICKY;}
    wm=(WindowManager)getSystemService(WINDOW_SERVICE); if(card!=null) try{wm.removeView(card);}catch(Exception ignored){}
    card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(22),dp(18),dp(22),dp(18));
    GradientDrawable bg=new GradientDrawable(); bg.setCornerRadius(dp(28)); bg.setColor(dark?0xCC12201B:0xDDF4F7F5); bg.setStroke(dp(1),dark?0x55FFFFFF:0x66FFFFFF); card.setBackground(bg); card.setElevation(dp(16));
    TextView title=new TextView(this); title.setText("إقامة صلاة "+prayer+" بعد"); title.setTextSize(17); title.setTextColor(dark?Color.WHITE:0xFF18352A); title.setGravity(Gravity.CENTER);
    TextView time=new TextView(this); time.setTextSize(34); time.setTextColor(0xFFE33A3A); time.setGravity(Gravity.CENTER); time.setPadding(0,dp(7),0,0);
    card.addView(title); card.addView(time);
    WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(300),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); lp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL; lp.y=dp(72);
    wm.addView(card,lp);
    timer=new CountDownTimer(left,1000){ public void onTick(long ms){ long sec=(ms+999)/1000; time.setText(String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60)); } public void onFinish(){ stopSelf(); }}; timer.start();
    return START_NOT_STICKY;
  }
  @Override public void onDestroy(){ if(timer!=null)timer.cancel(); if(card!=null&&wm!=null)try{wm.removeView(card);}catch(Exception ignored){} card=null; super.onDestroy(); }
  @Override public IBinder onBind(Intent i){return null;}
}
