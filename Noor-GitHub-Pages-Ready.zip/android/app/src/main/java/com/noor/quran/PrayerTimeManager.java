package com.noor.quran;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import com.batoulapps.adhan.CalculationMethod;
import com.batoulapps.adhan.CalculationParameters;
import com.batoulapps.adhan.Coordinates;
import com.batoulapps.adhan.DateComponents;
import com.batoulapps.adhan.PrayerTimes;
import java.util.Calendar;
import java.util.Date;

/** Calculates prayer times locally. Coordinates are stored privately after a user-granted precise location request. */
public final class PrayerTimeManager {
    private PrayerTimeManager() {}

    public static void saveLocationAndSchedule(Context c, Location loc, boolean dark) {
        SharedPreferences p=c.getSharedPreferences("noor",Context.MODE_PRIVATE);
        p.edit().putLong("prayer_lat",Double.doubleToRawLongBits(loc.getLatitude()))
          .putLong("prayer_lon",Double.doubleToRawLongBits(loc.getLongitude()))
          .putBoolean("prayer_location_saved",true).putBoolean("iqama_dark",dark).apply();
        scheduleFromSavedLocation(c);
    }

    public static void scheduleFromSavedLocation(Context c) {
        SharedPreferences p=c.getSharedPreferences("noor",Context.MODE_PRIVATE);
        if(!p.getBoolean("iqama_auto_enabled",false)||!p.getBoolean("prayer_location_saved",false)) return;
        double lat=Double.longBitsToDouble(p.getLong("prayer_lat",0));
        double lon=Double.longBitsToDouble(p.getLong("prayer_lon",0));
        boolean dark=p.getBoolean("iqama_dark",false);
        schedule(c,lat,lon,dark);
    }

    private static void schedule(Context c,double lat,double lon,boolean dark) {
        Coordinates coordinates=new Coordinates(lat,lon);
        CalculationParameters params=CalculationMethod.UMM_AL_QURA.getParameters();
        Calendar cal=Calendar.getInstance();
        for(int day=0;day<3;day++) {
            Calendar d=(Calendar)cal.clone(); d.add(Calendar.DAY_OF_YEAR,day);
            DateComponents dc=new DateComponents(d.get(Calendar.YEAR),d.get(Calendar.MONTH)+1,d.get(Calendar.DAY_OF_MONTH));
            PrayerTimes pt=new PrayerTimes(coordinates,dc,params);
            schedulePrayer(c,"الفجر",pt.fajr,25,dark,day*10+1);
            schedulePrayer(c,"الظهر",pt.dhuhr,20,dark,day*10+2);
            schedulePrayer(c,"العصر",pt.asr,20,dark,day*10+3);
            schedulePrayer(c,"المغرب",pt.maghrib,10,dark,day*10+4);
            schedulePrayer(c,"العشاء",pt.isha,20,dark,day*10+5);
        }
    }

    private static void schedulePrayer(Context c,String name,Date adhan,int offset,boolean dark,int code) {
        if(adhan==null)return;
        IqamaScheduler.scheduleAbsolute(c,name,adhan.getTime()+offset*60_000L,dark,9000+code);
    }
}
