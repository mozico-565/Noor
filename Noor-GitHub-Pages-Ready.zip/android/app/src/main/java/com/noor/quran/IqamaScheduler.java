package com.noor.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public final class IqamaScheduler {
    private IqamaScheduler() {}
    public static void scheduleAbsolute(Context c, String prayer, long iqamaAt, boolean dark, int requestCode) {
        long showAt=iqamaAt-5L*60_000L; if(showAt<=System.currentTimeMillis())return;
        Intent i=new Intent(c,IqamaAlarmReceiver.class).putExtra("prayer",prayer).putExtra("iqamaAt",iqamaAt).putExtra("dark",dark);
        PendingIntent pi=PendingIntent.getBroadcast(c,requestCode,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,showAt,pi);
        else if(Build.VERSION.SDK_INT<31)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,showAt,pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,showAt,pi);
    }
    public static void saveTemplates(Context c,String json)throws Exception{
        new JSONArray(json); c.getSharedPreferences("noor",Context.MODE_PRIVATE).edit().putString("iqama_templates",json).apply(); reschedule(c);
    }
    public static void reschedule(Context c){
        try{
            JSONArray a=new JSONArray(c.getSharedPreferences("noor",Context.MODE_PRIVATE).getString("iqama_templates","[]"));
            Calendar base=Calendar.getInstance();
            for(int day=0;day<2;day++) for(int n=0;n<a.length();n++){
                JSONObject o=a.getJSONObject(n); String[] hm=o.getString("time").split(":");
                Calendar cal=(Calendar)base.clone(); cal.add(Calendar.DAY_OF_YEAR,day); cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hm[0]));cal.set(Calendar.MINUTE,Integer.parseInt(hm[1]));cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
                long iqama=cal.getTimeInMillis()+o.optInt("offset",20)*60_000L;
                scheduleAbsolute(c,o.getString("prayer"),iqama,o.optBoolean("dark",false),7000+day*10+n);
            }
        }catch(Exception ignored){}
    }
}
