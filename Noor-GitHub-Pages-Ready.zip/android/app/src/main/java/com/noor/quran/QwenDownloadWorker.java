package com.noor.quran;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;

public class QwenDownloadWorker extends Worker {
    public static final String CHANNEL="qwen_download";
    public static final String FILENAME="Qwen_Qwen3-0.6B-Q4_K_M.gguf";
    public static final String URL="https://huggingface.co/bartowski/Qwen_Qwen3-0.6B-GGUF/resolve/main/"+FILENAME+"?download=true";
    public static final String SHA="9acfc1e001311f34b4252001b626f2e466d592a42065f66571bff3790d4e1b14";
    public static final long MIN=450_000_000L;
    public QwenDownloadWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    private File target(){File d=new File(getApplicationContext().getFilesDir(),"models"); d.mkdirs(); return new File(d,FILENAME);}
    private void channel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE); n.createNotificationChannel(new NotificationChannel(CHANNEL,"تنزيل Qwen",NotificationManager.IMPORTANCE_LOW));}}
    private ForegroundInfo fg(int pct,String text){channel(); return new ForegroundInfo(731,new NotificationCompat.Builder(getApplicationContext(),CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("نور · تنزيل Qwen").setContentText(text).setOnlyAlertOnce(true).setOngoing(pct<100).setProgress(100,pct,false).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);}
    private void progress(int pct,String status){setProgressAsync(new Data.Builder().putInt("percent",pct).putString("status",status).build()); setForegroundAsync(fg(pct,status));}
    private static String sha(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256"); try(InputStream in=new FileInputStream(f)){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:d.digest())s.append(String.format("%02x",b));return s.toString();}
    @NonNull @Override public Result doWork(){
        File dst=target(), part=new File(dst.getParentFile(),dst.getName()+".part");
        if(dst.exists()&&dst.length()>=MIN)return Result.success(new Data.Builder().putInt("percent",100).putString("status","جاهز للعمل دون إنترنت").build());
        HttpURLConnection c=null;
        try{
            long existing=part.exists()?part.length():0; progress((int)Math.min(95,existing/5_000_000L),existing>0?"استكمال تنزيل Qwen…":"بدء تنزيل Qwen…");
            c=(HttpURLConnection)new URL(URL).openConnection(); c.setConnectTimeout(20000); c.setReadTimeout(45000); c.setInstanceFollowRedirects(true); c.setRequestProperty("User-Agent","Noor-Quran-Android/1.2");
            if(existing>0)c.setRequestProperty("Range","bytes="+existing+"-"); c.connect(); int code=c.getResponseCode();
            boolean resume=existing>0&&code==206; if(code<200||code>=300)throw new IOException("HTTP "+code); if(existing>0&&!resume){part.delete();existing=0;}
            long remaining=c.getContentLengthLong(), total=remaining>0?existing+remaining:0, done=existing; int last=-1;
            try(InputStream in=c.getInputStream(); FileOutputStream out=new FileOutputStream(part,resume)){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0){if(isStopped())return Result.retry();out.write(b,0,n);done+=n;int pct=total>0?(int)Math.min(99,done*100L/total):(int)Math.min(99,done/5_000_000L);if(pct!=last){last=pct;progress(pct,"تنزيل Qwen · "+pct+"%");}}}
            progress(99,"التحقق من النموذج…"); if(part.length()<MIN)throw new IOException("الملف غير مكتمل"); if(!SHA.equalsIgnoreCase(sha(part)))throw new IOException("فشل التحقق من سلامة الملف"); if(dst.exists())dst.delete(); if(!part.renameTo(dst))throw new IOException("تعذر تثبيت النموذج");
            progress(100,"جاهز للعمل دون إنترنت"); return Result.success(new Data.Builder().putInt("percent",100).putString("status","جاهز للعمل دون إنترنت").build());
        }catch(Throwable e){return Result.failure(new Data.Builder().putString("status","فشل التنزيل: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage())).build());}finally{if(c!=null)c.disconnect();}
    }
}
