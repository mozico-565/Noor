package com.noor.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;
import androidx.work.*;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_PREFIX = "/assets/";

    private static final String QWEN_FILENAME = "Qwen_Qwen3-0.6B-Q4_K_M.gguf";
    private static final String QWEN_URL =
            "https://huggingface.co/bartowski/Qwen_Qwen3-0.6B-GGUF/resolve/main/" +
            QWEN_FILENAME + "?download=true";
    private static final String QWEN_SHA256 =
            "9acfc1e001311f34b4252001b626f2e466d592a42065f66571bff3790d4e1b14";
    private static final long QWEN_MIN_BYTES = 450_000_000L;

    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();

    private static native String nativeInfer(String modelPath, String prompt, int maxTokens);
    private static native void nativeUnloadQwen();

    static {
        try {
            System.loadLibrary("noor_qwen");
        } catch (Throwable ignored) {}
    }

    private WebView webView;
    private boolean readerActive = false;
    private SharedPreferences prefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        prefs = getSharedPreferences("noor", MODE_PRIVATE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(232, 238, 233));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        /*
         * Noor used to open index.html through file:///android_asset/.
         * Modern Android WebView blocks fetch() from a file:// page in several
         * configurations, which caused the Quran JSON to fail even though it
         * was correctly bundled inside the APK.
         *
         * The app now exposes packaged assets through a private HTTPS-style
         * origin and serves them directly from Android assets below.
         * Relative fetch("./data/quran.json") is therefore same-origin and
         * works completely offline.
         */
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if ("https".equals(uri.getScheme())
                        && APP_HOST.equals(uri.getHost())
                        && uri.getPath() != null
                        && uri.getPath().startsWith(APP_PREFIX)) {

                    String assetPath = uri.getPath().substring(APP_PREFIX.length());

                    // Do not allow path traversal.
                    if (assetPath.contains("..")) {
                        return new WebResourceResponse(
                                "text/plain", "UTF-8", 403, "Forbidden",
                                null, new java.io.ByteArrayInputStream(new byte[0]));
                    }

                    try {
                        InputStream stream = getAssets().open(assetPath);
                        return new WebResourceResponse(
                                mimeType(assetPath), "UTF-8", stream);
                    } catch (IOException ignored) {
                        return null;
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if (APP_HOST.equals(uri.getHost())) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.addJavascriptInterface(new NoorBridge(), "Android");
        setContentView(webView);

        // Private local origin. No internet connection is required.
        webView.loadUrl(
                "https://" + APP_HOST + "/assets/www/index.html"
        );
    }

    private String mimeType(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    private File qwenFile() {
        File dir = new File(getFilesDir(), "models");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, QWEN_FILENAME);
    }

    private void evalJs(String js) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void emitQwenProgress(int percent, String status) {
        evalJs("window.noorQwenProgress&&window.noorQwenProgress(" +
                percent + "," + JSONObject.quote(status) + ")");
    }

    private void emitQwenResult(String id, String result, String error) {
        evalJs("window.noorQwenResult&&window.noorQwenResult(" +
                JSONObject.quote(id) + "," +
                JSONObject.quote(result == null ? "" : result) + "," +
                JSONObject.quote(error == null ? "" : error) + ")");
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) digest.update(buffer, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : digest.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (readerActive && event.getRepeatCount() == 0) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(1)", null);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(-1)", null);
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onDestroy() {
        aiExecutor.shutdownNow();
        try { nativeUnloadQwen(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    public class NoorBridge {
        @JavascriptInterface
        public void setReaderActive(boolean active) {
            readerActive = active;
        }

        @JavascriptInterface
        public void saveReaderPage(int page) {
            prefs.edit().putInt("reader_page", page).apply();
        }

        @JavascriptInterface
        public int getReaderPage() {
            return prefs.getInt("reader_page", 1);
        }

        @JavascriptInterface
        public boolean isQwenReady() {
            File f = qwenFile();
            return f.exists() && f.length() >= QWEN_MIN_BYTES;
        }

        @JavascriptInterface
        public long qwenModelSize() {
            File f = qwenFile();
            return f.exists() ? f.length() : 0L;
        }

        @JavascriptInterface
        public void startQwenDownload() {
            if (isQwenReady()) { emitQwenProgress(100, "جاهز للعمل دون إنترنت"); return; }
            OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(QwenDownloadWorker.class)
                    .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build();
            WorkManager wm=WorkManager.getInstance(MainActivity.this);
            wm.enqueueUniqueWork("noor_qwen_download", ExistingWorkPolicy.KEEP, req);
            aiExecutor.submit(() -> {
                try {
                    while (true) {
                        java.util.List<WorkInfo> infos=wm.getWorkInfosForUniqueWork("noor_qwen_download").get();
                        if(infos==null||infos.isEmpty())break; WorkInfo info=infos.get(0);
                        Data d=info.getProgress(); int pct=d.getInt("percent",0); String st=d.getString("status");
                        if(st!=null)emitQwenProgress(pct,st);
                        if(info.getState().isFinished()){
                            if(info.getState()==WorkInfo.State.SUCCEEDED)emitQwenProgress(100,"جاهز للعمل دون إنترنت");
                            else {String e=info.getOutputData().getString("status");emitQwenProgress(0,e==null?"فشل التنزيل":e);}
                            break;
                        }
                        Thread.sleep(900);
                    }
                } catch(Throwable ignored) {}
            });
        }

        @JavascriptInterface
        public void deleteQwenModel() {
            WorkManager.getInstance(MainActivity.this).cancelUniqueWork("noor_qwen_download");
            aiExecutor.submit(() -> {
                try { nativeUnloadQwen(); } catch (Throwable ignored) {}
                File f = qwenFile();
                File p = new File(f.getParentFile(), f.getName() + ".part");
                if (f.exists()) f.delete();
                if (p.exists()) p.delete();
                emitQwenProgress(0, "غير مثبت");
            });
        }

        @JavascriptInterface
        public void qwenInfer(String requestId, String prompt) {
            if (!isQwenReady()) {
                emitQwenResult(requestId, "", "Qwen model is not installed");
                return;
            }

            aiExecutor.submit(() -> {
                try {
                    String result = nativeInfer(
                            qwenFile().getAbsolutePath(),
                            prompt,
                            112
                    );
                    if (result == null || result.trim().isEmpty()) {
                        emitQwenResult(requestId, "", "Qwen returned no result");
                    } else {
                        emitQwenResult(requestId, result, "");
                    }
                } catch (Throwable e) {
                    emitQwenResult(requestId, "", "Qwen inference failed");
                }
            });
        }

        @JavascriptInterface
        public void setSystemBarsDark(boolean dark) {
            runOnUiThread(() -> {
                int c = dark
                        ? Color.rgb(6, 17, 13)
                        : Color.rgb(232, 238, 233);

                getWindow().setStatusBarColor(c);
                getWindow().setNavigationBarColor(c);
                getWindow().getDecorView().setBackgroundColor(c);
                if (webView != null) webView.setBackgroundColor(c);
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    getWindow().setNavigationBarDividerColor(c);
                }

                int flags = getWindow()
                        .getDecorView()
                        .getSystemUiVisibility();

                if (dark) {
                    flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else {
                    flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }

                getWindow()
                        .getDecorView()
                        .setSystemUiVisibility(flags);
            });
        }
    }
}
