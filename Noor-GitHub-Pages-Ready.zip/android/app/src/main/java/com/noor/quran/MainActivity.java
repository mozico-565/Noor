package com.noor.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean readerActive = false;
    private SharedPreferences prefs;

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("noor", MODE_PRIVATE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(232,238,233));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.addJavascriptInterface(new NoorBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (readerActive && event.getRepeatCount()==0) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                webView.evaluateJavascript("window.noorVolumePage&&window.noorVolumePage(1)", null);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                webView.evaluateJavascript("window.noorVolumePage&&window.noorVolumePage(-1)", null);
                return true;
            }
        }
        return super.onKeyDown(keyCode,event);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class NoorBridge {
        @JavascriptInterface public void setReaderActive(boolean active) { readerActive = active; }
        @JavascriptInterface public void saveReaderPage(int page) { prefs.edit().putInt("reader_page", page).apply(); }
        @JavascriptInterface public int getReaderPage() { return prefs.getInt("reader_page", 1); }
        @JavascriptInterface public void setSystemBarsDark(boolean dark) {
            runOnUiThread(() -> {
                int c = dark ? Color.rgb(6,17,13) : Color.rgb(232,238,233);
                getWindow().setStatusBarColor(c);
                getWindow().setNavigationBarColor(c);
                int flags = getWindow().getDecorView().getSystemUiVisibility();
                if (dark) flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                getWindow().getDecorView().setSystemUiVisibility(flags);
            });
        }
    }
}
