package com.noor.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.database.Cursor;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.app.AlarmManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.CancellationSignal;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_PREFIX = "/assets/";

    private static final String QWEN_FILENAME = "Qwen3-1.7B.Q4_K_M.gguf";
    private static final String QWEN_URL =
            "https://huggingface.co/MaziyarPanahi/Qwen3-1.7B-GGUF/resolve/main/" +
            QWEN_FILENAME + "?download=true";
    private static final String QWEN_SHA256 =
            "ea2aa5f1cce3c8df81ae5fd292a6ed265b8393cc89534dc21fc5327cc974116a";
    private static final long QWEN_MIN_BYTES = 1_200_000_000L;

    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();

    private static native String nativeInfer(String modelPath, String prompt, int maxTokens);
    private static native void nativeUnloadQwen();

    static {
        try {
            System.loadLibrary("noor_qwen");
        } catch (Throwable ignored) {}
    }

    private WebView webView;
    private boolean readerActive = false;
    private SharedPreferences prefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        prefs = getSharedPreferences("noor", MODE_PRIVATE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(232, 238, 233));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        if (android.os.Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (android.os.Build.VERSION.SDK_INT >= 26) WebView.setSafeBrowsingWhitelist(java.util.Collections.emptyList(), null);

        /*
         * Noor used to open index.html through file:///android_asset/.
         * Modern Android WebView blocks fetch() from a file:// page in several
         * configurations, which caused the Quran JSON to fail even though it
         * was correctly bundled inside the APK.
         *
         * The app now exposes packaged assets through a private HTTPS-style
         * origin and serves them directly from Android assets below.
         * Relative fetch("./data/quran.json") is therefore same-origin and
         * works completely offline.
         */
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if ("https".equals(uri.getScheme())
                        && APP_HOST.equals(uri.getHost())
                        && uri.getPath() != null
                        && uri.getPath().startsWith(APP_PREFIX)) {

                    String assetPath = uri.getPath().substring(APP_PREFIX.length());

                    // Do not allow path traversal.
                    if (assetPath.contains("..")) {
                        return new WebResourceResponse(
                                "text/plain", "UTF-8", 403, "Forbidden",
                                null, new java.io.ByteArrayInputStream(new byte[0]));
                    }

                    try {
                        InputStream stream = getAssets().open(assetPath);
                        return new WebResourceResponse(
                                mimeType(assetPath), "UTF-8", stream);
                    } catch (IOException ignored) {
                        return null;
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if (APP_HOST.equals(uri.getHost())) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.addJavascriptInterface(new NoorBridge(), "Android");
        setContentView(webView);

        // Private local origin. No internet connection is required.
        webView.loadUrl(
                "https://" + APP_HOST + "/assets/www/index.html"
        );
    }

    private String mimeType(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    private File qwenFile() {
        File dir = getExternalFilesDir("models");
        if (dir == null) dir = new File(getFilesDir(), "models");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, QWEN_FILENAME);
    }

    private void watchSystemDownload(long id) {
        aiExecutor.submit(() -> {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            while (true) {
                try (Cursor c = dm.query(new DownloadManager.Query().setFilterById(id))) {
                    if (c == null || !c.moveToFirst()) { emitQwenProgress(0, "تعذر العثور على التنزيل"); break; }
                    int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    long total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    int pct = total > 0 ? (int)Math.min(99, done * 100L / total) : 0;
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        prefs.edit().remove("qwen_download_id").apply();
                        if (qwenFile().exists() && qwenFile().length() >= QWEN_MIN_BYTES) emitQwenProgress(100, "جاهز للعمل دون إنترنت");
                        else emitQwenProgress(0, "اكتمل التنزيل لكن الملف غير صالح");
                        break;
                    }
                    if (status == DownloadManager.STATUS_FAILED) {
                        int reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                        prefs.edit().remove("qwen_download_id").apply();
                        emitQwenProgress(0, "فشل التنزيل (" + reason + ") · اضغط للمحاولة مجددًا");
                        break;
                    }
                    emitQwenProgress(pct, status == DownloadManager.STATUS_PAUSED ? "التنزيل متوقف مؤقتًا · سيستأنف تلقائيًا" : "تنزيل Qwen · " + pct + "%");
                } catch (Throwable e) { break; }
                try { Thread.sleep(1200); } catch (InterruptedException e) { break; }
            }
        });
    }

    private void evalJs(String js) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void emitQwenProgress(int percent, String status) {
        evalJs("window.noorQwenProgress&&window.noorQwenProgress(" +
                percent + "," + JSONObject.quote(status) + ")");
    }

    private void emitQwenResult(String id, String result, String error) {
        evalJs("window.noorQwenResult&&window.noorQwenResult(" +
                JSONObject.quote(id) + "," +
                JSONObject.quote(result == null ? "" : result) + "," +
                JSONObject.quote(error == null ? "" : error) + ")");
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) digest.update(buffer, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : digest.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (readerActive && event.getRepeatCount() == 0) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(1)", null);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(-1)", null);
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onDestroy() {
        aiExecutor.shutdownNow();
        try { nativeUnloadQwen(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private static final int LOCATION_REQ=4412;

    private void requestPrayerLocation(boolean dark) {
        prefs.edit().putBoolean("iqama_dark",dark).putBoolean("iqama_auto_enabled",true).apply();
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_REQ);
            return;
        }
        acquirePrayerLocation();
    }

    @SuppressLint("MissingPermission")
    private void acquirePrayerLocation() {
        LocationManager lm=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if(lm==null)return;
        if(android.os.Build.VERSION.SDK_INT>=30){
            String provider=lm.isProviderEnabled(LocationManager.GPS_PROVIDER)?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;
            lm.getCurrentLocation(provider,new CancellationSignal(),getMainExecutor(),loc->{ if(loc!=null) PrayerTimeManager.saveLocationAndSchedule(this,loc,prefs.getBoolean("iqama_dark",false)); });
        } else {
            Location loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(loc==null)loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(loc!=null)PrayerTimeManager.saveLocationAndSchedule(this,loc,prefs.getBoolean("iqama_dark",false));
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==LOCATION_REQ && grantResults.length>0 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) acquirePrayerLocation();
    }

    public class NoorBridge {
        @JavascriptInterface
        public void setReaderActive(boolean active) {
            readerActive = active;
        }

        @JavascriptInterface
        public void saveOpenRouterKey(String key) {
            String v=key==null?"":key.trim();
            if(v.length()>300)v=v.substring(0,300);
            prefs.edit().putString("openrouter_user_key",v).apply();
        }

        @JavascriptInterface
        public String getOpenRouterKey() { return prefs.getString("openrouter_user_key",""); }

        @JavascriptInterface
        public void saveReaderPage(int page) {
            prefs.edit().putInt("reader_page", page).apply();
        }

        @JavascriptInterface
        public int getReaderPage() {
            return prefs.getInt("reader_page", 1);
        }

        @JavascriptInterface
        public boolean isQwenReady() {
            File f = qwenFile();
            return f.exists() && f.length() >= QWEN_MIN_BYTES;
        }

        @JavascriptInterface
        public long qwenModelSize() {
            File f = qwenFile();
            return f.exists() ? f.length() : 0L;
        }

        @JavascriptInterface
        public void startQwenDownload() {
            if (isQwenReady()) { emitQwenProgress(100, "جاهز للعمل دون إنترنت"); return; }
            try {
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                long oldId = prefs.getLong("qwen_download_id", -1L);
                if (oldId > 0) { watchSystemDownload(oldId); emitQwenProgress(0, "التنزيل يعمل في الخلفية…"); return; }
                File f = qwenFile();
                if (f.exists()) f.delete();
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(QWEN_URL))
                        .setTitle("نور · تنزيل Qwen")
                        .setDescription("يمكنك إغلاق نور، وسيستمر التنزيل في الخلفية")
                        .setAllowedOverMetered(true)
                        .setAllowedOverRoaming(false)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalFilesDir(MainActivity.this, "models", QWEN_FILENAME);
                long id = dm.enqueue(r);
                prefs.edit().putLong("qwen_download_id", id).apply();
                emitQwenProgress(0, "بدأ التنزيل في الخلفية · يمكنك الخروج من التطبيق");
                watchSystemDownload(id);
            } catch (Throwable e) {
                emitQwenProgress(0, "تعذر بدء التنزيل: " + (e.getMessage()==null?"خطأ Android":e.getMessage()));
            }
        }

        @JavascriptInterface
        public void deleteQwenModel() {
            long id = prefs.getLong("qwen_download_id", -1L);
            if (id > 0) {
                try { ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).remove(id); } catch (Throwable ignored) {}
                prefs.edit().remove("qwen_download_id").apply();
            }
            aiExecutor.submit(() -> {
                try { nativeUnloadQwen(); } catch (Throwable ignored) {}
                File f = qwenFile();
                File p = new File(f.getParentFile(), f.getName() + ".part");
                if (f.exists()) f.delete();
                if (p.exists()) p.delete();
                emitQwenProgress(0, "غير مثبت");
            });
        }

        @JavascriptInterface
        public void qwenInfer(String requestId, String prompt) {
            if (!isQwenReady()) {
                emitQwenResult(requestId, "", "Qwen model is not installed");
                return;
            }

            aiExecutor.submit(() -> {
                try {
                    String result = nativeInfer(
                            qwenFile().getAbsolutePath(),
                            prompt,
                            112
                    );
                    if (result == null || result.trim().isEmpty()) {
                        emitQwenResult(requestId, "", "Qwen returned no result");
                    } else {
                        emitQwenResult(requestId, result, "");
                    }
                } catch (Throwable e) {
                    emitQwenResult(requestId, "", "Qwen inference failed");
                }
            });
        }

        @JavascriptInterface
        public void enableAutomaticIqama(boolean enabled, boolean dark) {
            prefs.edit().putBoolean("iqama_auto_enabled",enabled).putBoolean("iqama_dark",dark).apply();
            if(enabled) runOnUiThread(() -> requestPrayerLocation(dark));
        }

        @JavascriptInterface
        public boolean hasPrayerLocation() { return prefs.getBoolean("prayer_location_saved",false); }

        @JavascriptInterface
        public boolean canDrawIqamaOverlay() { return Settings.canDrawOverlays(MainActivity.this); }

        @JavascriptInterface
        public void requestIqamaOverlayPermission() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Throwable ignored) {}
            });
        }

        @JavascriptInterface
        public void requestExactAlarmPermission() {
            if (android.os.Build.VERSION.SDK_INT >= 31) runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); } catch (Throwable ignored) {}
            });
        }

        @JavascriptInterface
        public void setIqamaSchedule(String json) {
            try { IqamaScheduler.saveTemplates(MainActivity.this, json); } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void previewIqamaOverlay(String prayer, boolean dark) {
            if (!Settings.canDrawOverlays(MainActivity.this)) { requestIqamaOverlayPermission(); return; }
            Intent i=new Intent(MainActivity.this,IqamaOverlayService.class).putExtra("prayer",prayer).putExtra("iqamaAt",System.currentTimeMillis()+5*60_000L).putExtra("dark",dark);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }

        @JavascriptInterface
        public void setSystemBarsDark(boolean dark) {
            runOnUiThread(() -> {
                int c = dark
                        ? Color.rgb(6, 17, 13)
                        : Color.rgb(232, 238, 233);

                getWindow().setStatusBarColor(c);
                getWindow().setNavigationBarColor(c);
                getWindow().getDecorView().setBackgroundColor(c);
                if (webView != null) webView.setBackgroundColor(c);
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    getWindow().setNavigationBarDividerColor(c);
                }

                int flags = getWindow()
                        .getDecorView()
                        .getSystemUiVisibility();

                if (dark) {
                    flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else {
                    flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }

                getWindow()
                        .getDecorView()
                        .setSystemUiVisibility(flags);
            });
        }
    }
}
