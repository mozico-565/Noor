package com.noor.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_PREFIX = "/assets/";

    private WebView webView;
    private boolean readerActive = false;
    private SharedPreferences prefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        prefs = getSharedPreferences("noor", MODE_PRIVATE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(232, 238, 233));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        /*
         * Noor used to open index.html through file:///android_asset/.
         * Modern Android WebView blocks fetch() from a file:// page in several
         * configurations, which caused the Quran JSON to fail even though it
         * was correctly bundled inside the APK.
         *
         * The app now exposes packaged assets through a private HTTPS-style
         * origin and serves them directly from Android assets below.
         * Relative fetch("./data/quran.json") is therefore same-origin and
         * works completely offline.
         */
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if ("https".equals(uri.getScheme())
                        && APP_HOST.equals(uri.getHost())
                        && uri.getPath() != null
                        && uri.getPath().startsWith(APP_PREFIX)) {

                    String assetPath = uri.getPath().substring(APP_PREFIX.length());

                    // Do not allow path traversal.
                    if (assetPath.contains("..")) {
                        return new WebResourceResponse(
                                "text/plain", "UTF-8", 403, "Forbidden",
                                null, new java.io.ByteArrayInputStream(new byte[0]));
                    }

                    try {
                        InputStream stream = getAssets().open(assetPath);
                        return new WebResourceResponse(
                                mimeType(assetPath), "UTF-8", stream);
                    } catch (IOException ignored) {
                        return null;
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                if (APP_HOST.equals(uri.getHost())) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.addJavascriptInterface(new NoorBridge(), "Android");
        setContentView(webView);

        // Private local origin. No internet connection is required.
        webView.loadUrl(
                "https://" + APP_HOST + "/assets/www/index.html"
        );
    }

    private String mimeType(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (readerActive && event.getRepeatCount() == 0) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(1)", null);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                webView.evaluateJavascript(
                        "window.noorVolumePage&&window.noorVolumePage(-1)", null);
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public class NoorBridge {
        @JavascriptInterface
        public void setReaderActive(boolean active) {
            readerActive = active;
        }

        @JavascriptInterface
        public void saveReaderPage(int page) {
            prefs.edit().putInt("reader_page", page).apply();
        }

        @JavascriptInterface
        public int getReaderPage() {
            return prefs.getInt("reader_page", 1);
        }

        @JavascriptInterface
        public void setSystemBarsDark(boolean dark) {
            runOnUiThread(() -> {
                int c = dark
                        ? Color.rgb(6, 17, 13)
                        : Color.rgb(232, 238, 233);

                getWindow().setStatusBarColor(c);
                getWindow().setNavigationBarColor(c);

                int flags = getWindow()
                        .getDecorView()
                        .getSystemUiVisibility();

                if (dark) {
                    flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else {
                    flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }

                getWindow()
                        .getDecorView()
                        .setSystemUiVisibility(flags);
            });
        }
    }
}
