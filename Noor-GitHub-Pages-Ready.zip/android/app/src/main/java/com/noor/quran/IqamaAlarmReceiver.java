package com.noor.quran;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class IqamaAlarmReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i){
    Intent s=new Intent(c,IqamaOverlayService.class).putExtra("prayer",i.getStringExtra("prayer")).putExtra("iqamaAt",i.getLongExtra("iqamaAt",0)).putExtra("dark",i.getBooleanExtra("dark",false));
    if(android.os.Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s); PrayerTimeManager.scheduleFromSavedLocation(c); IqamaScheduler.reschedule(c);
  }
}
