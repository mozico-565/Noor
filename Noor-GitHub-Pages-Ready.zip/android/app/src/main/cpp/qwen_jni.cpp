#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"
#include "ggml-backend.h"

#define LOG_TAG "NoorQwen"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static std::string g_model_path;
static bool g_backend_loaded = false;

static std::string jstring_to_utf8(JNIEnv * env, jstring value) {
    if (!value) return "";
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string result(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return result;
}

static void free_cached_model() {
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
        g_model_path.clear();
    }
}

static llama_model * get_model(const std::string & path) {
    if (g_model && g_model_path == path) return g_model;

    free_cached_model();

    if (!g_backend_loaded) {
        ggml_backend_load_all();
        g_backend_loaded = true;
    }

    llama_model_params params = llama_model_default_params();
    params.n_gpu_layers = 0;

    g_model = llama_model_load_from_file(path.c_str(), params);
    if (!g_model) {
        LOGE("Unable to load model: %s", path.c_str());
        return nullptr;
    }
    g_model_path = path;
    return g_model;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_noor_quran_MainActivity_nativeInfer(
        JNIEnv * env,
        jclass,
        jstring modelPathValue,
        jstring promptValue,
        jint maxTokensValue) {

    std::lock_guard<std::mutex> lock(g_mutex);

    const std::string model_path = jstring_to_utf8(env, modelPathValue);
    const std::string prompt = jstring_to_utf8(env, promptValue);
    const int max_tokens = std::max(16, std::min(160, (int) maxTokensValue));

    llama_model * model = get_model(model_path);
    if (!model) return env->NewStringUTF("");

    const llama_vocab * vocab = llama_model_get_vocab(model);

    int n_prompt = -llama_tokenize(
        vocab,
        prompt.c_str(),
        (int32_t) prompt.size(),
        nullptr,
        0,
        true,
        true
    );

    if (n_prompt <= 0) {
        LOGE("Token count failed: %d", n_prompt);
        return env->NewStringUTF("");
    }

    // Keep intent parsing memory use modest on Android 10 devices.
    const uint32_t n_ctx = (uint32_t) std::max(768, std::min(1536, n_prompt + max_tokens + 64));

    std::vector<llama_token> prompt_tokens((size_t) n_prompt);
    const int tokenized = llama_tokenize(
        vocab,
        prompt.c_str(),
        (int32_t) prompt.size(),
        prompt_tokens.data(),
        (int32_t) prompt_tokens.size(),
        true,
        true
    );

    if (tokenized < 0) {
        LOGE("Prompt tokenization failed");
        return env->NewStringUTF("");
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = n_ctx;
    ctx_params.n_batch = std::min<uint32_t>(n_ctx, 512);
    ctx_params.n_ubatch = std::min<uint32_t>(ctx_params.n_batch, 256);
    ctx_params.n_threads = 4;
    ctx_params.n_threads_batch = 4;
    ctx_params.no_perf = true;

    llama_context * ctx = llama_init_from_model(model, ctx_params);
    if (!ctx) {
        LOGE("Context creation failed");
        return env->NewStringUTF("");
    }

    llama_sampler * sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.15f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(0xC0FFEE));

    llama_batch batch = llama_batch_get_one(prompt_tokens.data(), (int32_t) prompt_tokens.size());

    std::string output;
    output.reserve(1024);

    int n_pos = 0;
    int generated = 0;

    while (generated < max_tokens && n_pos + batch.n_tokens < (int) n_ctx) {
        if (llama_decode(ctx, batch) != 0) {
            LOGE("llama_decode failed");
            break;
        }

        n_pos += batch.n_tokens;

        llama_token token = llama_sampler_sample(sampler, ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;

        char buf[512];
        int n = llama_token_to_piece(vocab, token, buf, sizeof(buf), 0, true);
        if (n < 0) {
            std::vector<char> large((size_t) (-n));
            n = llama_token_to_piece(vocab, token, large.data(), (int32_t) large.size(), 0, true);
            if (n > 0) output.append(large.data(), (size_t) n);
        } else if (n > 0) {
            output.append(buf, (size_t) n);
        }

        batch = llama_batch_get_one(&token, 1);
        generated++;

        // Intent JSON should be short. Stop after a complete object to save battery.
        if (!output.empty()) {
            auto open = output.find('{');
            auto close = output.rfind('}');
            if (open != std::string::npos && close != std::string::npos && close > open) break;
        }
    }

    llama_sampler_free(sampler);
    llama_free(ctx);

    return env->NewStringUTF(output.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_noor_quran_MainActivity_nativeUnloadQwen(
        JNIEnv *,
        jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_cached_model();
}
