# Noor release hardening
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.noor.quran.MainActivity$NoorBridge { public *; }
