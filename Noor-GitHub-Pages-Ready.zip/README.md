# نور | Noor
مساعد قرآني بواجهة عربية RTL وLiquid Glass.

## الوضع الحالي
- واجهة كاملة قابلة للتشغيل.
- بحث/محادثة Demo آمن.
- لا يتم اختلاق آيات أو أسباب نزول عند غياب مصدر.
- قبل الإنتاج: اربط Quran Foundation Content API أو مصدرًا موثوقًا من backend، ولا تضع secrets في الواجهة.

## Local
npm install
npm run dev

## GitHub Pages
الـ workflow المرفق يبني وينشر تلقائيًا عند push إلى main.
