# Noor

Noor is an Arabic-first Quran assistant and offline Quran reader.

## Included in this package
- Full Quran reader, grouped by Mushaf page (604 pages).
- Arabic ayah numbers.
- Light / dark mode persisted between sessions.
- Resume the exact last page and scroll position.
- Long-press any Quran word to open its root and local Mufradat meaning when available.
- Bookmarks.
- Local Quran text search and Asbab al-Nuzul lookup.
- Android wrapper with volume buttons:
  - Volume Down = next page.
  - Volume Up = previous page.
- Offline data bundled into the Android APK during GitHub Actions build.

## Build
The repository workflow downloads the licensed/open datasets, builds the Vite web app, deploys GitHub Pages, copies the built app into Android assets, builds `Noor-debug.apk`, then uploads it as the `Noor-APK` artifact.

See `THIRD_PARTY_NOTICES.md` for data attribution.


## GitHub Actions
- `build.yml` creates an installable `Noor-debug.apk` in the `Noor-APK` artifact.
- `pages.yml` builds and deploys the same app to GitHub Pages.


## Reference engine upgrade
- Fixes disappearing surah banners by keeping the current surah header sticky.
- Removes unsupported ornamental Quran annotation glyphs that appeared as square boxes on some Android fonts.
- Adds an offline word->root index and common Quran fact questions.
- Build can add compact excerpts from 8 major tafsir sources and a searchable index across 17 hadith collections.
- If local confidence is low and internet exists, Noor can verify Quran text via Al Quran Cloud. It does not require internet for normal reading/search.


## Word meaning accuracy
Long-press lookup now validates the surface word before accepting a morphology index.
Contextual meaning is shown before the generic root dictionary meaning, preventing a neighbouring token or broad root definition from being presented as the meaning of the selected word.


## Local Qwen intent engine
The Android build includes a native llama.cpp bridge for arm64-v8a.

Qwen is not bundled inside the APK. In Settings the user can download
Qwen3-0.6B Q4_K_M once (~484 MB). The model is stored in the app's private
storage and then works offline.

Security/grounding rule: Qwen is used only to classify the user's Arabic
question, extract useful search terms, and map clear questions to a small
verified fact ID. Quran, tafsir, hadith, word meaning, and facts are still
retrieved from Noor's source data. Qwen's memory is never treated as a
religious source.
