# Noor

Noor is an Arabic-first Quran assistant and offline Quran reader.

## Included in this package
- Full Quran reader, grouped by Mushaf page (604 pages).
- Arabic ayah numbers.
- Light / dark mode persisted between sessions.
- Resume the exact last page and scroll position.
- Long-press any Quran word to open its root and local Mufradat meaning when available.
- Bookmarks.
- Local Quran text search and Asbab al-Nuzul lookup.
- Android wrapper with volume buttons:
  - Volume Down = next page.
  - Volume Up = previous page.
- Offline data bundled into the Android APK during GitHub Actions build.

## Build
The repository workflow downloads the licensed/open datasets, builds the Vite web app, deploys GitHub Pages, copies the built app into Android assets, builds `Noor-debug.apk`, then uploads it as the `Noor-APK` artifact.

See `THIRD_PARTY_NOTICES.md` for data attribution.


## GitHub Actions
- `build.yml` creates an installable `Noor-debug.apk` in the `Noor-APK` artifact.
- `pages.yml` builds and deploys the same app to GitHub Pages.
