import React, {useEffect, useMemo, useRef, useState} from "react";
import { createRoot } from "react-dom/client";
import {
  Search, Send, BookOpen, Bookmark, BookmarkCheck, Settings, Sparkles, Moon, Sun,
  ChevronLeft, ChevronRight, Quote, Info, X, List, RotateCcw, LibraryBig
} from "lucide-react";
import "./styles.css";

type QWord = { index:number; text:string; buckwalter?:string };
type QAyah = {
  number:number; verse_key:string; global_number:number; text:string; words:QWord[];
  page:number; juz:number; hizb:number; ruku?:number; sajda?:unknown;
};
type QSurah = {
  number:number; name_arabic:string; name_transliteration?:string; counts:{ayahs:number};
  revelation?:{type:string;order:number}; ayahs:QAyah[];
};
type QuranData = { dataset?:unknown; surahs:QSurah[] };
type RootWord = {t:string; r?:string};
type RootAyah = {k:string; a:number; words:RootWord[]};
type MufradatEntry = {r?:string; t?:string; v?:string[]; vc?:number};
type RootEntry = {b?:string; m?:string; f?:number; v?:string[]};
type AsbabEntry = {surah:number; ayahs:number[]; occasions:string[]};

type ReaderVerse = QAyah & {surahNumber:number; surahName:string};
type Answer = {
  title:string; ayah:string; ref:string; meaning:string; context:string; sabab:string; source:string;
  verseKey?:string;
};
type WordInfo = {text:string; root?:string; definition?:string; english?:string; verseKey:string};

declare global {
  interface Window {
    Android?: {
      setReaderActive:(active:boolean)=>void;
      saveReaderPage:(page:number)=>void;
      getReaderPage:()=>number;
      setSystemBarsDark?:(dark:boolean)=>void;
    };
    noorVolumePage?:(delta:number)=>void;
  }
}

const suggestions=["ما معنى الصمد؟","اشرح سورة العصر","أين ذُكر الصبر؟","ما معنى التقوى؟"];
const stopWords=new Set(["ما","ماذا","من","عن","في","هو","هي","معنى","اشرح","شرح","أين","ذكر","القرآن","القران","سورة","آية","اية","سبب","نزول","سبب النزول"]);
const functionWordMeanings:Record<string,string>={
  "من":"حرف جر، ويأتي لابتداء الغاية أو التبعيض أو غيرهما بحسب السياق.",
  "في":"حرف جر يفيد الظرفية غالبًا بحسب السياق.",
  "على":"حرف جر يفيد الاستعلاء حقيقةً أو مجازًا بحسب السياق.",
  "الى":"حرف جر يدل غالبًا على انتهاء الغاية.",
  "عن":"حرف جر يفيد المجاوزة أو البعد بحسب السياق.",
  "ب":"حرف جر، ومن معانيه الإلصاق والاستعانة والسببية بحسب السياق.",
  "ك":"حرف تشبيه وجر.",
  "ل":"حرف جر، ومن معانيه الملك والاختصاص والتعليل بحسب السياق.",
  "و":"حرف عطف أو استئناف بحسب السياق.",
  "ف":"حرف عطف أو تفريع يدل غالبًا على التعقيب بحسب السياق.",
  "ثم":"حرف عطف للترتيب مع التراخي.",
  "او":"حرف عطف، ويأتي للتخيير أو التقسيم أو الإباحة بحسب السياق.",
  "لا":"أداة نفي أو نهي أو غير ذلك بحسب السياق.",
  "ما":"قد تأتي اسمًا موصولًا أو أداة استفهام أو نفي أو غير ذلك بحسب السياق.",
  "ان":"قد تأتي أداة توكيد أو شرط أو نفي بحسب الضبط والسياق.",
  "انما":"أداة حصر وتوكيد.",
  "هل":"أداة استفهام.",
  "هذا":"اسم إشارة للمفرد المذكر.",
  "هذه":"اسم إشارة للمفرد المؤنث.",
  "ذلك":"اسم إشارة للبعيد المفرد المذكر.",
  "تلك":"اسم إشارة للبعيد المفرد المؤنث.",
  "الذي":"اسم موصول للمفرد المذكر.",
  "التي":"اسم موصول للمفرد المؤنث.",
  "الذين":"اسم موصول لجمع المذكر.",
  "هو":"ضمير منفصل للمفرد المذكر الغائب.",
  "هي":"ضمير منفصل للمفرد المؤنث الغائب.",
  "هم":"ضمير لجمع الغائبين.",
  "هن":"ضمير لجمع الغائبات.",
  "انا":"ضمير المتكلم المفرد.",
  "نحن":"ضمير المتكلمين.",
  "انت":"ضمير للمخاطب بحسب الضبط والسياق.",
  "كان":"فعل ماض ناقص، ويدل مع خبره على اتصاف الاسم بالخبر في الزمن أو السياق المذكور.",
  "ليس":"فعل ماض ناقص جامد يفيد النفي.",
  "كل":"لفظ يفيد الشمول بحسب ما يضاف إليه.",
  "بعض":"لفظ يدل على جزء من كل.",
  "قبل":"ظرف يدل على التقدم زمانًا أو مكانًا بحسب السياق.",
  "بعد":"ظرف يدل على التأخر زمانًا أو مكانًا بحسب السياق."
};

function Glass({children,className="",onClick}:{children:React.ReactNode,className?:string,onClick?:React.MouseEventHandler<HTMLDivElement>}) {
  return <div className={`glass ${className}`} onClick={onClick}>{children}</div>;
}

function normalizeArabic(s:string){
  return s
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,"")
    .replace(/[إأآٱ]/g,"ا")
    .replace(/ى/g,"ي")
    .replace(/ؤ/g,"و")
    .replace(/ئ/g,"ي")
    .replace(/ة/g,"ه")
    .replace(/[^\u0621-\u063A\u0641-\u064A0-9\s]/g,"")
    .replace(/\s+/g," ")
    .trim();
}
function arNum(n:number){ return String(n).replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[Number(d)]); }
function clamp(n:number,min:number,max:number){ return Math.max(min,Math.min(max,n)); }

function useLiquidRuntime(){
  useEffect(()=>{
    const root=document.documentElement;
    let pressed:HTMLElement|null=null;
    let raf=0;
    let timer=0;
    const setVH=()=>root.style.setProperty("--vvh",`${Math.round(window.visualViewport?.height ?? window.innerHeight)}px`);
    const update=(el:HTMLElement,ev:PointerEvent)=>{
      cancelAnimationFrame(raf);
      raf=requestAnimationFrame(()=>{
        const r=el.getBoundingClientRect();
        if(!r.width||!r.height)return;
        const px=clamp(ev.clientX-r.left,0,r.width), py=clamp(ev.clientY-r.top,0,r.height);
        el.style.setProperty("--touch-x",`${px}px`);
        el.style.setProperty("--touch-y",`${py}px`);
        el.style.setProperty("--gx",`${px/r.width*100}%`);
        el.style.setProperty("--gy",`${py/r.height*100}%`);
      });
    };
    const down=(ev:PointerEvent)=>{
      const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
      if(!el)return;
      pressed=el; clearTimeout(timer); update(el,ev);
      el.classList.remove("liquid-release"); el.classList.add("liquid-press");
    };
    const move=(ev:PointerEvent)=>{ if(pressed) update(pressed,ev); };
    const release=()=>{
      if(!pressed)return;
      const el=pressed; pressed=null; el.classList.remove("liquid-press"); el.classList.add("liquid-release");
      timer=window.setTimeout(()=>el.classList.remove("liquid-release"),360);
    };
    setVH();
    window.visualViewport?.addEventListener("resize",setVH);
    window.addEventListener("orientationchange",setVH,{passive:true});
    document.addEventListener("pointerdown",down,{passive:true});
    document.addEventListener("pointermove",move,{passive:true});
    document.addEventListener("pointerup",release,{passive:true});
    document.addEventListener("pointercancel",release,{passive:true});
    return()=>{
      cancelAnimationFrame(raf); clearTimeout(timer);
      window.visualViewport?.removeEventListener("resize",setVH);
      window.removeEventListener("orientationchange",setVH);
      document.removeEventListener("pointerdown",down);
      document.removeEventListener("pointermove",move);
      document.removeEventListener("pointerup",release);
      document.removeEventListener("pointercancel",release);
    };
  },[]);
}

function App(){
  useLiquidRuntime();

  const [q,setQ]=useState("");
  const [answer,setAnswer]=useState<Answer|null>(null);
  const [tab,setTab]=useState<"home"|"quran"|"saved"|"settings">(()=>{
    const saved=localStorage.getItem("noor_last_tab");
    return saved==="quran"||saved==="saved"||saved==="settings"||saved==="home"?saved:"home";
  });
  const [dark,setDark]=useState(()=>localStorage.getItem("noor_theme")==="dark" || (!localStorage.getItem("noor_theme") && matchMedia("(prefers-color-scheme: dark)").matches));
  const [sources,setSources]=useState(false);

  const [quran,setQuran]=useState<QuranData|null>(null);
  const [mufradat,setMufradat]=useState<Record<string,MufradatEntry>>({});
  const [roots,setRoots]=useState<Record<string,RootEntry>>({});
  const [asbab,setAsbab]=useState<AsbabEntry[]>([]);
  const [dataError,setDataError]=useState("");
  const rootCache=useRef<Record<number,RootAyah[]>>({});

  const [readerPage,setReaderPage]=useState(()=>{
    const native=window.Android?.getReaderPage?.();
    if(native && native>0)return native;
    return Number(localStorage.getItem("noor_reader_page")||"1");
  });
  const [wordInfo,setWordInfo]=useState<WordInfo|null>(null);
  const [surahPicker,setSurahPicker]=useState(false);
  const [bookmarks,setBookmarks]=useState<string[]>(()=>JSON.parse(localStorage.getItem("noor_bookmarks")||"[]"));
  const readerRef=useRef<HTMLDivElement>(null);
  const restoredScroll=useRef(false);
  const scrollSaveTimer=useRef<number>(0);

  useEffect(()=>{
    Promise.all([
      fetch("./data/quran.json").then(r=>{if(!r.ok)throw new Error("quran"); return r.json()}),
      fetch("./data/mufradat.json").then(r=>r.ok?r.json():{}),
      fetch("./data/roots_index.json").then(r=>r.ok?r.json():{}),
      fetch("./data/asbab.json").then(r=>r.ok?r.json():[])
    ]).then(([q,m,r,a])=>{
      setQuran(q as QuranData); setMufradat(m); setRoots(r); setAsbab(Array.isArray(a)?a:[]);
    }).catch(()=>setDataError("تعذر تحميل بيانات القرآن. أعد بناء النسخة من GitHub Actions."));
  },[]);

  useEffect(()=>{
    localStorage.setItem("noor_theme",dark?"dark":"light");
    document.documentElement.style.colorScheme=dark?"dark":"light";
    window.Android?.setSystemBarsDark?.(dark);
  },[dark]);

  useEffect(()=>{
    localStorage.setItem("noor_tab",tab);
  },[tab]);

  useEffect(()=>{
    localStorage.setItem("noor_bookmarks",JSON.stringify(bookmarks));
  },[bookmarks]);

  useEffect(()=>{
    localStorage.setItem("noor_last_tab",tab);
  },[tab]);

  const pages=useMemo(()=>{
    const map:Record<number,ReaderVerse[]>={};
    if(!quran)return map;
    for(const s of quran.surahs){
      for(const a of s.ayahs){
        (map[a.page] ||= []).push({...a,surahNumber:s.number,surahName:s.name_arabic});
      }
    }
    return map;
  },[quran]);

  const verseByKey=useMemo(()=>{
    const map=new Map<string,ReaderVerse>();
    if(quran) for(const s of quran.surahs) for(const a of s.ayahs) map.set(a.verse_key,{...a,surahNumber:s.number,surahName:s.name_arabic});
    return map;
  },[quran]);

  const firstPageBySurah=useMemo(()=>{
    const map=new Map<number,number>();
    if(quran) for(const s of quran.surahs) if(s.ayahs.length) map.set(s.number,s.ayahs[0].page);
    return map;
  },[quran]);

  async function loadRootSurah(n:number){
    if(rootCache.current[n])return rootCache.current[n];
    try{
      const r=await fetch(`./data/surahs/${n}.json`);
      const d=r.ok?await r.json():[];
      rootCache.current[n]=d;
      return d as RootAyah[];
    }catch{return [] as RootAyah[];}
  }

  useEffect(()=>{
    if(tab!=="quran")return;
    const unique=[...new Set((pages[readerPage]||[]).map(v=>v.surahNumber))];
    unique.forEach(n=>void loadRootSurah(n));
  },[tab,readerPage,pages]);

  useEffect(()=>{
    const active=tab==="quran";
    window.Android?.setReaderActive?.(active);
    window.noorVolumePage=(delta:number)=>{
      if(!active)return;
      setReaderPage(p=>clamp(p+delta,1,604));
    };
    return()=>{ window.noorVolumePage=undefined; };
  },[tab]);

  useEffect(()=>{
    readerPage && localStorage.setItem("noor_reader_page",String(readerPage));
    window.Android?.saveReaderPage?.(readerPage);
    if(tab!=="quran")return;
    const exact=Number(localStorage.getItem(`noor_reader_scroll_${readerPage}`)||"0");
    requestAnimationFrame(()=>requestAnimationFrame(()=>{ if(readerRef.current) readerRef.current.scrollTop=exact; }));
  },[readerPage,tab]);

  function onReaderScroll(){
    if(!readerRef.current)return;
    clearTimeout(scrollSaveTimer.current);
    const top=readerRef.current.scrollTop;
    scrollSaveTimer.current=window.setTimeout(()=>localStorage.setItem(`noor_reader_scroll_${readerPage}`,String(top)),90);
  }

  function goPage(n:number,reset=true){
    const next=clamp(n,1,604);
    if(reset)localStorage.setItem(`noor_reader_scroll_${next}`,"0");
    setReaderPage(next);
  }

  function toggleBookmark(k:string){
    setBookmarks(b=>b.includes(k)?b.filter(x=>x!==k):[...b,k]);
  }

  function findAsbab(surah:number,ayah:number){
    return asbab.find(x=>Number(x.surah)===surah && Array.isArray(x.ayahs) && x.ayahs.map(Number).includes(ayah));
  }

  async function openWord(verse:ReaderVerse,index:number,text:string){
    const rootData=await loadRootSurah(verse.surahNumber);
    const row=rootData.find(x=>x.k===verse.verse_key);
    const rw=row?.words?.[index];
    let root=rw?.r;
    if(!root && row?.words){
      const target=normalizeArabic(text);
      root=row.words.find(w=>normalizeArabic(w.t)===target)?.r;
    }
    const mf=root?mufradat[root]:undefined;
    const ri=root?roots[root]:undefined;
    const normalizedWord=normalizeArabic(text);
    setWordInfo({
      text,root,
      definition:mf?.t || functionWordMeanings[normalizedWord] || "لا يتوفر شرح معجمي محلي مستقل لهذه الكلمة في المصدر الحالي؛ معناها الدقيق يتحدد من سياق الآية.",
      english:ri?.m,
      verseKey:verse.verse_key
    });
  }

  function extractTerms(text:string){
    const norm=normalizeArabic(text);
    return norm.split(" ").filter(w=>w.length>1&&!stopWords.has(w)).sort((a,b)=>b.length-a.length);
  }

  async function submit(text=q){
    const t=text.trim(); if(!t)return;
    setQ(t);
    if(!quran){
      setAnswer({title:"جاري تجهيز البيانات",ayah:"",ref:"",meaning:dataError||"انتظر لحظة حتى تُحمّل قاعدة القرآن المحلية.",context:"",sabab:"",source:"قاعدة نور المحلية"});
      return;
    }
    const terms=extractTerms(t);
    const all:Array<ReaderVerse>=[];
    for(const s of quran.surahs){
      for(const a of s.ayahs){
        const n=normalizeArabic(a.text);
        if(terms.length && terms.every(term=>n.includes(term))) all.push({...a,surahNumber:s.number,surahName:s.name_arabic});
        if(all.length>=8)break;
      }
      if(all.length>=8)break;
    }
    const first=all[0];
    if(!first){
      setAnswer({title:"لم أجد تطابقًا مباشرًا",ayah:"",ref:"",meaning:"جرّب كتابة كلمة من الآية أو اسم السورة. نور لا يخمّن نصًا قرآنيًا غير موجود في قاعدة البيانات.",context:"البحث الحالي يعمل محليًا داخل نص القرآن الكامل.",sabab:"",source:"نص القرآن المحلي · Tanzil / Quran Core Dataset"});
      return;
    }
    let meaning=`وجدت ${all.length} موضعًا مطابقًا في البحث المحلي.`;
    const candidate=terms[0];
    if(candidate){
      const row=(await loadRootSurah(first.surahNumber)).find(x=>x.k===first.verse_key);
      const idx=first.words.findIndex(w=>normalizeArabic(w.text).includes(candidate));
      const root=row?.words?.[Math.max(0,idx)]?.r;
      if(root && mufradat[root]?.t) meaning=mufradat[root].t!.slice(0,650);
    }
    const sabab=findAsbab(first.surahNumber,first.number);
    setAnswer({
      title:t.includes("معنى")?`معنى ${terms[0]||""}`:`نتيجة البحث`,
      ayah:first.text,
      ref:`سورة ${first.surahName} · الآية ${arNum(first.number)}`,
      meaning,
      context:all.slice(0,4).map(v=>`${v.surahName} ${arNum(v.number)}`).join(" · "),
      sabab:sabab?.occasions?.[0] || "لا يوجد سبب نزول مثبت لهذه الآية ضمن قاعدة أسباب النزول المحلية.",
      source:"نص القرآن: Tanzil / Quran Core Dataset · معاني المفردات: مفردات الراغب · أسباب النزول: صحيح أسباب النزول"
    });
  }

  const currentVerses=pages[readerPage]||[];
  const currentSurahs=[...new Map(currentVerses.map(v=>[v.surahNumber,v.surahName])).entries()];

  return <main className={dark?"app dark":"app"}>
    <div className="aurora a1"/><div className="aurora a2"/>

    <header>
      <div className="brand"><span className="logo">ن</span><div><b>نور</b><small>{tab==="quran"?"المصحف":"اسأل عن القرآن"}</small></div></div>
      <button className="icon glass" onClick={()=>setDark(!dark)} aria-label="تغيير المظهر">{dark?<Sun/>:<Moon/>}</button>
    </header>

    <section className="content">
      {tab==="home" && <>
        {!answer ? <div className="hero">
          <div className="orb"><BookOpen/></div>
          <h1 className="simpleTitle"><span>اسأل عن القرآن</span></h1>
          <div className="chips">{suggestions.map((s,i)=>
            <button className="chip glass" onClick={()=>submit(s)} key={s}>
              <span className="chipIcon">{i===0?<BookOpen/>:i===1?<Sparkles/>:i===2?<Quote/>:<BookOpen/>}</span>
              <span>{s}</span><ChevronLeft/>
            </button>)}
          </div>
        </div> :
        <div className="answer pageEnter">
          <button className="back glass" onClick={()=>{setAnswer(null);setQ("")}}><X/> سؤال جديد</button>
          <Glass className="answerCard">
            <div className="answerHead"><Sparkles/><div><small>إجابة نور المحلية</small><h2>{answer.title}</h2></div></div>
            {answer.ayah && <div className="ayah"><Quote/><p>{answer.ayah}</p><small>{answer.ref}</small></div>}
            <section><h3>المعنى</h3><p>{answer.meaning}</p></section>
            {answer.context && <section><h3>مواضع مرتبطة</h3><p>{answer.context}</p></section>}
            <section><h3>سبب النزول</h3><p>{answer.sabab}</p></section>
            <button className="source" onClick={()=>setSources(true)}><Info/> المصادر <ChevronLeft/></button>
          </Glass>
        </div>}
        <div className="composer glass"><Search/><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="اسأل عن القرآن…"/><button onClick={()=>submit()}><Send/></button></div>
      </>}

      {tab==="quran" && <div className="readerShell pageEnter">
        <div className="readerToolbar glass">
          <button onClick={()=>setSurahPicker(true)}><List/><span>{currentSurahs.map(([,n])=>n).join(" / ")||"المصحف"}</span></button>
          <div className="pageCounter">صفحة {arNum(readerPage)} من ٦٠٤</div>
          <button onClick={()=>{localStorage.setItem(`noor_reader_scroll_${readerPage}`,"0"); readerRef.current?.scrollTo({top:0,behavior:"smooth"})}} aria-label="بداية الصفحة"><RotateCcw/></button>
        </div>
        <div className="readerViewport" ref={readerRef} onScroll={onReaderScroll}>
          {!quran && <div className="readerLoading">{dataError||"جاري تحميل القرآن الكامل…"}</div>}
          {currentVerses.map((v,i)=><article className="verseBlock" key={v.verse_key}>
            {(i===0 || currentVerses[i-1]?.surahNumber!==v.surahNumber) && <div className="surahBanner">
              <LibraryBig/><b>سورة {v.surahName}</b>
            </div>}
            <div className="verseWords">
              {v.words.map((w,wi)=><WordSpan key={`${v.verse_key}-${wi}`} text={w.text} onLong={()=>openWord(v,wi,w.text)}/>)}
              <button className={`ayahNumber ${bookmarks.includes(v.verse_key)?"bookmarked":""}`} onClick={()=>toggleBookmark(v.verse_key)} aria-label={bookmarks.includes(v.verse_key)?"إزالة حفظ الآية":"حفظ الآية"}>
                <span>﴿{arNum(v.number)}﴾</span>
              </button>
            </div>
          </article>)}
          <div className="readerBottomPad"/>
        </div>
        <div className="pageStepper">
          <button className="glass" onClick={()=>goPage(readerPage-1)} disabled={readerPage<=1}><ChevronRight/> السابقة</button>
          <button className="glass" onClick={()=>goPage(readerPage+1)} disabled={readerPage>=604}>التالية <ChevronLeft/></button>
        </div>
      </div>}

      {tab==="saved" && <Glass className="page savedPage pageEnter">
        <Bookmark/><h2>المحفوظات</h2>
        {bookmarks.length===0?<p>اضغط رقم أي آية داخل المصحف لحفظها هنا.</p>:
          <div className="savedList">{bookmarks.map(k=>{
            const v=verseByKey.get(k); if(!v)return null;
            return <button key={k} onClick={()=>{goPage(v.page,false);setTab("quran")}}>
              <b>سورة {v.surahName} · {arNum(v.number)}</b><span>{v.text}</span>
            </button>;
          })}</div>}
      </Glass>}

      {tab==="settings" && <Glass className="page settingsPage pageEnter">
        <Settings/><h2>الإعدادات</h2>
        <div className="setting"><span>الوضع</span><button onClick={()=>setDark(!dark)}>{dark?"داكن":"فاتح"}</button></div>
        <div className="setting"><span>آخر صفحة</span><b>{arNum(readerPage)}</b></div>
        <div className="setting"><span>أزرار الصوت</span><b>تغيير صفحات المصحف في تطبيق Android</b></div>
        <div className="setting"><span>العمل بدون إنترنت</span><b>القرآن والمعاني وأسباب النزول محلية</b></div>
        <div className="credits">
          <b>المصادر</b>
          <p>نص القرآن: Tanzil عبر Quran Core Dataset. المعاني الجذرية: مفردات الراغب وبيانات Quran bil-Quran. أسباب النزول: صحيح أسباب النزول.</p>
        </div>
      </Glass>}
    </section>

    <nav className={`nav glass nav-${tab}`}>
      <span className="liquidSelection" aria-hidden="true"/>
      <button className={tab==="home"?"active":""} onClick={()=>setTab("home")}><Sparkles/><span>اسأل</span></button>
      <button className={tab==="quran"?"active":""} onClick={()=>setTab("quran")}><BookOpen/><span>القرآن</span></button>
      <button className={tab==="saved"?"active":""} onClick={()=>setTab("saved")}><Bookmark/><span>محفوظات</span></button>
      <button className={tab==="settings"?"active":""} onClick={()=>setTab("settings")}><Settings/><span>الإعدادات</span></button>
    </nav>

    {sources&&<div className="modal" onClick={()=>setSources(false)}>
      <Glass className="sheet" onClick={e=>e.stopPropagation()}><button onClick={()=>setSources(false)}><X/></button><h2>المصادر</h2><p>{answer?.source}</p></Glass>
    </div>}

    {wordInfo&&<div className="modal wordModal" onClick={()=>setWordInfo(null)}>
      <Glass className="sheet wordSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setWordInfo(null)}><X/></button>
        <small>ضغط مطول · {wordInfo.verseKey}</small>
        <h2>{wordInfo.text}</h2>
        {wordInfo.root&&<div className="rootBadge">الجذر: {wordInfo.root}</div>}
        <p className="wordDefinition">{wordInfo.definition}</p>
        {wordInfo.english&&<details><summary>مرجع لغوي إضافي</summary><p>{wordInfo.english}</p></details>}
        <small>المصدر: مفردات ألفاظ القرآن للراغب الأصفهاني + فهرس الجذور المحلي.</small>
      </Glass>
    </div>}

    {surahPicker&&<div className="modal" onClick={()=>setSurahPicker(false)}>
      <Glass className="sheet surahSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setSurahPicker(false)}><X/></button>
        <h2>السور</h2>
        <div className="surahList">{quran?.surahs.map(s=>
          <button key={s.number} onClick={()=>{goPage(firstPageBySurah.get(s.number)||1);setSurahPicker(false)}}>
            <span>{arNum(s.number)}</span><b>{s.name_arabic}</b><small>{arNum(s.counts.ayahs)} آية</small>
          </button>)}
        </div>
      </Glass>
    </div>}
  </main>;
}

function WordSpan({text,onLong}:{text:string;onLong:()=>void}){
  const timer=useRef<number>(0);
  const origin=useRef<{x:number;y:number}|null>(null);
  const start=(e:React.PointerEvent<HTMLSpanElement>)=>{
    origin.current={x:e.clientX,y:e.clientY};
    clearTimeout(timer.current);
    timer.current=window.setTimeout(()=>{onLong(); if(navigator.vibrate)navigator.vibrate(18);},520);
  };
  const move=(e:React.PointerEvent<HTMLSpanElement>)=>{
    if(!origin.current)return;
    if(Math.hypot(e.clientX-origin.current.x,e.clientY-origin.current.y)>9){
      clearTimeout(timer.current); origin.current=null;
    }
  };
  const stop=()=>{clearTimeout(timer.current);origin.current=null};
  return <span className="qWord" onPointerDown={start} onPointerMove={move} onPointerUp={stop} onPointerCancel={stop} onPointerLeave={stop} onContextMenu={e=>e.preventDefault()}>{text}</span>;
}

createRoot(document.getElementById("root")!).render(<App/>);
