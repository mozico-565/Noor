import React, {useMemo, useState} from "react";
import { createRoot } from "react-dom/client";
import { Search, Send, BookOpen, Bookmark, Settings, Sparkles, Moon, Sun, ChevronLeft, Quote, Info, X } from "lucide-react";
import "./styles.css";

type Answer = {title:string; ayah:string; ref:string; meaning:string; tafsir:string; sabab:string; source:string};
const demo: Record<string,Answer> = {
  "الصمد": {title:"معنى الصمد",ayah:"قُلْ هُوَ ٱللَّهُ أَحَدٌ ۝ ٱللَّهُ ٱلصَّمَدُ",ref:"سورة الإخلاص · 1–2",meaning:"الصمد: السيد الكامل في صفاته، المقصود في الحوائج، الغني عن خلقه وكل الخلق محتاجون إليه.",tafsir:"توضح كتب التفسير أن اسم «الصمد» يجمع معاني كمال الغنى والسيادة وأن الخلائق تصمد إليه في حاجاتها.",sabab:"لا يعرض التطبيق سبب نزول محدد إلا عند توفر نقل موثوق في المصدر المختار.",source:"وضع تجريبي · راجع تفسير السعدي/ابن كثير"},
  "العصر": {title:"ما معنى والعصر؟",ayah:"وَٱلْعَصْرِ ۝ إِنَّ ٱلْإِنسَانَ لَفِى خُسْرٍ",ref:"سورة العصر · 1–2",meaning:"افتتح الله السورة بالقسم بالعصر، وهو الزمن، ثم بيّن أن الإنسان في خسارة إلا من اتصف بالصفات المذكورة في بقية السورة.",tafsir:"المعنى العام يلفت إلى قيمة الزمن وأن النجاة مرتبطة بالإيمان والعمل الصالح والتواصي بالحق والصبر.",sabab:"لا نثبت سبب نزول خاص هنا في الوضع التجريبي.",source:"وضع تجريبي · يلزم ربط مصدر قرآني موثوق للإنتاج"}
};
const suggestions=["ما معنى الصمد؟","اشرح سورة العصر","أين ذُكر الصبر؟","ما معنى التقوى؟"];

function Glass({children,className=""}:{children:React.ReactNode,className?:string}){return <div className={`glass ${className}`}>{children}</div>}


function useLiquidRuntime(){
 React.useEffect(()=>{
   const setVH=()=>document.documentElement.style.setProperty("--vvh",`${window.visualViewport?.height ?? window.innerHeight}px`);
   setVH();
   window.visualViewport?.addEventListener("resize",setVH);
   window.visualViewport?.addEventListener("scroll",setVH);
   const down=(ev:PointerEvent)=>{
     const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
     if(!el)return;
     const r=el.getBoundingClientRect();
     const px=ev.clientX-r.left, py=ev.clientY-r.top;
     el.style.setProperty("--touch-x",`${px}px`);
     el.style.setProperty("--touch-y",`${py}px`);
     el.style.setProperty("--gx",`${(px/r.width)*100}%`);
     el.style.setProperty("--gy",`${(py/r.height)*100}%`);
     el.style.setProperty("--press-dx",`${Math.max(-2.5,Math.min(2.5,(px-r.width/2)*.025))}px`);
     el.style.setProperty("--press-dy",`${Math.max(-2,Math.min(2,(py-r.height/2)*.025))}px`);
     el.classList.remove("liquid-release");
     el.classList.add("liquid-press");
   };
   const move=(ev:PointerEvent)=>{
     const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
     if(!el || !el.classList.contains("liquid-press")) return;
     const r=el.getBoundingClientRect(), px=ev.clientX-r.left, py=ev.clientY-r.top;
     el.style.setProperty("--touch-x",`${px}px`); el.style.setProperty("--touch-y",`${py}px`);
     el.style.setProperty("--gx",`${(px/r.width)*100}%`); el.style.setProperty("--gy",`${(py/r.height)*100}%`);
   };
   const up=(ev:PointerEvent)=>{
     const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
     if(!el)return;
     el.classList.remove("liquid-press");
     el.classList.add("liquid-release");
     window.setTimeout(()=>el.classList.remove("liquid-release"),520);
   };
   document.addEventListener("pointerdown",down,{passive:true});
   document.addEventListener("pointermove",move,{passive:true});
   document.addEventListener("pointerup",up,{passive:true});
   document.addEventListener("pointercancel",up,{passive:true});
   return ()=>{
     window.visualViewport?.removeEventListener("resize",setVH);
     window.visualViewport?.removeEventListener("scroll",setVH);
     document.removeEventListener("pointerdown",down);
     document.removeEventListener("pointermove",move);
     document.removeEventListener("pointerup",up);
     document.removeEventListener("pointercancel",up);
   };
 },[]);
}
function App(){
 useLiquidRuntime();
 const [q,setQ]=useState(""); const [answer,setAnswer]=useState<Answer|null>(null); const [dark,setDark]=useState(false); const [tab,setTab]=useState("home"); const [sources,setSources]=useState(false);
 const submit=(text=q)=>{const t=text.trim(); if(!t)return; setQ(t); const key=Object.keys(demo).find(k=>t.includes(k)); setAnswer(key?demo[key]:{title:"بحث عن: "+t,ayah:"",ref:"",meaning:"هذه النسخة تعمل حاليًا بوضع Demo آمن. تم تجهيز الواجهة ومحرك الإجابة، لكن البحث الحي في القرآن والتفاسير يحتاج ربط Content API موثوق من الخادم.",tafsir:"لن يؤلف نور آية أو تفسيرًا أو سبب نزول عند عدم وجود مصدر موثوق.",sabab:"إذا لم يثبت سبب نزول في المصدر، سيصرح التطبيق بذلك بدل التخمين.",source:"Demo mode"});};
 return <main className={dark?"app dark":"app"} onClick={(e)=>{if((e.target as HTMLElement).closest("button")) (document.activeElement as HTMLElement)?.blur?.()}}>
   <div className="aurora a1"/><div className="aurora a2"/>
   <header><div className="brand"><span className="logo">ن</span><div><b>نور</b><small>اسأل عن القرآن</small></div></div><button className="icon glass" onClick={()=>setDark(!dark)}>{dark?<Sun/>:<Moon/>}</button></header>
   <section className="content">
    <div className="viewTransition" key={tab}>
    {tab==="home" && <>
      {!answer ? <div className="hero">
        <div className="orb"><BookOpen/></div><h1 className="simpleTitle"><span>اسأل عن القرآن</span></h1>
        <div className="chips">{suggestions.map((s,i)=><button className="chip glass" onClick={()=>submit(s)} key={s}><span className="chipIcon">{i===0?<BookOpen/>:i===1?<Sparkles/>:i===2?<Quote/>:<BookOpen/>}</span><span>{s}</span><ChevronLeft/></button>)}</div>
      </div> :
      <div className="answer">
        <button className="back glass" onClick={()=>{setAnswer(null);setQ("")}}><X/> سؤال جديد</button>
        <Glass className="answerCard">
          <div className="answerHead"><Sparkles/><div><small>إجابة نور</small><h2>{answer.title}</h2></div></div>
          {answer.ayah && <div className="ayah"><Quote/><p>{answer.ayah}</p><small>{answer.ref}</small></div>}
          <section><h3>المعنى</h3><p>{answer.meaning}</p></section>
          <section><h3>من التفسير</h3><p>{answer.tafsir}</p></section>
          <section><h3>سبب النزول</h3><p>{answer.sabab}</p></section>
          <button className="source" onClick={()=>setSources(true)}><Info/> المصادر <ChevronLeft/></button>
        </Glass>
      </div>}
      <div className="composer glass"><Search/><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="اسأل عن القرآن…"/><button onClick={()=>submit()}><Send/></button></div>
    </>}
    {tab==="saved" && <Glass className="page"><Bookmark/><h2>المحفوظات</h2><p>ستظهر هنا الآيات والإجابات التي تحفظها. لا توجد عناصر محفوظة بعد.</p></Glass>}
    {tab==="topics" && <Glass className="page"><BookOpen/><h2>الموضوعات</h2><div className="topicGrid">{["الصبر","الرحمة","التوبة","الصلاة","الأخلاق","القصص"].map(x=><button onClick={()=>{setTab("home");submit("ماذا يقول القرآن عن "+x)}}>{x}</button>)}</div></Glass>}
    {tab==="settings" && <Glass className="page"><Settings/><h2>الإعدادات</h2><div className="setting"><span>الوضع الداكن</span><button onClick={()=>setDark(!dark)}>{dark?"مفعّل":"غير مفعّل"}</button></div><div className="setting"><span>المصدر</span><b>Demo آمن</b></div></Glass>}
    </div>
   </section>
   <nav className={`nav glass nav-${tab}`}>
    <span className="liquidSelection" aria-hidden="true"/>
    <button className={tab==="home"?"active":""} onClick={()=>setTab("home")}><Sparkles/><span>اسأل</span></button>
    <button className={tab==="topics"?"active":""} onClick={()=>setTab("topics")}><BookOpen/><span>موضوعات</span></button>
    <button className={tab==="saved"?"active":""} onClick={()=>setTab("saved")}><Bookmark/><span>محفوظات</span></button>
    <button className={tab==="settings"?"active":""} onClick={()=>setTab("settings")}><Settings/><span>الإعدادات</span></button>
   </nav>
   {sources&&<div className="modal" onClick={()=>setSources(false)}><Glass className="sheet" ><button onClick={()=>setSources(false)}><X/></button><h2>المصادر</h2><p>{answer?.source}</p><small>النسخة الحالية Demo. قبل الإطلاق العام يجب ربط مصدر قرآني موثوق والتحقق من التراخيص وإظهار المرجع لكل إجابة.</small></Glass></div>}
 </main>
}
createRoot(document.getElementById("root")!).render(<App/>);