import React, {useEffect, useMemo, useRef, useState} from "react";
import { createRoot } from "react-dom/client";
import {
  Search, Send, BookOpen, Bookmark, BookmarkCheck, Settings, Sparkles, Moon, Sun,
  ChevronLeft, ChevronRight, Quote, Info, X, List, RotateCcw, LibraryBig
} from "lucide-react";
import "./styles.css";

type QWord = { index:number; text:string; buckwalter?:string };
type QAyah = {
  number:number; verse_key:string; global_number:number; text:string; words:QWord[];
  page:number; juz:number; hizb:number; ruku?:number; sajda?:unknown;
};
type QSurah = {
  number:number; name_arabic:string; name_transliteration?:string; counts:{ayahs:number};
  revelation?:{type:string;order:number}; ayahs:QAyah[];
};
type QuranData = { dataset?:unknown; surahs:QSurah[] };
type RootWord = {t:string; r?:string};
type RootAyah = {k:string; a:number; words:RootWord[]};
type MufradatEntry = {r?:string; t?:string; v?:string[]; vc?:number};
type RootEntry = {b?:string; m?:string; f?:number; v?:string[]};
type AsbabEntry = {surah:number; ayahs:number[]; occasions:string[]};
type TafsirItem = {type:string; text:string};
type TafsirAyah = {ayah_number:number; tafsir:TafsirItem[]};
type TafsirSurah = {surah?:string; number:number; ayahs:TafsirAyah[]};
type HadithIndexItem = {book:string; id:string|number; arabic:string; reference?:string; grade?:string};
type CommonFact = {id:string; patterns:string[]; title:string; answer:string; verseKey?:string; source:string};

type ReaderVerse = QAyah & {surahNumber:number; surahName:string};
type Answer = {
  title:string; ayah:string; ref:string; meaning:string; context:string; sabab:string; source:string;
  verseKey?:string;
};
type WordInfo = {text:string; root?:string; contextMeaning?:string; lexicalMeaning?:string; english?:string; verseKey:string; source?:string};
type QwenIntent = {
  intent?: "word_meaning"|"person"|"surah_fact"|"tafsir"|"hadith"|"topic"|"verse_search"|"general";
  keywords?: string[];
  fact_id?: string;
  surah?: string;
  verse?: number;
};

const qwenResolvers=new Map<string,{resolve:(value:QwenIntent|null)=>void,timer:number}>();

declare global {
  interface Window {
    Android?: {
      setReaderActive:(active:boolean)=>void;
      saveReaderPage:(page:number)=>void;
      getReaderPage:()=>number;
      setSystemBarsDark?:(dark:boolean)=>void;
      isQwenReady?:()=>boolean;
      qwenModelSize?:()=>number;
      startQwenDownload?:()=>void;
      deleteQwenModel?:()=>void;
      qwenInfer?:(requestId:string,prompt:string)=>void;
    };
    noorVolumePage?:(delta:number)=>void;
    noorQwenProgress?:(percent:number,status:string)=>void;
    noorQwenResult?:(requestId:string,result:string,error:string)=>void;
  }
}

const suggestions=["ما معنى الصمد؟","اشرح سورة العصر","أين ذُكر الصبر؟","ما معنى التقوى؟"];
const contextualWordGlosses:Record<string,string>={
  "2:7|غشاوه":"غِشاوة: غطاءٌ وحجابٌ على الأبصار. في سياق الآية: جُعل على أبصارهم غطاء فلا ينتفعون برؤية الحق.",
  "2:7|ختم":"خَتَمَ: طبع وأغلق. في سياق الآية: طبع الله على قلوبهم وسمعهم بسبب كفرهم فلا يصل إليهما الهدى.",
  "2:2|المتقين":"المتقون: الذين يجعلون بينهم وبين عذاب الله وقاية بطاعته واجتناب معصيته."
};
const stopWords=new Set(["ما","ماذا","من","عن","في","هو","هي","معنى","اشرح","شرح","أين","ذكر","القرآن","القران","سورة","آية","اية","سبب","نزول","سبب النزول"]);
const functionWordMeanings:Record<string,string>={
  "من":"حرف جر، ويأتي لابتداء الغاية أو التبعيض أو غيرهما بحسب السياق.",
  "في":"حرف جر يفيد الظرفية غالبًا بحسب السياق.",
  "على":"حرف جر يفيد الاستعلاء حقيقةً أو مجازًا بحسب السياق.",
  "الى":"حرف جر يدل غالبًا على انتهاء الغاية.",
  "عن":"حرف جر يفيد المجاوزة أو البعد بحسب السياق.",
  "ب":"حرف جر، ومن معانيه الإلصاق والاستعانة والسببية بحسب السياق.",
  "ك":"حرف تشبيه وجر.",
  "ل":"حرف جر، ومن معانيه الملك والاختصاص والتعليل بحسب السياق.",
  "و":"حرف عطف أو استئناف بحسب السياق.",
  "ف":"حرف عطف أو تفريع يدل غالبًا على التعقيب بحسب السياق.",
  "ثم":"حرف عطف للترتيب مع التراخي.",
  "او":"حرف عطف، ويأتي للتخيير أو التقسيم أو الإباحة بحسب السياق.",
  "لا":"أداة نفي أو نهي أو غير ذلك بحسب السياق.",
  "ما":"قد تأتي اسمًا موصولًا أو أداة استفهام أو نفي أو غير ذلك بحسب السياق.",
  "ان":"قد تأتي أداة توكيد أو شرط أو نفي بحسب الضبط والسياق.",
  "انما":"أداة حصر وتوكيد.",
  "هل":"أداة استفهام.",
  "هذا":"اسم إشارة للمفرد المذكر.",
  "هذه":"اسم إشارة للمفرد المؤنث.",
  "ذلك":"اسم إشارة للبعيد المفرد المذكر.",
  "تلك":"اسم إشارة للبعيد المفرد المؤنث.",
  "الذي":"اسم موصول للمفرد المذكر.",
  "التي":"اسم موصول للمفرد المؤنث.",
  "الذين":"اسم موصول لجمع المذكر.",
  "هو":"ضمير منفصل للمفرد المذكر الغائب.",
  "هي":"ضمير منفصل للمفرد المؤنث الغائب.",
  "هم":"ضمير لجمع الغائبين.",
  "هن":"ضمير لجمع الغائبات.",
  "انا":"ضمير المتكلم المفرد.",
  "نحن":"ضمير المتكلمين.",
  "انت":"ضمير للمخاطب بحسب الضبط والسياق.",
  "كان":"فعل ماض ناقص، ويدل مع خبره على اتصاف الاسم بالخبر في الزمن أو السياق المذكور.",
  "ليس":"فعل ماض ناقص جامد يفيد النفي.",
  "كل":"لفظ يفيد الشمول بحسب ما يضاف إليه.",
  "بعض":"لفظ يدل على جزء من كل.",
  "قبل":"ظرف يدل على التقدم زمانًا أو مكانًا بحسب السياق.",
  "بعد":"ظرف يدل على التأخر زمانًا أو مكانًا بحسب السياق."
};

function Glass({children,className="",onClick}:{children:React.ReactNode,className?:string,onClick?:React.MouseEventHandler<HTMLDivElement>}) {
  return <div className={`glass ${className}`} onClick={onClick}>{children}</div>;
}

function normalizeArabic(s:string){
  return s
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,"")
    .replace(/[إأآٱ]/g,"ا")
    .replace(/ى/g,"ي")
    .replace(/ؤ/g,"و")
    .replace(/ئ/g,"ي")
    .replace(/ة/g,"ه")
    .replace(/[^\u0621-\u063A\u0641-\u064A0-9\s]/g,"")
    .replace(/\s+/g," ")
    .trim();
}
function cleanQuranDisplay(s:string){
  // Android system fonts do not render every ornamental Quran annotation.
  // Keep letters + ordinary harakat, remove only decorative annotation codepoints
  // that were appearing as empty square glyphs on some phones.
  return s.normalize("NFC")
    .replace(/[\u06D6-\u06ED\u08D4-\u08FF]/g,"")
    .replace(/[\u200B-\u200F\u2066-\u2069\uFEFF]/g,"");
}
function arNum(n:number){ return String(n).replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[Number(d)]); }
function clamp(n:number,min:number,max:number){ return Math.max(min,Math.min(max,n)); }

function useLiquidRuntime(){
  useEffect(()=>{
    const root=document.documentElement;
    let pressed:HTMLElement|null=null;
    let raf=0;
    let timer=0;
    const setVH=()=>root.style.setProperty("--vvh",`${Math.round(window.visualViewport?.height ?? window.innerHeight)}px`);
    const update=(el:HTMLElement,ev:PointerEvent)=>{
      cancelAnimationFrame(raf);
      raf=requestAnimationFrame(()=>{
        const r=el.getBoundingClientRect();
        if(!r.width||!r.height)return;
        const px=clamp(ev.clientX-r.left,0,r.width), py=clamp(ev.clientY-r.top,0,r.height);
        el.style.setProperty("--touch-x",`${px}px`);
        el.style.setProperty("--touch-y",`${py}px`);
        el.style.setProperty("--gx",`${px/r.width*100}%`);
        el.style.setProperty("--gy",`${py/r.height*100}%`);
      });
    };
    const down=(ev:PointerEvent)=>{
      const el=(ev.target as HTMLElement)?.closest("button") as HTMLElement|null;
      if(!el)return;
      pressed=el; clearTimeout(timer); update(el,ev);
      el.classList.remove("liquid-release"); el.classList.add("liquid-press");
    };
    const move=(ev:PointerEvent)=>{ if(pressed) update(pressed,ev); };
    const release=()=>{
      if(!pressed)return;
      const el=pressed; pressed=null; el.classList.remove("liquid-press"); el.classList.add("liquid-release");
      timer=window.setTimeout(()=>el.classList.remove("liquid-release"),360);
    };
    setVH();
    window.visualViewport?.addEventListener("resize",setVH);
    window.addEventListener("orientationchange",setVH,{passive:true});
    document.addEventListener("pointerdown",down,{passive:true});
    document.addEventListener("pointermove",move,{passive:true});
    document.addEventListener("pointerup",release,{passive:true});
    document.addEventListener("pointercancel",release,{passive:true});
    return()=>{
      cancelAnimationFrame(raf); clearTimeout(timer);
      window.visualViewport?.removeEventListener("resize",setVH);
      window.removeEventListener("orientationchange",setVH);
      document.removeEventListener("pointerdown",down);
      document.removeEventListener("pointermove",move);
      document.removeEventListener("pointerup",release);
      document.removeEventListener("pointercancel",release);
    };
  },[]);
}

function App(){
  useLiquidRuntime();

  const [q,setQ]=useState("");
  const [answer,setAnswer]=useState<Answer|null>(null);
  const [tab,setTab]=useState<"home"|"quran"|"saved"|"settings">(()=>{
    const saved=localStorage.getItem("noor_last_tab");
    return saved==="quran"||saved==="saved"||saved==="settings"||saved==="home"?saved:"home";
  });
  const [dark,setDark]=useState(()=>localStorage.getItem("noor_theme")==="dark" || (!localStorage.getItem("noor_theme") && matchMedia("(prefers-color-scheme: dark)").matches));
  const [sources,setSources]=useState(false);
  const [qwenReady,setQwenReady]=useState(()=>Boolean(window.Android?.isQwenReady?.()));
  const [qwenProgress,setQwenProgress]=useState(0);
  const [qwenStatus,setQwenStatus]=useState(qwenReady?"جاهز للعمل دون إنترنت":"غير مثبت");

  const [quran,setQuran]=useState<QuranData|null>(null);
  const [mufradat,setMufradat]=useState<Record<string,MufradatEntry>>({});
  const [roots,setRoots]=useState<Record<string,RootEntry>>({});
  const [asbab,setAsbab]=useState<AsbabEntry[]>([]);
  const [wordRootIndex,setWordRootIndex]=useState<Record<string,string>>({});
  const [commonFacts,setCommonFacts]=useState<CommonFact[]>([]);
  const [dataError,setDataError]=useState("");
  const rootCache=useRef<Record<number,RootAyah[]>>({});
  const tafsirCache=useRef<Record<number,TafsirSurah>>({});
  const hadithCache=useRef<HadithIndexItem[]|null>(null);

  const [readerPage,setReaderPage]=useState(()=>{
    const native=window.Android?.getReaderPage?.();
    if(native && native>0)return native;
    return Number(localStorage.getItem("noor_reader_page")||"1");
  });
  const [wordInfo,setWordInfo]=useState<WordInfo|null>(null);
  const [surahPicker,setSurahPicker]=useState(false);
  const [bookmarks,setBookmarks]=useState<string[]>(()=>JSON.parse(localStorage.getItem("noor_bookmarks")||"[]"));
  const readerRef=useRef<HTMLDivElement>(null);
  const restoredScroll=useRef(false);
  const scrollSaveTimer=useRef<number>(0);

  useEffect(()=>{
    Promise.all([
      fetch("./data/quran.json").then(r=>{if(!r.ok)throw new Error("quran"); return r.json()}),
      fetch("./data/mufradat.json").then(r=>r.ok?r.json():{}),
      fetch("./data/roots_index.json").then(r=>r.ok?r.json():{}),
      fetch("./data/asbab.json").then(r=>r.ok?r.json():[]),
      fetch("./data/word_root_index.json").then(r=>r.ok?r.json():{}).catch(()=>({})),
      fetch("./data/common_facts.json").then(r=>r.ok?r.json():[]).catch(()=>([]))
    ]).then(([q,m,r,a,w,f])=>{
      setQuran(q as QuranData);
      setMufradat(m);
      setRoots(r);
      setAsbab(Array.isArray(a)?a:[]);
      setWordRootIndex(w||{});
      setCommonFacts(Array.isArray(f)?f:[]);
    }).catch(()=>setDataError("تعذر تحميل بيانات القرآن. أعد بناء النسخة من GitHub Actions."));
  },[]);

  useEffect(()=>{
    localStorage.setItem("noor_theme",dark?"dark":"light");
    document.documentElement.style.colorScheme=dark?"dark":"light";
    window.Android?.setSystemBarsDark?.(dark);
  },[dark]);

  useEffect(()=>{
    window.noorQwenProgress=(percent,status)=>{
      setQwenProgress(Math.max(0,Math.min(100,Number(percent)||0)));
      setQwenStatus(status||"جاري تجهيز Qwen…");
      if(percent>=100){
        setQwenReady(true);
        setQwenStatus("جاهز للعمل دون إنترنت");
      }
    };
    window.noorQwenResult=(requestId,result,error)=>{
      const pending=qwenResolvers.get(requestId);
      if(!pending)return;
      window.clearTimeout(pending.timer);
      qwenResolvers.delete(requestId);
      if(error){
        pending.resolve(null);
        return;
      }
      try{
        const cleaned=String(result||"")
          .replace(/<think>[\s\S]*?<\/think>/g,"")
          .trim();
        const match=cleaned.match(/\{[\s\S]*\}/);
        pending.resolve(match?JSON.parse(match[0]):null);
      }catch{
        pending.resolve(null);
      }
    };
    return()=>{
      window.noorQwenProgress=undefined;
      window.noorQwenResult=undefined;
    };
  },[]);

  useEffect(()=>{
    localStorage.setItem("noor_tab",tab);
  },[tab]);

  useEffect(()=>{
    localStorage.setItem("noor_bookmarks",JSON.stringify(bookmarks));
  },[bookmarks]);

  useEffect(()=>{
    localStorage.setItem("noor_last_tab",tab);
  },[tab]);

  const pages=useMemo(()=>{
    const map:Record<number,ReaderVerse[]>={};
    if(!quran)return map;
    for(const s of quran.surahs){
      for(const a of s.ayahs){
        (map[a.page] ||= []).push({...a,surahNumber:s.number,surahName:s.name_arabic});
      }
    }
    return map;
  },[quran]);

  const verseByKey=useMemo(()=>{
    const map=new Map<string,ReaderVerse>();
    if(quran) for(const s of quran.surahs) for(const a of s.ayahs) map.set(a.verse_key,{...a,surahNumber:s.number,surahName:s.name_arabic});
    return map;
  },[quran]);

  const firstPageBySurah=useMemo(()=>{
    const map=new Map<number,number>();
    if(quran) for(const s of quran.surahs) if(s.ayahs.length) map.set(s.number,s.ayahs[0].page);
    return map;
  },[quran]);

  async function loadRootSurah(n:number){
    if(rootCache.current[n])return rootCache.current[n];
    try{
      const r=await fetch(`./data/surahs/${n}.json`);
      const d=r.ok?await r.json():[];
      rootCache.current[n]=d;
      return d as RootAyah[];
    }catch{return [] as RootAyah[];}
  }

  useEffect(()=>{
    if(tab!=="quran")return;
    const unique=[...new Set((pages[readerPage]||[]).map(v=>v.surahNumber))];
    unique.forEach(n=>void loadRootSurah(n));
  },[tab,readerPage,pages]);

  useEffect(()=>{
    const active=tab==="quran";
    window.Android?.setReaderActive?.(active);
    window.noorVolumePage=(delta:number)=>{
      if(!active)return;
      setReaderPage(p=>clamp(p+delta,1,604));
    };
    return()=>{ window.noorVolumePage=undefined; };
  },[tab]);

  useEffect(()=>{
    readerPage && localStorage.setItem("noor_reader_page",String(readerPage));
    window.Android?.saveReaderPage?.(readerPage);
    if(tab!=="quran")return;
    const exact=Number(localStorage.getItem(`noor_reader_scroll_${readerPage}`)||"0");
    requestAnimationFrame(()=>requestAnimationFrame(()=>{ if(readerRef.current) readerRef.current.scrollTop=exact; }));
  },[readerPage,tab]);

  function onReaderScroll(){
    if(!readerRef.current)return;
    clearTimeout(scrollSaveTimer.current);
    const top=readerRef.current.scrollTop;
    scrollSaveTimer.current=window.setTimeout(()=>localStorage.setItem(`noor_reader_scroll_${readerPage}`,String(top)),90);
  }

  function goPage(n:number,reset=true){
    const next=clamp(n,1,604);
    if(reset)localStorage.setItem(`noor_reader_scroll_${next}`,"0");
    setReaderPage(next);
  }

  function toggleBookmark(k:string){
    setBookmarks(b=>b.includes(k)?b.filter(x=>x!==k):[...b,k]);
  }

  function findAsbab(surah:number,ayah:number){
    return asbab.find(x=>Number(x.surah)===surah && Array.isArray(x.ayahs) && x.ayahs.map(Number).includes(ayah));
  }

  async function openWord(verse:ReaderVerse,index:number,text:string){
    const target=normalizeArabic(text);

    // Resolve the root from the exact surface form first. The old implementation
    // trusted the word array index before validating the token, which could return
    // the root of a neighbouring word when two datasets segment an ayah differently.
    let root=wordRootIndex[target];

    const rootData=await loadRootSurah(verse.surahNumber);
    const row=rootData.find(x=>x.k===verse.verse_key);

    if(!root && row?.words){
      const exact=row.words.find(w=>normalizeArabic(w.t)===target);
      root=exact?.r;
    }

    if(!root && row?.words?.[index]){
      const indexed=row.words[index];
      // Index fallback is accepted only when the actual surface word matches.
      if(normalizeArabic(indexed.t)===target) root=indexed.r;
    }

    const mf=root?mufradat[root]:undefined;
    const ri=root?roots[root]:undefined;

    // Prefer a context-specific gloss, then a short excerpt from the tafsir of
    // this exact ayah. The root dictionary remains visible separately as a
    // lexical reference and is never presented as the contextual meaning itself.
    let contextMeaning=contextualWordGlosses[`${verse.verse_key}|${target}`];

    const tafsir=await loadTafsirSurah(verse.surahNumber);
    const ayahTafsir=tafsir?.ayahs?.find(a=>Number(a.ayah_number)===verse.number);
    const preferred=(ayahTafsir?.tafsir||[]).find(x=>
      /الميسر|السعدي|المختصر/.test(x.type||"")
    ) || ayahTafsir?.tafsir?.[0];

    if(!contextMeaning && preferred?.text){
      const clean=preferred.text.replace(/\s+/g," ").trim();
      contextMeaning=`في سياق الآية (${preferred.type}): ${clean.slice(0,520)}${clean.length>520?"…":""}`;
    }

    if(!contextMeaning){
      contextMeaning=functionWordMeanings[target] || "لم أجد شرحًا سياقيًا مستقلًا لهذه الكلمة في المراجع المحلية الحالية.";
    }

    setWordInfo({
      text:cleanQuranDisplay(text),
      root,
      contextMeaning,
      lexicalMeaning:mf?.t
        ? `المعنى المعجمي للجذر «${root}»: ${mf.t.slice(0,650)}`
        : undefined,
      english:ri?.m,
      verseKey:verse.verse_key,
      source:preferred?.type
        ? `${preferred.type} · مفردات الراغب · فهرس الجذور المحلي`
        : "مفردات ألفاظ القرآن للراغب الأصفهاني · فهرس الجذور المحلي"
    });
  }

  function extractTerms(text:string){
    const norm=normalizeArabic(text);
    return norm.split(" ").filter(w=>w.length>1&&!stopWords.has(w)).sort((a,b)=>b.length-a.length);
  }

  function matchCommonFact(text:string){
    const n=normalizeArabic(text);
    return commonFacts.find(f=>f.patterns.some(p=>n.includes(normalizeArabic(p))));
  }

  async function loadTafsirSurah(surah:number){
    if(tafsirCache.current[surah])return tafsirCache.current[surah];
    try{
      const key=String(surah).padStart(3,"0");
      const r=await fetch(`./data/tafsir/${key}.json`);
      if(!r.ok)return null;
      const data=await r.json() as TafsirSurah;
      tafsirCache.current[surah]=data;
      return data;
    }catch{return null}
  }

  async function loadHadithIndex(){
    if(hadithCache.current)return hadithCache.current;
    try{
      const r=await fetch("./data/hadith_index.json");
      if(!r.ok)return [];
      const data=await r.json();
      hadithCache.current=Array.isArray(data)?data:[];
      return hadithCache.current;
    }catch{return []}
  }

  function textScore(text:string,terms:string[]){
    const n=normalizeArabic(text);
    let score=0;
    for(const term of terms){
      if(n.includes(term))score += term.length>=5?4:2;
      else if(term.length>=4 && n.includes(term.slice(0,-1)))score += 1;
    }
    return score;
  }

  async function findHadithSupport(terms:string[]){
    if(!terms.length)return [] as HadithIndexItem[];
    const data=await loadHadithIndex();
    return data
      .map(h=>({h,score:textScore(h.arabic,terms)}))
      .filter(x=>x.score>0)
      .sort((a,b)=>b.score-a.score)
      .slice(0,3)
      .map(x=>x.h);
  }

  async function onlineQuranVerify(term:string){
    if(!navigator.onLine || !term)return null;
    const ctrl=new AbortController();
    const timer=window.setTimeout(()=>ctrl.abort(),4500);
    try{
      const url=`https://api.alquran.cloud/v1/search/${encodeURIComponent(term)}/all/quran-simple-clean`;
      const r=await fetch(url,{signal:ctrl.signal});
      if(!r.ok)return null;
      const j=await r.json();
      const matches=j?.data?.matches;
      if(!Array.isArray(matches)||!matches.length)return null;
      const m=matches[0];
      return {
        text:String(m.text||""),
        surah:String(m.surah?.name||m.surah?.englishName||""),
        number:Number(m.numberInSurah||0)
      };
    }catch{return null}
    finally{clearTimeout(timer)}
  }

  async function understandWithQwen(question:string):Promise<QwenIntent|null>{
    if(!window.Android?.isQwenReady?.() || !window.Android?.qwenInfer)return null;

    const requestId=`q${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const prompt=`<|im_start|>system
أنت وحدة فهم سؤال فقط داخل تطبيق قرآن. لا تجب عن السؤال ولا تقتبس آية من ذاكرتك.
مهمتك تحويل سؤال المستخدم إلى JSON فقط بلا شرح.
القيم المسموحة intent:
word_meaning, person, surah_fact, tafsir, hadith, topic, verse_search, general.
fact_id المسموح عند التطابق الواضح فقط:
longest-surah, shortest-surah, longest-ayah, ayat-kursi, surah-count, juz-count, first-surah, last-surah, basmala-tawbah, two-basmala, named-companion.
أخرج:
{"intent":"...","keywords":["..."],"fact_id":"","surah":"","verse":0}
ضع الكلمات العربية المهمة فقط في keywords. لا تخترع معلومة دينية.
/no_think<|im_end|>
<|im_start|>user
${question}<|im_end|>
<|im_start|>assistant
`;

    return new Promise(resolve=>{
      const timer=window.setTimeout(()=>{
        qwenResolvers.delete(requestId);
        resolve(null);
      },12000);
      qwenResolvers.set(requestId,{resolve,timer});
      try{
        window.Android!.qwenInfer!(requestId,prompt);
      }catch{
        window.clearTimeout(timer);
        qwenResolvers.delete(requestId);
        resolve(null);
      }
    });
  }

  async function submit(text=q){
    const t=text.trim(); if(!t)return;
    setQ(t);

    if(!quran){
      setAnswer({title:"جاري تجهيز البيانات",ayah:"",ref:"",meaning:dataError||"انتظر لحظة حتى تُحمّل قاعدة القرآن المحلية.",context:"",sabab:"",source:"قاعدة نور المحلية"});
      return;
    }

    const fact=matchCommonFact(t);
    if(fact){
      const v=fact.verseKey?verseByKey.get(fact.verseKey):undefined;
      setAnswer({
        title:fact.title,
        ayah:v?cleanQuranDisplay(v.text):"",
        ref:v?`سورة ${v.surahName} · الآية ${arNum(v.number)}`:"",
        meaning:fact.answer,
        context:"إجابة محفوظة محليًا من قاعدة الحقائق القرآنية الموثقة.",
        sabab:v?(findAsbab(v.surahNumber,v.number)?.occasions?.[0]||"لا يرتبط هذا السؤال بسبب نزول محدد في القاعدة المحلية."):"",
        source:fact.source
      });
      return;
    }

    const ai=await understandWithQwen(t);

    if(ai?.fact_id){
      const aiFact=commonFacts.find(f=>f.id===ai.fact_id);
      if(aiFact){
        const v=aiFact.verseKey?verseByKey.get(aiFact.verseKey):undefined;
        setAnswer({
          title:aiFact.title,
          ayah:v?cleanQuranDisplay(v.text):"",
          ref:v?`سورة ${v.surahName} · الآية ${arNum(v.number)}`:"",
          meaning:aiFact.answer,
          context:"فهم Qwen نية السؤال، ثم أخذ Noor الإجابة من قاعدة الحقائق المحلية الموثقة.",
          sabab:v?(findAsbab(v.surahNumber,v.number)?.occasions?.[0]||"لا يرتبط هذا السؤال بسبب نزول محدد في القاعدة المحلية."):"",
          source:aiFact.source+" · Qwen استُخدم لفهم السؤال فقط"
        });
        return;
      }
    }

    const baseTerms=extractTerms(t);
    const aiTerms=(ai?.keywords||[]).map(normalizeArabic).filter(x=>x.length>1&&!stopWords.has(x));
    const terms=[...new Set([...aiTerms,...baseTerms])].sort((a,b)=>b.length-a.length);

    // Direct word-meaning lookup, independent of exact verse spelling.
    if((ai?.intent==="word_meaning" || /معن[ىي]|ماذا تعني|ما المقصود/.test(normalizeArabic(t))) && terms[0]){
      const word=terms[0];
      const root=wordRootIndex[word] || wordRootIndex[normalizeArabic(word)];
      const mf=root?mufradat[root]:undefined;
      if(mf?.t){
        const localMatches:Array<ReaderVerse>=[];
        for(const s of quran.surahs){
          for(const a of s.ayahs){
            if(a.words.some(w=>normalizeArabic(w.text)===word || normalizeArabic(w.text).includes(word))){
              localMatches.push({...a,surahNumber:s.number,surahName:s.name_arabic});
              if(localMatches.length>=5)break;
            }
          }
          if(localMatches.length>=5)break;
        }
        const first=localMatches[0];
        setAnswer({
          title:`معنى ${word}`,
          ayah:first?cleanQuranDisplay(first.text):"",
          ref:first?`سورة ${first.surahName} · الآية ${arNum(first.number)}`:"",
          meaning:mf.t.slice(0,950),
          context:localMatches.map(v=>`${v.surahName} ${arNum(v.number)}`).join(" · "),
          sabab:first?(findAsbab(first.surahNumber,first.number)?.occasions?.[0]||"لا يوجد سبب نزول مرتبط مباشرةً بهذه الكلمة في القاعدة المحلية."):"",
          source:"مفردات ألفاظ القرآن للراغب الأصفهاني · فهرس الجذور المحلي · نص القرآن"
        });
        return;
      }
    }

    // Score all verses instead of requiring every token to be an exact substring.
    const scored:Array<{v:ReaderVerse;score:number}>=[];
    for(const s of quran.surahs){
      const surahName=normalizeArabic(s.name_arabic);
      for(const a of s.ayahs){
        let score=textScore(a.text,terms);
        if(terms.some(term=>surahName.includes(term))) score+=3;
        if(score>0) scored.push({v:{...a,surahNumber:s.number,surahName:s.name_arabic},score});
      }
    }
    scored.sort((a,b)=>b.score-a.score || a.v.global_number-b.v.global_number);
    const all=scored.slice(0,8).map(x=>x.v);
    const first=all[0];

    if(first){
      const tafsir=await loadTafsirSurah(first.surahNumber);
      const ayahTafsir=tafsir?.ayahs?.find(a=>Number(a.ayah_number)===first.number);
      const selected=(ayahTafsir?.tafsir||[])
        .filter(x=>x.text?.trim())
        .slice(0,3);

      let meaning="";
      if(selected.length){
        meaning=selected.map(x=>`${x.type}: ${x.text.trim().slice(0,520)}`).join("\n\n");
      }else{
        const candidate=terms[0];
        const row=(await loadRootSurah(first.surahNumber)).find(x=>x.k===first.verse_key);
        const idx=first.words.findIndex(w=>normalizeArabic(w.text).includes(candidate||""));
        const root=row?.words?.[Math.max(0,idx)]?.r;
        meaning=(root&&mufradat[root]?.t)
          ? mufradat[root]!.t!.slice(0,800)
          : `أقرب موضع قرآني لسؤالك هو ${first.verse_key}. أعرض النص والمواضع المرتبطة بدل تخمين تفسير غير موجود في المصدر المحلي.`;
      }

      let hadithNote="";
      if(/حديث|السنه|الرسول|النبي|سبب|فضل|حكم/.test(normalizeArabic(t))){
        const hadiths=await findHadithSupport(terms);
        if(hadiths.length){
          const h=hadiths[0];
          hadithNote=`\n\nحديث مرتبط: ${h.arabic.slice(0,420)}${h.arabic.length>420?"…":""} (${h.book}${h.reference?` · ${h.reference}`:""})`;
        }
      }

      const sabab=findAsbab(first.surahNumber,first.number);
      setAnswer({
        title:t.includes("معنى")?`معنى ${terms[0]||""}`:`إجابة من المراجع المحلية`,
        ayah:cleanQuranDisplay(first.text),
        ref:`سورة ${first.surahName} · الآية ${arNum(first.number)}`,
        meaning:meaning+hadithNote,
        context:all.slice(0,5).map(v=>`${v.surahName} ${arNum(v.number)}`).join(" · "),
        sabab:sabab?.occasions?.[0] || "لا يوجد سبب نزول مثبت لهذه الآية ضمن قاعدة أسباب النزول المحلية.",
        source:selected.length
          ? `نص القرآن · ${selected.map(x=>x.type).join(" · ")} · أسباب النزول المحلية${hadithNote?" · فهرس الحديث المحلي":""}`
          : `نص القرآن · مفردات الراغب · أسباب النزول المحلية${hadithNote?" · فهرس الحديث المحلي":""}`
      });
      return;
    }

    // If Quran matching is weak, use the offline hadith reference index.
    const hadiths=await findHadithSupport(terms);
    if(hadiths.length){
      const h=hadiths[0];
      setAnswer({
        title:"نص مرتبط من السنة",
        ayah:"",
        ref:"",
        meaning:`${h.arabic}${h.grade?`\n\nالدرجة في المصدر: ${h.grade}`:""}`,
        context:`المصدر: ${h.book}${h.reference?` · ${h.reference}`:""}`,
        sabab:"",
        source:"فهرس كتب الحديث المحلي داخل Noor"
      });
      return;
    }

    // Online verification is only a fallback. Noor remains usable offline.
    const online=await onlineQuranVerify(terms[0]||normalizeArabic(t));
    if(online){
      setAnswer({
        title:"تم التحقق عبر مصدر قرآني خارجي",
        ayah:cleanQuranDisplay(online.text),
        ref:`${online.surah}${online.number?` · الآية ${arNum(online.number)}`:""}`,
        meaning:"لم يظهر التطابق بوضوح في الفهرس المحلي، فتم التحقق من وجود النص عبر Al Quran Cloud عند توفر الإنترنت.",
        context:"سيبقى التطبيق معتمدًا على المصادر المحلية أولًا.",
        sabab:"",
        source:"Al Quran Cloud API · قاعدة Noor المحلية"
      });
      return;
    }

    // Final safe fallback: never fabricate an answer.
    setAnswer({
      title:"أقرب نتيجة موثوقة",
      ayah:"",
      ref:"",
      meaning:"السؤال عام جدًا أو لا يحتوي ألفاظًا تكفي لربطه بنص موثوق. أعد صياغته بكلمة قرآنية، اسم سورة، اسم نبي، موضوع، أو اذكر أنك تريد حديثًا أو تفسيرًا. لن يختلق Noor جوابًا بلا مرجع.",
      context:"المصحف والمعاني وأسباب النزول والحقائق الشائعة تعمل محليًا، وتتوفر مراجع إضافية إذا نجح تنزيلها أثناء Build.",
      sabab:"",
      source:"قاعدة Noor المحلية"
    });
  }

  const currentVerses=pages[readerPage]||[];
  const currentSurahs=[...new Map(currentVerses.map(v=>[v.surahNumber,v.surahName])).entries()];

  return <main className={dark?"app dark":"app"}>
    <div className="aurora a1"/><div className="aurora a2"/>

    <header>
      <div className="brand"><span className="logo">ن</span><div><b>نور</b><small>{tab==="quran"?"المصحف":"اسأل عن القرآن"}</small></div></div>
      <button className="icon glass" onClick={()=>setDark(!dark)} aria-label="تغيير المظهر">{dark?<Sun/>:<Moon/>}</button>
    </header>

    <section className="content">
      {tab==="home" && <>
        {!answer ? <div className="hero">
          <div className="orb"><BookOpen/></div>
          <h1 className="simpleTitle"><span>اسأل عن القرآن</span></h1>
          <div className="chips">{suggestions.map((s,i)=>
            <button className="chip glass" onClick={()=>submit(s)} key={s}>
              <span className="chipIcon">{i===0?<BookOpen/>:i===1?<Sparkles/>:i===2?<Quote/>:<BookOpen/>}</span>
              <span>{s}</span><ChevronLeft/>
            </button>)}
          </div>
        </div> :
        <div className="answer pageEnter">
          <button className="back glass" onClick={()=>{setAnswer(null);setQ("")}}><X/> سؤال جديد</button>
          <Glass className="answerCard">
            <div className="answerHead"><Sparkles/><div><small>إجابة نور المحلية</small><h2>{answer.title}</h2></div></div>
            {answer.ayah && <div className="ayah"><Quote/><p>{answer.ayah}</p><small>{answer.ref}</small></div>}
            <section><h3>المعنى</h3><p>{answer.meaning}</p></section>
            {answer.context && <section><h3>مواضع مرتبطة</h3><p>{answer.context}</p></section>}
            <section><h3>سبب النزول</h3><p>{answer.sabab}</p></section>
            <button className="source" onClick={()=>setSources(true)}><Info/> المصادر <ChevronLeft/></button>
          </Glass>
        </div>}
        <div className="composer glass"><Search/><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="اسأل عن القرآن…"/><button onClick={()=>submit()}><Send/></button></div>
      </>}

      {tab==="quran" && <div className="readerShell pageEnter">
        <div className="readerToolbar glass">
          <button onClick={()=>setSurahPicker(true)}><List/><span>{currentSurahs.map(([,n])=>n).join(" / ")||"المصحف"}</span></button>
          <div className="pageCounter">صفحة {arNum(readerPage)} من ٦٠٤</div>
          <button onClick={()=>{localStorage.setItem(`noor_reader_scroll_${readerPage}`,"0"); readerRef.current?.scrollTo({top:0,behavior:"smooth"})}} aria-label="بداية الصفحة"><RotateCcw/></button>
        </div>
        <div className="readerViewport" ref={readerRef} onScroll={onReaderScroll}>
          {!quran && <div className="readerLoading">{dataError||"جاري تحميل القرآن الكامل…"}</div>}
          {currentSurahs.map(([surahNumber,surahName])=>{
            const verses=currentVerses.filter(v=>v.surahNumber===surahNumber);
            const surah=quran?.surahs.find(s=>s.number===surahNumber);
            return <section className="mushafSurah" key={surahNumber}>
              <div className="surahBanner ornate">
                <span className="surahMeta">{surah?.revelation?.type==="Meccan"?"مكية":"مدنية"}</span>
                <b>{verses[0]?.number===1?"سورة":"تابع سورة"} {surahName}</b>
                <span className="surahMeta">{arNum(surah?.counts?.ayahs||verses.length)} آية</span>
              </div>
              <div className="mushafText">
                {verses.map(v=><React.Fragment key={v.verse_key}>
                  {v.words.map((w,wi)=><React.Fragment key={`${v.verse_key}-${wi}`}>
                    <WordSpan text={cleanQuranDisplay(w.text)} onLong={()=>openWord(v,wi,w.text)}/>{' '}
                  </React.Fragment>)}
                  <button className={`ayahNumber ${bookmarks.includes(v.verse_key)?"bookmarked":""}`} onClick={()=>toggleBookmark(v.verse_key)} aria-label={bookmarks.includes(v.verse_key)?"إزالة حفظ الآية":"حفظ الآية"}>
                    <span>{arNum(v.number)}</span>
                  </button>{' '}
                </React.Fragment>)}
              </div>
            </section>;
          })}
          <div className="readerBottomPad"/>
        </div>
        <div className="pageStepper">
          <button className="glass" onClick={()=>goPage(readerPage-1)} disabled={readerPage<=1}><ChevronRight/> السابقة</button>
          <button className="glass" onClick={()=>goPage(readerPage+1)} disabled={readerPage>=604}>التالية <ChevronLeft/></button>
        </div>
      </div>}

      {tab==="saved" && <Glass className="page savedPage pageEnter">
        <Bookmark/><h2>المحفوظات</h2>
        {bookmarks.length===0?<p>اضغط رقم أي آية داخل المصحف لحفظها هنا.</p>:
          <div className="savedList">{bookmarks.map(k=>{
            const v=verseByKey.get(k); if(!v)return null;
            return <button key={k} onClick={()=>{goPage(v.page,false);setTab("quran")}}>
              <b>سورة {v.surahName} · {arNum(v.number)}</b><span>{cleanQuranDisplay(v.text)}</span>
            </button>;
          })}</div>}
      </Glass>}

      {tab==="settings" && <Glass className="page settingsPage pageEnter">
        <Settings/><h2>الإعدادات</h2>
        <div className="setting"><span>الوضع</span><button onClick={()=>setDark(!dark)}>{dark?"داكن":"فاتح"}</button></div>
        <div className="setting"><span>آخر صفحة</span><b>{arNum(readerPage)}</b></div>
        <div className="setting"><span>أزرار الصوت</span><b>تغيير صفحات المصحف في تطبيق Android</b></div>
        <div className="setting qwenSetting">
          <div className="qwenLabel">
            <span>ذكاء Qwen المحلي</span>
            <small>{window.Android?`${qwenStatus}${qwenProgress>0&&qwenProgress<100?` · ${Math.round(qwenProgress)}%`:""}`:"متاح داخل تطبيق Android"}</small>
          </div>
          {window.Android && <div className="qwenActions">
            {!qwenReady
              ? <button onClick={()=>{setQwenStatus("بدء التنزيل…");window.Android?.startQwenDownload?.()}}>تنزيل Qwen</button>
              : <button className="dangerSoft" onClick={()=>{window.Android?.deleteQwenModel?.();setQwenReady(false);setQwenProgress(0);setQwenStatus("غير مثبت")}}>حذف النموذج</button>}
          </div>}
        </div>
        {window.Android && !qwenReady && <div className="qwenHint">Qwen3 0.6B Q4_K_M حجمه نحو 484 MB. يُنزّل مرة واحدة ثم يعمل محليًا لفهم السؤال. لا يستخدم كمرجع ديني مستقل.</div>}
        <div className="setting"><span>العمل بدون إنترنت</span><b>القرآن والمعاني وأسباب النزول وحقائق شائعة محلية</b></div>
        <div className="credits">
          <b>المصادر</b>
          <p>نص القرآن: Tanzil عبر Quran Core Dataset. المعاني: مفردات الراغب. أسباب النزول: صحيح أسباب النزول. وعند نجاح Build تُضاف ثمانية تفاسير رئيسية وفهرس حديثي واسع للاستخدام دون إنترنت.</p>
        </div>
      </Glass>}
    </section>

    <nav className={`nav glass nav-${tab}`}>
      <span className="liquidSelection" aria-hidden="true"/>
      <button className={tab==="home"?"active":""} onClick={()=>setTab("home")}><Sparkles/><span>اسأل</span></button>
      <button className={tab==="quran"?"active":""} onClick={()=>setTab("quran")}><BookOpen/><span>القرآن</span></button>
      <button className={tab==="saved"?"active":""} onClick={()=>setTab("saved")}><Bookmark/><span>محفوظات</span></button>
      <button className={tab==="settings"?"active":""} onClick={()=>setTab("settings")}><Settings/><span>الإعدادات</span></button>
    </nav>

    {sources&&<div className="modal" onClick={()=>setSources(false)}>
      <Glass className="sheet" onClick={e=>e.stopPropagation()}><button onClick={()=>setSources(false)}><X/></button><h2>المصادر</h2><p>{answer?.source}</p></Glass>
    </div>}

    {wordInfo&&<div className="modal wordModal" onClick={()=>setWordInfo(null)}>
      <Glass className="sheet wordSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setWordInfo(null)}><X/></button>
        <small>ضغط مطول · {wordInfo.verseKey}</small>
        <h2>{wordInfo.text}</h2>
        {wordInfo.root&&<div className="rootBadge">الجذر: {wordInfo.root}</div>}
        <h3 className="wordSectionTitle">المعنى في هذه الآية</h3>
        <p className="wordDefinition">{wordInfo.contextMeaning}</p>
        {wordInfo.lexicalMeaning&&<details className="lexicalDetails"><summary>المعنى المعجمي للجذر</summary><p>{wordInfo.lexicalMeaning}</p></details>}
        {wordInfo.english&&<details><summary>مرجع لغوي إضافي</summary><p>{wordInfo.english}</p></details>}
        <small>المصدر: {wordInfo.source}</small>
      </Glass>
    </div>}

    {surahPicker&&<div className="modal" onClick={()=>setSurahPicker(false)}>
      <Glass className="sheet surahSheet" onClick={e=>e.stopPropagation()}>
        <button onClick={()=>setSurahPicker(false)}><X/></button>
        <h2>السور</h2>
        <div className="surahList">{quran?.surahs.map(s=>
          <button key={s.number} onClick={()=>{goPage(firstPageBySurah.get(s.number)||1);setSurahPicker(false)}}>
            <span>{arNum(s.number)}</span><b>{s.name_arabic}</b><small>{arNum(s.counts.ayahs)} آية</small>
          </button>)}
        </div>
      </Glass>
    </div>}
  </main>;
}

function WordSpan({text,onLong}:{text:string;onLong:()=>void}){
  const timer=useRef<number>(0);
  const origin=useRef<{x:number;y:number}|null>(null);
  const start=(e:React.PointerEvent<HTMLSpanElement>)=>{
    origin.current={x:e.clientX,y:e.clientY};
    clearTimeout(timer.current);
    timer.current=window.setTimeout(()=>{onLong(); if(navigator.vibrate)navigator.vibrate(18);},520);
  };
  const move=(e:React.PointerEvent<HTMLSpanElement>)=>{
    if(!origin.current)return;
    if(Math.hypot(e.clientX-origin.current.x,e.clientY-origin.current.y)>9){
      clearTimeout(timer.current); origin.current=null;
    }
  };
  const stop=()=>{clearTimeout(timer.current);origin.current=null};
  return <span className="qWord" onPointerDown={start} onPointerMove={move} onPointerUp={stop} onPointerCancel={stop} onPointerLeave={stop} onContextMenu={e=>e.preventDefault()}>{text}</span>;
}

createRoot(document.getElementById("root")!).render(<App/>);
