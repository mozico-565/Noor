# Third-party data notices

Noor bundles Quran and reference data for offline use.

- Quran Core Dataset by Mirza Iqbal: CC BY 4.0.
- Underlying Tanzil Uthmani Quran text and metadata: CC BY 3.0. Quran text is kept verbatim.
- Quran bil-Quran code/data packaging: MIT. Its morphology/root mapping cites the Quranic Arabic Corpus (GNU GPL); the root data is kept as a separate data asset and attribution is preserved.
- Al-Mufradat fi Gharib al-Quran: classical work by al-Raghib al-Isfahani, packaged in Quran bil-Quran.
- Asbab al-Nuzul Dataset by mostafaahmed97: MIT, based on "Sahih Asbab al-Nuzul" by Ibrahim Muhammad al-Ali.

Do not remove these notices when redistributing the app.
