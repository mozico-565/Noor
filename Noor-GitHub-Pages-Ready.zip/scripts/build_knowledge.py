#!/usr/bin/env python3
import json, re, sys
from pathlib import Path

out=Path(sys.argv[1]); qbb=Path(sys.argv[2])
tafsir=Path(sys.argv[3]) if len(sys.argv)>3 and sys.argv[3] else None
hadith=Path(sys.argv[4]) if len(sys.argv)>4 and sys.argv[4] else None

(out/"tafsir").mkdir(parents=True,exist_ok=True)

def norm(s):
    s=str(s or "")
    s=re.sub(r"[\u064B-\u065F\u0670\u06D6-\u06ED]","",s)
    s=s.translate(str.maketrans({"إ":"ا","أ":"ا","آ":"ا","ٱ":"ا","ى":"ي","ؤ":"و","ئ":"ي","ة":"ه"}))
    s=re.sub(r"[^\u0621-\u063A\u0641-\u064A0-9\s]","",s)
    return re.sub(r"\s+"," ",s).strip()

# Surface word -> root
word_root={}
for p in sorted((qbb/"app/data/surahs").glob("*.json")):
    try: rows=json.loads(p.read_text(encoding="utf-8"))
    except Exception: continue
    for row in rows if isinstance(rows,list) else []:
        for w in row.get("words",[]) or []:
            t=norm(w.get("t","")); r=w.get("r")
            if t and r and t not in word_root: word_root[t]=r
(out/"word_root_index.json").write_text(json.dumps(word_root,ensure_ascii=False,separators=(",",":")),encoding="utf-8")

facts=[
 {"id":"longest-surah","patterns":["اطول سورة","أطول سورة"],"title":"أطول سورة في القرآن","answer":"أطول سورة في القرآن من حيث عدد الآيات هي سورة البقرة، وعدد آياتها 286 آية في العدّ المستخدم في هذا المصحف.","verseKey":"2:1","source":"بنية المصحف المحلية · Quran Core Dataset"},
 {"id":"shortest-surah","patterns":["اقصر سورة","أقصر سورة"],"title":"أقصر سورة في القرآن","answer":"سورة الكوثر هي أقصر سور القرآن من حيث عدد الآيات، فهي ثلاث آيات.","verseKey":"108:1","source":"بنية المصحف المحلية · Quran Core Dataset"},
 {"id":"longest-ayah","patterns":["اطول اية","أطول آية"],"title":"أطول آية في القرآن","answer":"أطول آية في القرآن هي آية الدَّين في سورة البقرة، الآية 282.","verseKey":"2:282","source":"سورة البقرة 2:282 · نص القرآن المحلي"},
 {"id":"biggest-ayah-question","patterns":["اكبر اية","أكبر آية","ما هي اكبر اية","ما هي أكبر آية"],"title":"إذا كنت تقصد الأكبر أو الأعظم","answer":"إذا كنت تقصد أطول آية فهي آية الدَّين، البقرة 282. وإذا كنت تقصد أعظم آية فقد ثبت في صحيح مسلم 810 أن آية الكرسي، البقرة 255، هي أعظم آية في كتاب الله.","verseKey":"2:255","source":"سورة البقرة 2:255 و2:282 · صحيح مسلم 810"},
 {"id":"ayat-kursi","patterns":["اشهر اية","أشهر آية","اية الكرسي","آية الكرسي"],"title":"آية الكرسي","answer":"من أشهر آيات القرآن آية الكرسي، وهي سورة البقرة الآية 255. وصف «الأشهر» تقديري، لذلك يعرض Noor هذا بصيغة «من أشهر الآيات» لا كترتيب قطعي.","verseKey":"2:255","source":"سورة البقرة 2:255 · نص القرآن المحلي"},
 {"id":"surah-count","patterns":["كم سورة","عدد السور"],"title":"عدد سور القرآن","answer":"القرآن الكريم يتكون من 114 سورة.","source":"بنية المصحف المحلية · Quran Core Dataset"},
 {"id":"juz-count","patterns":["كم جزء","عدد الاجزاء","عدد الأجزاء"],"title":"عدد أجزاء القرآن","answer":"القرآن مقسم إلى 30 جزءًا.","source":"بيانات بنية المصحف المحلية"},
 {"id":"first-surah","patterns":["اول سورة في المصحف","أول سورة في المصحف"],"title":"أول سورة في المصحف","answer":"أول سورة في ترتيب المصحف هي سورة الفاتحة.","verseKey":"1:1","source":"ترتيب المصحف المحلي"},
 {"id":"last-surah","patterns":["اخر سورة في المصحف","آخر سورة في المصحف"],"title":"آخر سورة في المصحف","answer":"آخر سورة في ترتيب المصحف هي سورة الناس.","verseKey":"114:1","source":"ترتيب المصحف المحلي"},
 {"id":"basmala-tawbah","patterns":["سورة بدون بسملة","السورة التي لا تبدأ بالبسملة","لا تبدا بالبسملة"],"title":"السورة التي لا تبدأ بالبسملة","answer":"سورة التوبة هي السورة الوحيدة في المصحف التي لا تبدأ ببسم الله الرحمن الرحيم.","verseKey":"9:1","source":"بيانات نص المصحف المحلي"},
 {"id":"two-basmala","patterns":["سورة فيها بسملتين","سورتين بسملة","بسملتان"],"title":"السورة التي وردت فيها البسملة مرتين","answer":"سورة النمل فيها البسملة في أول السورة، ووردت أيضًا في الآية 30 ضمن كتاب سليمان عليه السلام.","verseKey":"27:30","source":"سورة النمل 27:30 · نص القرآن المحلي"},
 {"id":"named-companion","patterns":["الصحابي المذكور في القران","الصحابي المذكور في القرآن","من هو الصحابي المذكور في القران","من هو الصحابي المذكور في القرآن","صحابي ذكر اسمه في القران","صحابي ذكر اسمه في القرآن"],"title":"الصحابي المذكور باسمه في القرآن","answer":"الصحابي الذي ذُكر باسمه صراحةً في القرآن هو زيد بن حارثة رضي الله عنه، في سورة الأحزاب الآية 37.","verseKey":"33:37","source":"سورة الأحزاب 33:37 · نص القرآن المحلي"}
]
(out/"common_facts.json").write_text(json.dumps(facts,ensure_ascii=False,separators=(",",":")),encoding="utf-8")

# Compact 8-tafsir per-surah reference layer + compact full-text search index.
tafsir_count=0
tafsir_search=[]
if tafsir and (tafsir/"json-data").exists():
    for p in sorted((tafsir/"json-data").glob("*.json")):
        try:d=json.loads(p.read_text(encoding="utf-8"))
        except Exception:continue
        number=int(d.get("number",0) or 0)
        if not number: continue
        ayahs=[]
        for a in d.get("ayahs",[]) or []:
            refs=[]
            for x in a.get("tafsir",[]) or []:
                txt=re.sub(r"\s+"," ",str(x.get("text",""))).strip()
                if txt:
                    refs.append({"type":str(x.get("type","تفسير")),"text":txt[:1000]})
            ayah_number=int(a.get("ayah_number",0) or 0)
            ayahs.append({"ayah_number":ayah_number,"tafsir":refs})
            preferred=sorted(
                refs,
                key=lambda x: (
                    0 if "الميسر" in x["type"] else
                    1 if "السعدي" in x["type"] else
                    2 if "ابن كثير" in x["type"] else
                    3 if "الطبري" in x["type"] else
                    4 if "القرطبي" in x["type"] else 9
                )
            )[:2]
            if ayah_number and preferred:
                tafsir_search.append({
                    "verseKey":f"{number}:{ayah_number}",
                    "surah":number,
                    "ayah":ayah_number,
                    "text":" ".join(x["text"][:420] for x in preferred)
                })
        payload={"surah":d.get("surah",""),"number":number,"ayahs":ayahs}
        (out/"tafsir"/f"{number:03}.json").write_text(json.dumps(payload,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
        tafsir_count+=1

(out/"tafsir_search.json").write_text(
    json.dumps(tafsir_search,ensure_ascii=False,separators=(",",":")),
    encoding="utf-8"
)

# Generic compact hadith index from by_book JSON.
items=[]; seen=set()
def walk(x,book):
    if isinstance(x,dict):
        arabic=x.get("arabic")
        if isinstance(arabic,str) and len(norm(arabic))>18:
            ident=x.get("idInBook",x.get("id",len(items)+1))
            ref=x.get("reference","")
            if isinstance(ref,dict): ref=ref.get("text") or ref.get("inBookReference") or ""
            grade=x.get("grade","")
            if isinstance(grade,dict): grade=grade.get("grade","")
            key=(book,str(ident),norm(arabic)[:90])
            if key not in seen:
                seen.add(key)
                items.append({"book":book,"id":ident,"arabic":re.sub(r"\s+"," ",arabic).strip()[:900],"reference":str(ref or ""),"grade":str(grade or "")})
        for v in x.values(): walk(v,book)
    elif isinstance(x,list):
        for v in x: walk(v,book)

if hadith:
    base=hadith/"db/by_book"
    if base.exists():
        for p in sorted(base.rglob("*.json")):
            try:d=json.loads(p.read_text(encoding="utf-8"))
            except Exception:continue
            walk(d,p.stem)

(out/"hadith_index.json").write_text(json.dumps(items,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
manifest={"word_roots":len(word_root),"common_facts":len(facts),"tafsir_surahs":tafsir_count,"tafsir_search_rows":len(tafsir_search),"hadith_entries":len(items)}
(out/"knowledge_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
print("Knowledge manifest:",manifest)
