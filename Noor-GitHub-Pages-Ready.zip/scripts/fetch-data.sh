#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/public/data"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$OUT/surahs"

echo "Downloading Quran Core Dataset..."
curl -fsSL --retry 4 https://github.com/mjmirza/quran-dataset/archive/refs/heads/main.tar.gz -o "$TMP/quran.tar.gz"
tar -xzf "$TMP/quran.tar.gz" -C "$TMP"
cp "$TMP"/quran-dataset-main/data/quran.json "$OUT/quran.json"

echo "Downloading local word roots and Mufradat..."
curl -fsSL --retry 4 https://github.com/R3GENESI5/quran-bil-quran/archive/refs/heads/master.tar.gz -o "$TMP/qbb.tar.gz"
tar -xzf "$TMP/qbb.tar.gz" -C "$TMP"
QBB="$(find "$TMP" -maxdepth 1 -type d -name 'quran-bil-quran-*' | head -1)"
cp "$QBB/app/data/mufradat.json" "$OUT/mufradat.json"
cp "$QBB/app/data/roots_index.json" "$OUT/roots_index.json"
cp "$QBB/app/data/surahs/"*.json "$OUT/surahs/"

echo "Downloading authenticated Asbab al-Nuzul dataset..."
curl -fsSL --retry 4 https://github.com/mostafaahmed97/asbab-al-nuzul-dataset/archive/refs/heads/main.tar.gz -o "$TMP/asbab.tar.gz"
tar -xzf "$TMP/asbab.tar.gz" -C "$TMP"
ASBAB="$(find "$TMP" -maxdepth 1 -type d -name 'asbab-al-nuzul-dataset-*' | head -1)"
python3 "$ROOT/scripts/merge_asbab.py" "$ASBAB/data/structured/json" "$OUT/asbab.json"

cat > "$OUT/sources.json" <<'EOF'
{
  "quran": "Quran Core Dataset (mjmirza), based on Tanzil Uthmani text and metadata",
  "word_roots": "Quran bil-Quran / Quranic Arabic Corpus derived root mapping",
  "mufradat": "Al-Mufradat fi Gharib al-Quran by al-Raghib al-Isfahani, packaged by Quran bil-Quran",
  "asbab": "Asbab al-Nuzul Dataset based on Sahih Asbab al-Nuzul by Ibrahim Muhammad al-Ali"
}
EOF
echo "Data ready in $OUT"
