#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/public/data"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$OUT/surahs"

download() {
  local url="$1"
  local out="$2"
  echo "↓ $url"
  curl -fL --retry 5 --retry-delay 2 --retry-all-errors --connect-timeout 30 "$url" -o "$out"
}

echo "=== Quran text + Mushaf metadata ==="
download "https://codeload.github.com/mjmirza/quran-dataset/tar.gz/refs/heads/main" "$TMP/quran.tar.gz"
tar -xzf "$TMP/quran.tar.gz" -C "$TMP"
QURAN_DIR="$(find "$TMP" -maxdepth 1 -type d -name 'quran-dataset-*' | head -1)"
test -f "$QURAN_DIR/data/quran.json"
cp "$QURAN_DIR/data/quran.json" "$OUT/quran.json"

echo "=== Roots + local Mufradat ==="
download "https://codeload.github.com/R3GENESI5/quran-bil-quran/tar.gz/refs/heads/master" "$TMP/qbb.tar.gz"
tar -xzf "$TMP/qbb.tar.gz" -C "$TMP"
QBB_DIR="$(find "$TMP" -maxdepth 1 -type d -name 'quran-bil-quran-*' | head -1)"
test -f "$QBB_DIR/app/data/mufradat.json"
test -f "$QBB_DIR/app/data/roots_index.json"
cp "$QBB_DIR/app/data/mufradat.json" "$OUT/mufradat.json"
cp "$QBB_DIR/app/data/roots_index.json" "$OUT/roots_index.json"
cp "$QBB_DIR/app/data/surahs/"*.json "$OUT/surahs/"

echo "=== Asbab al-Nuzul ==="
download "https://codeload.github.com/mostafaahmed97/asbab-al-nuzul-dataset/tar.gz/refs/heads/main" "$TMP/asbab.tar.gz"
tar -xzf "$TMP/asbab.tar.gz" -C "$TMP"
ASBAB_DIR="$(find "$TMP" -maxdepth 1 -type d -name 'asbab-al-nuzul-dataset-*' | head -1)"
python3 "$ROOT/scripts/merge_asbab.py" "$ASBAB_DIR/data/structured/json" "$OUT/asbab.json"

echo "=== Validate Quran package ==="
python3 - "$OUT/quran.json" <<'PY'
import json, sys
p=sys.argv[1]
d=json.load(open(p,encoding="utf-8"))
surahs=d.get("surahs",[])
ayahs=sum(len(s.get("ayahs",[])) for s in surahs)
pages={a.get("page") for s in surahs for a in s.get("ayahs",[]) if a.get("page")}
assert len(surahs)==114, f"Expected 114 surahs, got {len(surahs)}"
assert ayahs==6236, f"Expected 6236 ayahs, got {ayahs}"
assert min(pages)==1 and max(pages)==604, f"Unexpected pages: {min(pages)}..{max(pages)}"
print(f"✓ Quran validated: {len(surahs)} surahs, {ayahs} ayahs, pages 1..604")
PY

cat > "$OUT/sources.json" <<'EOF'
{
  "quran": "Quran Core Dataset (mjmirza), based on Tanzil Uthmani text and metadata",
  "word_roots": "Quran bil-Quran / Quranic Arabic Corpus derived root mapping",
  "mufradat": "Al-Mufradat fi Gharib al-Quran by al-Raghib al-Isfahani, packaged by Quran bil-Quran",
  "asbab": "Asbab al-Nuzul Dataset based on Sahih Asbab al-Nuzul by Ibrahim Muhammad al-Ali"
}
EOF

echo "✓ Offline data prepared."
