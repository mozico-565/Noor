import json, sys
from pathlib import Path
src=Path(sys.argv[1]); out=Path(sys.argv[2])
if (src/"all.json").exists():
    data=json.loads((src/"all.json").read_text(encoding="utf-8-sig"))
else:
    data=[]
    for p in sorted(src.glob("*.json")):
        if p.name=="all.json": continue
        try:
            d=json.loads(p.read_text(encoding="utf-8-sig"))
            if isinstance(d,list): data.extend(d)
        except Exception:
            pass
out.write_text(json.dumps(data,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
print(f"merged {len(data)} asbab entries")
